import React, { useState } from 'react';
import { MessageSquareQuoteIcon } from './Icons';
import FeedbackModal from './FeedbackModal';

const FloatingFeedbackButton: React.FC = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);

    return (
        <>
            <button
                onClick={() => setIsModalOpen(true)}
                className="fixed bottom-6 left-6 z-40 flex items-center px-4 py-3 bg-indigo-600 text-white font-bold rounded-full shadow-lg hover:bg-indigo-700 transition-all transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                aria-label="תן משוב בטא"
                dir="rtl"
            >
                <MessageSquareQuoteIcon className="w-5 h-5 ml-2" />
                <span>בטא - תן משוב</span>
            </button>
            <FeedbackModal 
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
            />
        </>
    );
};

export default FloatingFeedbackButton;
