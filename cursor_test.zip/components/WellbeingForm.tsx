
import React, { useState, useEffect, useMemo } from 'react';
import { MoodRecord, Student, Role, Tool } from '../types';
import { SmileIcon, Users2Icon, BookOpenIcon, HomeIcon, MicIcon } from './Icons';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { useToast } from '../hooks/useToast';


export interface WellbeingFormData extends Omit<MoodRecord, 'id' | 'averageScore' | 'date'> {
    mentorImpression?: string;
    usedToolId?: string;
}

interface WellbeingFormProps {
  student: Student;
  onSubmit: (record: WellbeingFormData) => void;
  onCancel: () => void;
  isSubmitting: boolean;
  role: Role;
  tools: Tool[];
}

const SliderInput = ({ label, explanation, value, onChange, Icon, color }: { label: string, explanation: string, value: number, onChange: (val: number) => void, Icon: React.FC<{className?: string}>, color: string }) => {
    
    const isRated = value > 0;
    const thumbPercent = value * 10; // Simple percentage for 0-10 scale

    return (
        <div>
            <label className="flex items-center text-lg font-semibold text-gray-700 mb-1">
                <Icon className={`w-6 h-6 ml-2 ${color}`} />
                {label}
            </label>
            <p className="text-xs text-gray-500 mb-2 pr-8">{explanation}</p>
            {/* The wrapper div is LTR to ensure slider and labels are laid out left-to-right. */}
            <div dir="ltr">
                <div className="relative w-full pt-8">
                    {isRated && (
                        <div
                            className="absolute text-white text-xs font-bold rounded-full flex items-center justify-center transform -translate-x-1/2 pointer-events-none"
                            style={{
                                left: `${thumbPercent}%`,
                                top: '0px',
                                height: '24px',
                                width: '24px',
                                backgroundColor: 'rgb(79 70 229)',
                            }}
                        >
                            {value}
                        </div>
                    )}
                    <input
                        type="range"
                        min="0"
                        max="10"
                        step="1"
                        value={value}
                        onChange={(e) => onChange(parseInt(e.target.value))}
                        className={`w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer transition-colors ${isRated ? 'accent-indigo-600' : 'accent-gray-400'}`}
                    />
                </div>
                 <div className="relative h-4 mt-2 text-xs text-gray-500">
                    <span className="absolute whitespace-nowrap" style={{ left: '10%', transform: 'translateX(-50%)' }}>
                        ממש לא משהו (1)
                    </span>
                    <span className="absolute whitespace-nowrap" style={{ left: '100%', transform: 'translateX(-100%)' }}>
                        מעולה! (10)
                    </span>
                </div>
            </div>
        </div>
    );
};


const WellbeingForm: React.FC<WellbeingFormProps> = ({ student, onSubmit, onCancel, isSubmitting, role, tools }) => {
  const [emotionalScore, setEmotionalScore] = useState<number>(0);
  const [socialScore, setSocialScore] = useState<number>(0);
  const [academicScore, setAcademicScore] = useState<number>(0);
  const [personalScore, setPersonalScore] = useState<number>(0);
  const [emotionalEvidence, setEmotionalEvidence] = useState('');
  const [socialEvidence, setSocialEvidence] = useState('');
  const [academicEvidence, setAcademicEvidence] = useState('');
  const [personalEvidence, setPersonalEvidence] = useState('');
  
  // Mentor-specific fields
  const [mentorImpression, setMentorImpression] = useState('');
  const [usedToolId, setUsedToolId] = useState('');
  const { addToast } = useToast();


  const [listeningField, setListeningField] = useState<string | null>(null);
  const {
      text,
      interimText,
      isListening,
      startListening,
      stopListening,
      hasRecognitionSupport,
  } = useSpeechRecognition();

  useEffect(() => {
    if (text && listeningField) {
        const updateFunctions: { [key: string]: React.Dispatch<React.SetStateAction<string>> } = {
            emotional: setEmotionalEvidence,
            social: setSocialEvidence,
            academic: setAcademicEvidence,
            personal: setPersonalEvidence,
            impression: setMentorImpression,
        };
        const updateFunction = updateFunctions[listeningField];
        if (updateFunction) {
            updateFunction(prev => (prev ? prev.trim() + ' ' : '') + text);
        }
    }
  }, [text, listeningField]);
  
  const handleMicClick = (fieldName: string) => {
    if (isListening && listeningField === fieldName) {
        stopListening();
    } else {
        if(isListening) stopListening();
        setListeningField(fieldName);
        startListening();
    }
  };

  const isAnyScoreRated = useMemo(() => {
    return [emotionalScore, socialScore, academicScore, personalScore].some(s => s > 0);
  }, [emotionalScore, socialScore, academicScore, personalScore]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if(isListening) stopListening();

    if (!isAnyScoreRated) {
        addToast("חייבים למלא לפחות דיווח אחד (ועדיף יותר)", "error");
        return;
    }

    onSubmit({
      studentId: student.id,
      emotionalScore: emotionalScore || null,
      socialScore: socialScore || null,
      academicScore: academicScore || null,
      personalScore: personalScore || null,
      emotionalEvidence,
      socialEvidence,
      academicEvidence,
      personalEvidence,
      mentorImpression: role === 'mentor' ? mentorImpression : undefined,
      usedToolId: role === 'mentor' ? (usedToolId || undefined) : undefined,
    });
  };
  
  const handleCancel = () => {
    if(isListening) stopListening();
    setEmotionalScore(0);
    setSocialScore(0);
    setAcademicScore(0);
    setPersonalScore(0);
    setEmotionalEvidence('');
    setSocialEvidence('');
    setAcademicEvidence('');
    setPersonalEvidence('');
    setMentorImpression('');
    setUsedToolId('');
    onCancel();
  }

  const cardClasses = "p-4 rounded-lg border";
  const textAreaClasses = "w-full p-2 border rounded-md mt-3 text-sm resize-none";

  const renderEvidenceInput = (
      fieldName: 'emotional' | 'social' | 'academic' | 'personal' | 'impression', 
      value: string, 
      setter: (val: string) => void, 
      placeholder: string
  ) => {
    const isCurrentlyListening = isListening && listeningField === fieldName;
    const isDisabled = isListening && !isCurrentlyListening;
    return (
        <div className="relative mt-3">
            <textarea
                value={isCurrentlyListening ? value + (interimText ? ' ' + interimText : '') : value}
                onChange={e => setter(e.target.value)}
                placeholder={placeholder}
                className={`${textAreaClasses} pl-12`}
                disabled={isDisabled}
                rows={3}
            />
            {hasRecognitionSupport && (
                <button
                    type="button"
                    onClick={() => handleMicClick(fieldName)}
                    className={`absolute bottom-2.5 left-2 p-2 rounded-full transition-colors ${
                        isCurrentlyListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                    disabled={isDisabled}
                    title={isCurrentlyListening ? 'הפסק הקלטה' : 'התחל הקלטה'}
                >
                    <MicIcon className="w-5 h-5" />
                </button>
            )}
        </div>
    );
  };


  return (
    <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-4 space-y-4">
      
      <div className={`${cardClasses} bg-green-50 border-green-200`}>
        <SliderInput 
          label="מ'קורה חברתית?" 
          explanation="חשבו על הקשרים עם חברים. דרגו בין 1 ('על הפנים') ל-10 ('מדהים!'), וכתבו בעדות על אירוע חברתי שהשפיע עליכם."
          value={socialScore} 
          onChange={setSocialScore} 
          Icon={Users2Icon} 
          color="text-green-500" 
        />
        {socialScore > 0 && renderEvidenceInput('social', socialEvidence, setSocialEvidence, "עדות (מה קרה עם חברים?)")}
      </div>
      
      <div className={`${cardClasses} bg-orange-50 border-orange-200`}>
        <SliderInput 
          label="מ'קורה לימודית?" 
          explanation="חשבו איך הלך בלימודים. דרגו בין 1 ('על הפנים') ל-10 ('מדהים!'), וכתבו בעדות על מקצוע שהיה קל או מאתגר."
          value={academicScore} 
          onChange={setAcademicScore} 
          Icon={BookOpenIcon} 
          color="text-orange-500" 
        />
        {academicScore > 0 && renderEvidenceInput('academic', academicEvidence, setAcademicEvidence, "עדות (איך הלך בלימודים?)")}
      </div>
      
      <div className={`${cardClasses} bg-blue-50 border-blue-200`}>
        <SliderInput 
          label="מ'קורה רגשית?" 
          explanation="חשבו על מצב הרוח הכללי. דרגו בין 1 ('על הפנים') ל-10 ('מדהים!'), וכתבו בעדות מה גרם לכם להרגיש כך."
          value={emotionalScore} 
          onChange={setEmotionalScore} 
          Icon={SmileIcon} 
          color="text-blue-500" 
        />
        {emotionalScore > 0 && renderEvidenceInput('emotional', emotionalEvidence, setEmotionalEvidence, "עדות (איך הרגשת?)")}
      </div>

      <div className={`${cardClasses} bg-purple-50 border-purple-200`}>
        <SliderInput 
          label="מ'קורה בגדול?" 
          explanation="חשבו על דברים אישיים (משפחה, תחביבים). דרגו בין 1 ('על הפנים') ל-10 ('מדהים!'), וכתבו בעדות מה שלומכם."
          value={personalScore} 
          onChange={setPersonalScore} 
          Icon={HomeIcon} 
          color="text-purple-500" 
        />
        {personalScore > 0 && renderEvidenceInput('personal', personalEvidence, setPersonalEvidence, "עדות (מה שלומך באופן כללי?)")}
      </div>
      
      {role === Role.Mentor && (
        <div className="p-4 rounded-lg border-2 border-dashed border-indigo-300 bg-indigo-50 mt-6 space-y-4">
          <h3 className="font-bold text-lg text-indigo-800">התרשמות חונך (לאחר הפגישה)</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700">התרשמות כללית מהפגישה</label>
            {renderEvidenceInput('impression', mentorImpression, setMentorImpression, "סיכום, תובנות, נקודות להמשך...")}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">כלי שהשתמשתי בו מהמאגר (אופציונלי)</label>
            <select
                value={usedToolId}
                onChange={(e) => setUsedToolId(e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"
            >
                <option value="">ללא</option>
                {tools.map(tool => <option key={tool.id} value={tool.id}>{tool.name}</option>)}
            </select>
          </div>
        </div>
      )}

      <div className="flex justify-end space-x-3 space-x-reverse pt-2">
        <button
          type="button"
          onClick={handleCancel}
          className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          בטל
        </button>
        <button 
          type="submit" 
          disabled={isSubmitting || isListening}
          className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400 disabled:cursor-not-allowed"
        >
          {isSubmitting ? 'שומר...' : 'שמור'}
        </button>
      </div>
    </form>
  );
};

export default WellbeingForm;
