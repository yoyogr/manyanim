import React, { useEffect, useState } from 'react';
import { Toast, ToastType } from '../types';
import { CheckCircleIcon, AlertCircleIcon, InfoIcon, XIcon } from './Icons';

interface ToastProps {
  toast: Toast;
  onDismiss: (id: number) => void;
}

const ICONS: Record<ToastType, React.ReactNode> = {
  success: <CheckCircleIcon className="w-6 h-6 text-green-500" />,
  error: <AlertCircleIcon className="w-6 h-6 text-red-500" />,
  info: <InfoIcon className="w-6 h-6 text-blue-500" />,
};

const BG_COLORS: Record<ToastType, string> = {
  success: 'bg-green-50 border-green-400',
  error: 'bg-red-50 border-red-400',
  info: 'bg-blue-50 border-blue-400',
};

const ToastComponent: React.FC<ToastProps> = ({ toast, onDismiss }) => {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(() => onDismiss(toast.id), 300); // Wait for exit animation
    }, 4000); // 4 seconds
    return () => clearTimeout(timer);
  }, [toast.id, onDismiss]);

  const handleDismiss = () => {
    setIsExiting(true);
    setTimeout(() => onDismiss(toast.id), 300);
  };

  const animationClass = isExiting 
    ? 'animate-toast-exit'
    : 'animate-toast-enter';

  return (
    <div
      className={`relative w-full max-w-sm p-4 rounded-lg shadow-lg flex items-start border-r-4 ${BG_COLORS[toast.type]} ${animationClass}`}
    >
      <div className="flex-shrink-0">{ICONS[toast.type]}</div>
      <div className="mr-3 flex-1 text-sm font-medium text-gray-800">
        {toast.message}
      </div>
      <button
        onClick={handleDismiss}
        className="flex-shrink-0 ml-auto -mr-1 -mt-1 p-1 rounded-md text-gray-400 hover:text-gray-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
      >
        <XIcon className="w-5 h-5" />
      </button>
      <style>{`
        @keyframes toast-enter {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        @keyframes toast-exit {
          from { transform: translateX(0); opacity: 1; }
          to { transform: translateX(100%); opacity: 0; }
        }
        .animate-toast-enter { animation: toast-enter 0.3s ease-out forwards; }
        .animate-toast-exit { animation: toast-exit 0.3s ease-in forwards; }
      `}</style>
    </div>
  );
};

export default ToastComponent;
