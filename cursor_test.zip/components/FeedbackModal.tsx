import React, { useState } from 'react';
import { useToast } from '../hooks/useToast';
import { useAuth } from '../hooks/useAuth';
import apiService from '../services/apiService';
import { FeedbackType } from '../types';
import { XIcon, MessageSquareQuoteIcon, LightbulbIcon, AlertTriangleIcon } from './Icons';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({ isOpen, onClose }) => {
    const [feedbackType, setFeedbackType] = useState<FeedbackType>('comment');
    const [message, setMessage] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { addToast } = useToast();
    const { user } = useAuth();

    if (!isOpen) return null;

    const handleClose = () => {
        if (isSubmitting) return;
        // Reset state for next time
        setFeedbackType('comment');
        setMessage('');
        onClose();
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!message.trim()) {
            addToast('יש למלא את תוכן המשוב', 'error');
            return;
        }
        
        if (!user) {
            addToast('יש להתחבר כדי לשלוח משוב', 'error');
            return;
        }

        setIsSubmitting(true);
        
        try {
            await apiService.addFeedback({
                userId: user.id,
                userName: `${user.firstName} ${user.lastName}`,
                userRole: user.role,
                type: feedbackType,
                message: message,
            });
            addToast('המשוב שלך נשלח בהצלחה, תודה!', 'success');
            handleClose();
        } catch (error) {
            addToast('שליחת המשוב נכשלה', 'error');
        } finally {
            setIsSubmitting(false);
        }
    };

    const typeOptions: { id: FeedbackType; label: string; icon: React.ReactNode }[] = [
        { id: 'comment', label: 'הערה כללית', icon: <MessageSquareQuoteIcon className="w-5 h-5" /> },
        { id: 'feature', label: 'בקשת פיצ\'ר', icon: <LightbulbIcon className="w-5 h-5" /> },
        { id: 'bug', label: 'דיווח על באג', icon: <AlertTriangleIcon className="w-5 h-5" /> },
    ];

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={handleClose}>
            <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-lg relative" onClick={(e) => e.stopPropagation()}>
                <button onClick={handleClose} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors">
                    <XIcon className="w-6 h-6" />
                </button>
                <h2 className="text-2xl font-bold mb-4 text-gray-900">
                    שליחת משוב, פיצ'ר או באג
                </h2>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">סוג הפנייה</label>
                        <div className="flex flex-col sm:flex-row rounded-lg border border-gray-200 overflow-hidden">
                            {typeOptions.map((option, index) => (
                                <label key={option.id} className={`flex-1 p-3 flex items-center justify-center cursor-pointer transition-colors ${feedbackType === option.id ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'} ${index > 0 ? 'sm:border-r border-t sm:border-t-0 border-gray-200' : ''}`}>
                                    <input
                                        type="radio"
                                        name="feedbackType"
                                        value={option.id}
                                        checked={feedbackType === option.id}
                                        onChange={() => setFeedbackType(option.id)}
                                        className="sr-only"
                                    />
                                    {option.icon}
                                    <span className="mr-2 font-semibold">{option.label}</span>
                                </label>
                            ))}
                        </div>
                    </div>
                    <div>
                        <label htmlFor="message" className="block text-sm font-medium text-gray-700">תוכן הפנייה</label>
                        <textarea
                            id="message"
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            rows={8}
                            className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                            placeholder="נשמח לשמוע מה יש לך להגיד..."
                            required
                        />
                    </div>
                    <div className="flex justify-end space-x-3 space-x-reverse pt-2">
                        <button
                            type="button"
                            onClick={handleClose}
                            disabled={isSubmitting}
                            className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            בטל
                        </button>
                        <button 
                            type="submit" 
                            disabled={isSubmitting}
                            className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400"
                        >
                            {isSubmitting ? 'שולח...' : 'שלח משוב'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default FeedbackModal;