import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth';
import { LogOutIcon, ChevronDownIcon, UsersIcon, HomeIcon, ArchiveIcon, AlertTriangleIcon } from './Icons';
import apiService from '../services/apiService';

const Header: React.FC = () => {
    const { user, logout, isAdmin, adminView, setAdminView, isMentor, isImpersonating, exitImpersonation } = useAuth();
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
                setIsMenuOpen(false);
            }
        };
        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, []);

    const handleExportData = async () => {
        if (!user) return;
        try {
            const jsonData = await apiService.exportAllData(user.id);
            const blob = new Blob([jsonData], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            const safeName = `${user.firstName}_${user.lastName}`.replace(/[^a-z0-9]/gi, '_').toLowerCase();
            link.download = `menaynim_backup_${safeName}_${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            setIsMenuOpen(false);
        } catch (error) {
            console.error("Failed to export data:", error);
            // Optionally add a toast message for the user
        }
    };


    if (!user) return null;

    const navigateToAdminPanel = () => {
        setAdminView(true);
        setIsMenuOpen(false);
    }

    const navigateToDashboard = () => {
        setAdminView(false);
        setIsMenuOpen(false);
    }

    return (
        <>
            {isImpersonating && (
                <div className="fixed top-0 left-0 right-0 bg-yellow-400 text-yellow-900 px-4 py-2 text-center text-sm font-bold z-50 flex justify-between items-center" dir="rtl">
                    <div>
                        <AlertTriangleIcon className="w-5 h-5 inline-block ml-2"/>
                        אתה צופה במערכת בתור <span className="underline">{user.firstName} {user.lastName}</span>.
                    </div>
                    <button onClick={exitImpersonation} className="bg-yellow-600 hover:bg-yellow-700 text-white font-bold py-1 px-3 rounded-md text-xs">
                        צא ממצב התחזות
                    </button>
                </div>
            )}
            <header className={`fixed ${isImpersonating ? 'top-10' : 'top-0'} left-0 right-0 bg-white shadow-md h-20 z-40 flex items-center justify-between px-4 sm:px-6`} dir="rtl">
                <div className="text-3xl font-bold text-indigo-600" style={{ fontFamily: "'Heebo', sans-serif", fontWeight: 800 }}>
                מ׳ניינים?
                </div>
                
                <div className="relative" ref={menuRef}>
                    <button 
                        onClick={() => setIsMenuOpen(!isMenuOpen)} 
                        className="flex items-center space-x-2 space-x-reverse p-2 rounded-lg hover:bg-gray-100 transition-colors"
                    >
                        <div className="flex items-center">
                        <span className="font-semibold text-gray-700">{user.firstName} {user.lastName}</span>
                        {isAdmin && <span className="text-xs bg-indigo-100 text-indigo-700 font-bold py-0.5 px-2 rounded-full mr-2">אדמין</span>}
                        </div>
                        <ChevronDownIcon className={`w-5 h-5 text-gray-500 transition-transform ${isMenuOpen ? 'rotate-180' : ''}`} />
                    </button>

                    {isMenuOpen && (
                        <div className="absolute left-0 mt-2 w-56 bg-white rounded-md shadow-lg py-1 ring-1 ring-black ring-opacity-5">
                            {isAdmin && !adminView && (
                                <button 
                                    onClick={navigateToAdminPanel}
                                    className="w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                                >
                                    <UsersIcon className="w-4 h-4 ml-2" />
                                    <span>פאנל ניהול</span>
                                </button>
                            )}
                            {isAdmin && adminView && (
                                <button 
                                    onClick={navigateToDashboard}
                                    className="w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                                >
                                    <HomeIcon className="w-4 h-4 ml-2" />
                                    <span>חזור לדשבורד</span>
                                </button>
                            )}
                            {(isAdmin || isMentor) && (
                                <button 
                                    onClick={handleExportData}
                                    className="w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                                >
                                    <ArchiveIcon className="w-4 h-4 ml-2" />
                                    <span>גיבוי וייצוא נתונים</span>
                                </button>
                            )}
                            <div className="border-t my-1"></div>
                            <button 
                                onClick={logout}
                                className="w-full text-right px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center"
                            >
                                <LogOutIcon className="w-4 h-4 ml-2" />
                                <span>התנתקות</span>
                            </button>
                        </div>
                    )}
                </div>
            </header>
        </>
    );
};

export default Header;
