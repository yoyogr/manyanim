
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import apiService from '../services/apiService';
import { Role, User, Student, Gender, Feedback, FeedbackStatus, FeedbackType } from '../types';
import { ChevronLeftIcon, EditIcon, PlusCircleIcon, XIcon, UsersIcon, UploadCloudIcon, TrashIcon, MessageSquareQuoteIcon, LightbulbIcon, AlertTriangleIcon, ArchiveIcon, CornerUpLeftIcon } from '../components/Icons';
import Papa from 'papaparse';

const LoadingSpinner: React.FC = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
);

// --- Confirmation Modal for Deletion ---
const ConfirmationModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onConfirm: () => void;
    isProcessing: boolean;
    userName: string;
}> = ({ isOpen, onClose, onConfirm, isProcessing, userName }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-[60] p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-xl font-bold mb-2 text-gray-800">אישור מחיקה</h2>
                <p className="text-gray-600 mb-6">
                    האם אתה בטוח שברצונך למחוק את המשתמש <span className="font-bold">{userName}</span>? 
                    פעולה זו היא בלתי הפיכה ותמחק את כל הנתונים המשויכים למשתמש זה.
                </p>
                <div className="flex justify-end space-x-3 space-x-reverse">
                    <button type="button" onClick={onClose} disabled={isProcessing} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">
                        ביטול
                    </button>
                    <button onClick={onConfirm} disabled={isProcessing} className="inline-flex justify-center items-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:bg-gray-400">
                        {isProcessing ? 'מוחק...' : 'מחק'}
                    </button>
                </div>
            </div>
        </div>
    );
};

// --- Import Students Modal ---
const ImportStudentsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onImportSuccess: () => void;
}> = ({ isOpen, onClose, onImportSuccess }) => {
    const [step, setStep] = useState(1);
    const [file, setFile] = useState<File | null>(null);
    const [parsedData, setParsedData] = useState<any[]>([]);
    const [errors, setErrors] = useState<string[]>([]);
    const [isProcessing, setIsProcessing] = useState(false);
    const { addToast } = useToast();

    const resetState = useCallback(() => {
        setStep(1);
        setFile(null);
        setParsedData([]);
        setErrors([]);
        setIsProcessing(false);
    }, []);

    useEffect(() => {
        if(isOpen) resetState();
    }, [isOpen, resetState]);

    const handleClose = () => {
        resetState();
        onClose();
    };

    const handleDownloadTemplate = () => {
        const headers = "firstName,lastName,class,gender,studentPhone";
        const csvContent = `data:text/csv;charset=utf-8,${headers}\n`;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "menaynim_students_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
        }
    };
    
    const handleParseFile = () => {
        if (!file) return;
        setIsProcessing(true);
        setErrors([]);
        setParsedData([]);

        Papa.parse(file, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                const newErrors: string[] = [];
                const validData: any[] = [];
                const requiredFields = ['firstName', 'lastName', 'class', 'gender'];

                results.data.forEach((row: any, index: number) => {
                    const missingFields = requiredFields.filter(field => !row[field] || !row[field].trim());
                    if (missingFields.length > 0) {
                        newErrors.push(`שורה ${index + 2}: חסרים שדות חובה: ${missingFields.join(', ')}`);
                    } else {
                        validData.push(row);
                    }
                });
                
                setErrors(newErrors);
                setParsedData(validData);
                setStep(2);
                setIsProcessing(false);
            },
            error: (error) => {
                setErrors([`שגיאה בקריאת הקובץ: ${error.message}`]);
                setIsProcessing(false);
            }
        });
    };
    
    const handleImport = async () => {
        setIsProcessing(true);
        try {
            const result = await apiService.addMultipleUsers(parsedData);
            addToast(`${result.success} תלמידים יובאו בהצלחה!`, 'success');
            if(result.failures > 0) {
                addToast(`${result.failures} שורות נכשלו (ייתכן והטלפון של התלמיד כבר קיים).`, 'error');
            }
            onImportSuccess();
            handleClose();
        } catch (error) {
            addToast("שגיאה בייבוא הנתונים", "error");
            setIsProcessing(false);
        }
    };

    if (!isOpen) return null;
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={handleClose}>
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-gray-800">ייבוא רשימת תלמידים (CSV)</h2>
                    <button onClick={handleClose}><XIcon className="w-6 h-6 text-gray-400 hover:text-gray-600"/></button>
                </div>
                
                <div className="flex-grow overflow-y-auto">
                    {step === 1 && (
                        <div className="space-y-4">
                            <p>כדי לייבא רשימת תלמידים, יש להעלות קובץ CSV בפורמט הנכון. תוכלו להוריד קובץ תבנית לדוגמה.</p>
                             <div className="bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800 p-3 rounded-md text-sm my-3">
                                <strong>חשוב:</strong> בעת שמירת הקובץ ב-Excel, יש לבחור באפשרות 'CSV UTF-8'. הדבר יבטיח שהעברית תוצג כראוי.
                            </div>
                            <button onClick={handleDownloadTemplate} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                הורד קובץ תבנית (CSV)
                            </button>
                            <div className="mt-4">
                                <label className="block text-sm font-medium text-gray-700 mb-1">העלה את קובץ ה-CSV שלך:</label>
                                <input type="file" accept=".csv" onChange={handleFileChange} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"/>
                            </div>
                        </div>
                    )}
                    
                    {step === 2 && (
                        <div>
                           <h3 className="text-lg font-bold mb-2">תצוגה מקדימה ואימות</h3>
                           {errors.length > 0 && (
                               <div className="bg-red-50 border border-red-200 p-3 rounded-md mb-4 max-h-40 overflow-y-auto">
                                   <h4 className="font-bold text-red-800">שגיאות שנמצאו:</h4>
                                   <ul className="list-disc list-inside text-sm text-red-700">
                                       {errors.map((err, i) => <li key={i}>{err}</li>)}
                                   </ul>
                               </div>
                           )}
                           {parsedData.length > 0 && (
                               <div className="bg-green-50 border border-green-200 p-3 rounded-md max-h-40 overflow-y-auto">
                                   <h4 className="font-bold text-green-800">נמצאו {parsedData.length} תלמידים תקינים לייבוא:</h4>
                                    <ul className="list-disc list-inside text-sm text-green-700">
                                        {parsedData.slice(0, 5).map((row, i) => <li key={i}>{row.firstName} {row.lastName} - כיתה {row.class}</li>)}
                                        {parsedData.length > 5 && <li>...ועוד {parsedData.length - 5} תלמידים.</li>}
                                   </ul>
                               </div>
                           )}
                           {parsedData.length === 0 && errors.length > 0 && (
                               <p className="text-center text-gray-600">לא נמצאו רשומות תקינות לייבוא. אנא תקן את קובץ ה-CSV ונסה שוב.</p>
                           )}
                        </div>
                    )}
                </div>

                <div className="flex justify-end space-x-3 space-x-reverse pt-4 border-t mt-4">
                    {step === 1 && (
                        <button onClick={handleParseFile} disabled={!file || isProcessing} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-400">
                            {isProcessing ? 'מעבד...' : 'המשך לאימות'}
                        </button>
                    )}
                    {step === 2 && (
                        <>
                        <button onClick={() => setStep(1)} className="bg-white py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
                            חזור
                        </button>
                        <button onClick={handleImport} disabled={parsedData.length === 0 || isProcessing} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-400">
                            {isProcessing ? 'מייבא...' : `ייבא ${parsedData.length} תלמידים`}
                        </button>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

// --- Import Mentors Modal ---
const ImportMentorsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onImportSuccess: () => void;
}> = ({ isOpen, onClose, onImportSuccess }) => {
    const [step, setStep] = useState(1);
    const [file, setFile] = useState<File | null>(null);
    const [parsedData, setParsedData] = useState<any[]>([]);
    const [errors, setErrors] = useState<string[]>([]);
    const [isProcessing, setIsProcessing] = useState(false);
    const { addToast } = useToast();

    const resetState = useCallback(() => {
        setStep(1);
        setFile(null);
        setParsedData([]);
        setErrors([]);
        setIsProcessing(false);
    }, []);
    
    useEffect(() => {
        if(isOpen) resetState();
    }, [isOpen, resetState]);

    const handleClose = () => {
        resetState();
        onClose();
    };

    const handleDownloadTemplate = () => {
        const headers = "firstName,lastName,phone,role";
        const csvContent = `data:text/csv;charset=utf-8,${headers}\n`;
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "menaynim_staff_template.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    
    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setFile(e.target.files[0]);
        }
    };
    
    const handleParseFile = () => {
        if (!file) return;
        setIsProcessing(true);
        setErrors([]);
        setParsedData([]);

        Papa.parse(file, {
            header: true,
            skipEmptyLines: true,
            complete: (results) => {
                const newErrors: string[] = [];
                const validData: any[] = [];
                const requiredFields = ['firstName', 'lastName', 'phone', 'role'];

                results.data.forEach((row: any, index: number) => {
                    const missingFields = requiredFields.filter(field => !row[field] || !row[field].trim());
                    if (missingFields.length > 0) {
                        newErrors.push(`שורה ${index + 2}: חסרים שדות חובה: ${missingFields.join(', ')}`);
                    } else if (!['mentor', 'admin'].includes(row.role.toLowerCase())) {
                        newErrors.push(`שורה ${index + 2}: תפקיד לא חוקי. חייב להיות 'mentor' או 'admin'.`);
                    } else {
                        validData.push(row);
                    }
                });
                
                setErrors(newErrors);
                setParsedData(validData);
                setStep(2);
                setIsProcessing(false);
            },
            error: (error) => {
                setErrors([`שגיאה בקריאת הקובץ: ${error.message}`]);
                setIsProcessing(false);
            }
        });
    };
    
    const handleImport = async () => {
        setIsProcessing(true);
        try {
            const result = await apiService.addMultipleMentors(parsedData);
            addToast(`${result.success} אנשי צוות יובאו בהצלחה!`, 'success');
            onImportSuccess();
            handleClose();
        } catch (error) {
            addToast("שגיאה בייבוא הנתונים", "error");
            setIsProcessing(false);
        }
    };

    if (!isOpen) return null;
    
    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={handleClose}>
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-gray-800">ייבוא רשימת חונכים וצוות</h2>
                    <button onClick={handleClose}><XIcon className="w-6 h-6 text-gray-400 hover:text-gray-600"/></button>
                </div>
                
                <div className="flex-grow overflow-y-auto">
                    {step === 1 && (
                        <div className="space-y-4">
                            <p>העלה קובץ CSV עם פרטי אנשי הצוות. יש לוודא שהתפקיד (role) הוא 'mentor' או 'admin'.</p>
                             <div className="bg-yellow-50 border-l-4 border-yellow-400 text-yellow-800 p-3 rounded-md text-sm my-3">
                                <strong>חשוב:</strong> בעת שמירת הקובץ ב-Excel, יש לבחור באפשרות 'CSV UTF-8'. הדבר יבטיח שהעברית תוצג כראוי.
                            </div>
                            <button onClick={handleDownloadTemplate} className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
                                הורד קובץ תבנית (CSV)
                            </button>
                            <div className="mt-4">
                                <label className="block text-sm font-medium text-gray-700 mb-1">העלה את קובץ ה-CSV שלך:</label>
                                <input type="file" accept=".csv" onChange={handleFileChange} className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"/>
                            </div>
                        </div>
                    )}
                    
                    {step === 2 && (
                        <div>
                           <h3 className="text-lg font-bold mb-2">תצוגה מקדימה ואימות</h3>
                           {errors.length > 0 && (
                               <div className="bg-red-50 border border-red-200 p-3 rounded-md mb-4 max-h-40 overflow-y-auto">
                                   <h4 className="font-bold text-red-800">שגיאות שנמצאו:</h4>
                                   <ul className="list-disc list-inside text-sm text-red-700">
                                       {errors.map((err, i) => <li key={i}>{err}</li>)}
                                   </ul>
                               </div>
                           )}
                           {parsedData.length > 0 && (
                               <div className="bg-green-50 border border-green-200 p-3 rounded-md max-h-40 overflow-y-auto">
                                   <h4 className="font-bold text-green-800">נמצאו {parsedData.length} אנשי צוות תקינים לייבוא:</h4>
                                    <ul className="list-disc list-inside text-sm text-green-700">
                                        {parsedData.slice(0, 5).map((row, i) => <li key={i}>{row.firstName} {row.lastName} - תפקיד: {row.role}</li>)}
                                        {parsedData.length > 5 && <li>...ועוד {parsedData.length - 5}.</li>}
                                   </ul>
                               </div>
                           )}
                           {parsedData.length === 0 && errors.length > 0 && (
                               <p className="text-center text-gray-600">לא נמצאו רשומות תקינות לייבוא. אנא תקן את קובץ ה-CSV ונסה שוב.</p>
                           )}
                        </div>
                    )}
                </div>

                <div className="flex justify-end space-x-3 space-x-reverse pt-4 border-t mt-4">
                    {step === 1 && (
                        <button onClick={handleParseFile} disabled={!file || isProcessing} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-400">
                            {isProcessing ? 'מעבד...' : 'המשך לאימות'}
                        </button>
                    )}
                    {step === 2 && (
                        <>
                        <button onClick={() => setStep(1)} className="bg-white py-2 px-4 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50">
                            חזור
                        </button>
                        <button onClick={handleImport} disabled={parsedData.length === 0 || isProcessing} className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded disabled:bg-gray-400">
                            {isProcessing ? 'מייבא...' : `ייבא ${parsedData.length} אנשי צוות`}
                        </button>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};


// --- User Form Modal ---
type UserFormDataType = Partial<Omit<Student, 'role'>> & { role?: Role };

const UserFormModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (user: UserFormDataType) => void;
    isSubmitting: boolean;
    initialUser?: User | Student | null;
    allStudents: Student[];
    allMentors: User[];
}> = ({ isOpen, onClose, onSubmit, isSubmitting, initialUser, allStudents, allMentors }) => {
    
    const [formData, setFormData] = useState<UserFormDataType>({});

    useEffect(() => {
        if (isOpen) {
            if (initialUser) {
                setFormData(initialUser as UserFormDataType);
            } else {
                setFormData({ role: Role.Student, gender: 'other', rememberMe: false });
            }
        }
    }, [initialUser, isOpen]);
    
    if (!isOpen) return null;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };
    
    const handleStudentAssignmentChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const selectedIds = Array.from(e.target.selectedOptions, option => option.value);
        setFormData(prev => ({ ...prev, assignedStudentIds: selectedIds }));
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(formData);
    };

    const isEditing = !!initialUser;
    const role = formData.role;

    return (
         <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={onClose}>
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4">
                    <h2 className="text-2xl font-bold text-gray-800">{isEditing ? 'עריכת משתמש' : 'יצירת משתמש חדש'}</h2>
                    <button onClick={onClose}><XIcon className="w-6 h-6 text-gray-400 hover:text-gray-600"/></button>
                </div>
                <form onSubmit={handleFormSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-gray-700">שם פרטי</label>
                            <input type="text" name="firstName" value={formData.firstName || ''} onChange={handleChange} className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">שם משפחה</label>
                            <input type="text" name="lastName" value={formData.lastName || ''} onChange={handleChange} className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">טלפון</label>
                            <input type="tel" name="phone" value={formData.phone || ''} onChange={handleChange} className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" required />
                        </div>
                        <div>
                            <label className="block text-sm font-medium text-gray-700">תפקיד</label>
                            <select name="role" value={role} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                                <option value={Role.Student}>תלמיד/ה</option>
                                <option value={Role.Mentor}>חונך/ת</option>
                                <option value={Role.Admin}>אדמין</option>
                            </select>
                        </div>
                    </div>
                    
                    {role === Role.Student && (
                        <div className="p-4 bg-gray-50 rounded-md space-y-4 mt-4 border">
                            <h3 className="font-semibold text-gray-700">פרטי תלמיד/ה</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">כיתה</label>
                                    <input type="text" name="class" value={formData.class || ''} onChange={handleChange} className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" required />
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">מגדר</label>
                                     <select name="gender" value={formData.gender || 'other'} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                                        <option value="male">זכר</option>
                                        <option value="female">נקבה</option>
                                        <option value="other">אחר</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">שיוך לחונך/ת</label>
                                    <select name="mentorId" value={formData.mentorId || ''} onChange={handleChange} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md" required>
                                        <option value="">בחר חונך/ת</option>
                                        {allMentors.map(m => <option key={m.id} value={m.id}>{m.firstName} {m.lastName}</option>)}
                                    </select>
                                </div>
                            </div>
                        </div>
                    )}

                    {(role === Role.Mentor || role === Role.Admin) && (
                         <div className="p-4 bg-gray-50 rounded-md mt-4 border">
                            <h3 className="font-semibold text-gray-700">שיוך תלמידים</h3>
                             <div>
                                <label className="block text-sm font-medium text-gray-700">תלמידים משויכים (החזק Ctrl/Cmd לבחירה מרובה)</label>
                                <select 
                                    multiple 
                                    name="assignedStudentIds" 
                                    value={formData.assignedStudentIds || []} 
                                    onChange={handleStudentAssignmentChange} 
                                    className="mt-1 block w-full h-40 shadow-sm sm:text-sm border-gray-300 rounded-md"
                                >
                                    {allStudents.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName} ({s.class})</option>)}
                                </select>
                            </div>
                        </div>
                    )}
                    
                    <div className="flex justify-end space-x-3 space-x-reverse pt-4">
                        <button type="button" onClick={onClose} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">ביטול</button>
                        <button type="submit" disabled={isSubmitting} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400">
                           {isSubmitting ? 'שומר...' : (isEditing ? 'שמור שינויים' : 'צור משתמש')}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const AssignStudentsModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (mentorId: string, studentIds: string[]) => void;
    isSubmitting: boolean;
    mentor: User;
    allStudents: Student[];
}> = ({ isOpen, onClose, onSubmit, isSubmitting, mentor, allStudents }) => {
    const [selectedStudentIds, setSelectedStudentIds] = useState<Set<string>>(new Set());
    const [searchTerm, setSearchTerm] = useState('');
    const [classFilter, setClassFilter] = useState('all');

    useEffect(() => {
        if (isOpen) {
            setSelectedStudentIds(new Set(mentor.assignedStudentIds || []));
        }
    }, [isOpen, mentor]);

    if (!isOpen) return null;

    const handleToggleStudent = (studentId: string) => {
        const newSet = new Set(selectedStudentIds);
        if (newSet.has(studentId)) {
            newSet.delete(studentId);
        } else {
            newSet.add(studentId);
        }
        setSelectedStudentIds(newSet);
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onSubmit(mentor.id, Array.from(selectedStudentIds));
    };

    const allStudentClasses = ['all', ...Array.from(new Set(allStudents.map(s => s.class)))];

    const filteredStudents = allStudents.filter(student => {
        const nameMatch = `${student.firstName} ${student.lastName}`.toLowerCase().includes(searchTerm.toLowerCase());
        const classMatch = classFilter === 'all' || student.class === classFilter;
        return nameMatch && classMatch;
    });

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={onClose}>
            <form onSubmit={handleFormSubmit} className="bg-white rounded-lg shadow-xl p-6 w-full max-w-3xl max-h-[90vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                <div className="flex justify-between items-center mb-4 flex-shrink-0">
                    <div>
                        <h2 className="text-2xl font-bold text-gray-800">שיוך תלמידים</h2>
                        <p className="text-gray-600">עבור: {mentor.firstName} {mentor.lastName}</p>
                    </div>
                    <button type="button" onClick={onClose}><XIcon className="w-6 h-6 text-gray-400 hover:text-gray-600"/></button>
                </div>

                <div className="mb-4 space-y-2 flex-shrink-0">
                    <input 
                        type="text" 
                        placeholder="חפש תלמיד לפי שם..." 
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full p-2 border rounded-md text-sm"
                    />
                    <select
                        value={classFilter}
                        onChange={(e) => setClassFilter(e.target.value)}
                        className="w-full p-2 border rounded-md text-sm bg-white"
                    >
                        {allStudentClasses.map(c => (
                            <option key={c} value={c}>{c === 'all' ? 'כל הכיתות' : `כיתה ${c}`}</option>
                        ))}
                    </select>
                </div>

                <div className="flex-grow overflow-y-auto border rounded-lg p-2 bg-gray-50">
                    {filteredStudents.map(student => (
                        <label key={student.id} className="flex items-center p-2 rounded-md hover:bg-indigo-50 cursor-pointer">
                            <input 
                                type="checkbox"
                                checked={selectedStudentIds.has(student.id)}
                                onChange={() => handleToggleStudent(student.id)}
                                className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                            />
                            <span className="mr-3 text-gray-700">{student.firstName} {student.lastName} ({student.class})</span>
                        </label>
                    ))}
                </div>

                <div className="flex justify-end space-x-3 space-x-reverse pt-4 mt-4 border-t flex-shrink-0">
                    <button type="button" onClick={onClose} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">ביטול</button>
                    <button type="submit" disabled={isSubmitting} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400">
                       {isSubmitting ? 'שומר...' : 'שמור שינויים'}
                    </button>
                </div>
            </form>
        </div>
    );
};


// --- User Management View ---
const UserManagementView: React.FC<{
    onBack: () => void;
}> = ({ onBack }) => {
    const { addToast } = useToast();
    const { user: currentUser } = useAuth();
    const [users, setUsers] = useState<(User | Student)[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isFormModalOpen, setIsFormModalOpen] = useState(false);
    const [isAssignmentModalOpen, setIsAssignmentModalOpen] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [editingUser, setEditingUser] = useState<User | Student | null>(null);
    const [selectedMentor, setSelectedMentor] = useState<User | null>(null);
    const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
    const [userToDelete, setUserToDelete] = useState<User | Student | null>(null);
    const [activeTab, setActiveTab] = useState<'staff' | 'students'>('staff');

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const allUsers = await apiService.getAllUsers();
            setUsers(allUsers);
        } catch (error) {
            addToast("שגיאה בטעינת משתמשים", "error");
        } finally {
            setIsLoading(false);
        }
    }, [addToast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const { students, mentors } = useMemo(() => {
        const students = users.filter(u => u.role === Role.Student) as Student[];
        const mentors = users.filter(u => u.role === Role.Mentor || u.role === Role.Admin).sort((a, b) => a.lastName.localeCompare(b.lastName));
        const mentorMap = new Map(mentors.map(m => [m.id, `${m.firstName} ${m.lastName}`]));
        students.forEach(s => {
            (s as any).mentorName = mentorMap.get(s.mentorId) || 'לא משויך';
        });
        students.sort((a,b) => a.lastName.localeCompare(b.lastName));
        return { students, mentors };
    }, [users]);

    const handleCreateClick = () => {
        setEditingUser(null);
        setIsFormModalOpen(true);
    };

    const handleEditClick = (user: User | Student) => {
        setEditingUser(user);
        setIsFormModalOpen(true);
    };

    const handleAssignClick = (mentor: User) => {
        setSelectedMentor(mentor);
        setIsAssignmentModalOpen(true);
    };

    const handleDeleteClick = (user: User | Student) => {
        setUserToDelete(user);
        setIsConfirmModalOpen(true);
    };

    const handleConfirmDelete = async () => {
        if (!userToDelete) return;
        setIsSubmitting(true);
        try {
            await apiService.deleteUser(userToDelete.id);
            addToast("המשתמש נמחק בהצלחה");
            await fetchData();
            setIsConfirmModalOpen(false);
            setUserToDelete(null);
        } catch (error) {
            addToast("אירעה שגיאה במחיקת המשתמש", "error");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleFormSubmit = async (formData: UserFormDataType) => {
        setIsSubmitting(true);
        try {
            if (editingUser) { // Editing existing user
                await apiService.updateUser(editingUser.id, formData);
                addToast("המשתמש עודכן בהצלחה");
            } else { // Creating new user
                await apiService.addUser(formData);
                addToast("המשתמש נוצר בהצלחה");
            }
            await fetchData();
            setIsFormModalOpen(false);
        } catch (error) {
            addToast("אירעה שגיאה", "error");
        } finally {
            setIsSubmitting(false);
        }
    };

    const handleAssignmentSubmit = async (mentorId: string, studentIds: string[]) => {
        setIsSubmitting(true);
        try {
            await apiService.updateUser(mentorId, { assignedStudentIds: studentIds });
            addToast("השיוכים עודכנו בהצלחה");
            await fetchData();
            setIsAssignmentModalOpen(false);
        } catch (error) {
            addToast("שגיאה בעדכון השיוכים", "error");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-gray-50 p-4 sm:p-6 rounded-lg shadow-md min-h-screen flex flex-col">
            <header className="flex-shrink-0 flex justify-between items-center mb-6">
                <div>
                    <button onClick={onBack} className="flex items-center text-indigo-600 font-bold">
                        <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
                    </button>
                    <h2 className="text-2xl font-bold">ניהול משתמשים</h2>
                </div>
                <button onClick={handleCreateClick} className="flex items-center bg-indigo-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                    <PlusCircleIcon className="w-5 h-5 ml-1" />
                    <span>משתמש חדש</span>
                </button>
            </header>

            <div className="flex border-b mb-4">
                <button onClick={() => setActiveTab('staff')} className={`py-2 px-4 ${activeTab === 'staff' ? 'border-b-2 border-indigo-500 text-indigo-600 font-semibold' : 'text-gray-500'}`}>
                    צוות ({mentors.length})
                </button>
                <button onClick={() => setActiveTab('students')} className={`py-2 px-4 ${activeTab === 'students' ? 'border-b-2 border-indigo-500 text-indigo-600 font-semibold' : 'text-gray-500'}`}>
                    תלמידים ({students.length})
                </button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm flex-grow border overflow-y-auto">
                 {isLoading ? <LoadingSpinner /> : (
                    <>
                        {activeTab === 'staff' && (
                            <div className="space-y-3">
                                {mentors.map(mentor => (
                                    <div key={mentor.id} className="bg-gray-50 hover:bg-gray-100 p-3 rounded-lg border border-gray-200 flex justify-between items-center transition-colors">
                                        <div>
                                            <p className="font-bold text-indigo-800">{mentor.firstName} {mentor.lastName} <span className="text-xs font-normal bg-gray-200 px-2 py-0.5 rounded-full">{mentor.role === Role.Admin ? 'אדמין' : 'חונך'}</span></p>
                                            <p className="text-sm text-gray-600">משויכים: {mentor.assignedStudentIds?.length || 0} תלמידים</p>
                                        </div>
                                        <div className="flex items-center space-x-2 space-x-reverse">
                                            <button onClick={() => handleAssignClick(mentor)} className="text-sm bg-indigo-100 text-indigo-700 hover:bg-indigo-200 font-semibold py-1.5 px-3 rounded-md">
                                                שיוכים
                                            </button>
                                            <button onClick={() => handleEditClick(mentor)} className="p-2 text-gray-500 hover:text-indigo-600 rounded-md"><EditIcon className="w-5 h-5" /></button>
                                            <button onClick={() => handleDeleteClick(mentor)} disabled={mentor.id === currentUser?.id} className="p-2 text-gray-500 hover:text-red-600 rounded-md disabled:opacity-50 disabled:cursor-not-allowed"><TrashIcon className="w-5 h-5" /></button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}
                        {activeTab === 'students' && (
                            <div className="flow-root">
                                <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                    <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                                        <table className="min-w-full divide-y divide-gray-300">
                                            <thead>
                                                <tr>
                                                    <th scope="col" className="py-3.5 pr-4 pl-3 text-right text-sm font-semibold text-gray-900 sm:pr-6">שם</th>
                                                    <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-gray-900">כיתה</th>
                                                    <th scope="col" className="px-3 py-3.5 text-right text-sm font-semibold text-gray-900">חונך משויך</th>
                                                    <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6"><span className="sr-only">פעולות</span></th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-200 bg-white">
                                                {students.map(student => (
                                                    <tr key={student.id}>
                                                        <td className="whitespace-nowrap py-4 pr-4 pl-3 text-sm font-medium text-gray-900 sm:pr-6">{student.firstName} {student.lastName}</td>
                                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{student.class}</td>
                                                        <td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{(student as any).mentorName}</td>
                                                        <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                                                            <button onClick={() => handleEditClick(student)} className="text-indigo-600 hover:text-indigo-900">ערוך<span className="sr-only">, {student.firstName}</span></button>
                                                            <button onClick={() => handleDeleteClick(student)} className="text-red-600 hover:text-red-900 mr-4">מחק<span className="sr-only">, {student.firstName}</span></button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}
                    </>
                 )}
            </div>
            
            <UserFormModal
                isOpen={isFormModalOpen}
                onClose={() => setIsFormModalOpen(false)}
                onSubmit={handleFormSubmit}
                isSubmitting={isSubmitting}
                initialUser={editingUser}
                allStudents={students}
                allMentors={mentors}
            />

            {selectedMentor && (
                <AssignStudentsModal
                    isOpen={isAssignmentModalOpen}
                    onClose={() => setIsAssignmentModalOpen(false)}
                    onSubmit={handleAssignmentSubmit}
                    isSubmitting={isSubmitting}
                    mentor={selectedMentor}
                    allStudents={students}
                />
            )}
            
            <ConfirmationModal
                isOpen={isConfirmModalOpen}
                onClose={() => setIsConfirmModalOpen(false)}
                onConfirm={handleConfirmDelete}
                isProcessing={isSubmitting}
                userName={userToDelete ? `${userToDelete.firstName} ${userToDelete.lastName}` : ''}
            />

        </div>
    );
};

// --- Feedback View ---
const FeedbackView: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const { addToast } = useToast();
    const [isLoading, setIsLoading] = useState(true);
    const [feedbackItems, setFeedbackItems] = useState<Feedback[]>([]);
    const [activeTab, setActiveTab] = useState<FeedbackStatus>('new');
    const [processingId, setProcessingId] = useState<string | null>(null);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const items = await apiService.getAllFeedback();
            setFeedbackItems(items);
        } catch (error) {
            addToast("שגיאה בטעינת המשובים", "error");
        } finally {
            setIsLoading(false);
        }
    }, [addToast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleStatusChange = async (id: string, newStatus: FeedbackStatus) => {
        setProcessingId(id);
        try {
            await apiService.updateFeedbackStatus(id, newStatus);
            addToast(newStatus === 'archived' ? 'המשוב הועבר לארכיון' : 'המשוב שוחזר', 'success');
            await fetchData();
        } catch {
            addToast('שגיאה בעדכון סטטוס המשוב', 'error');
        } finally {
            setProcessingId(null);
        }
    };

    const { newItems, archivedItems } = useMemo(() => {
        const newItems = feedbackItems.filter(item => item.status === 'new');
        const archivedItems = feedbackItems.filter(item => item.status === 'archived');
        return { newItems, archivedItems };
    }, [feedbackItems]);
    
    const displayedItems = activeTab === 'new' ? newItems : archivedItems;

    const feedbackTypeDetails: { [key in FeedbackType]: { label: string; icon: React.ReactNode; borderColor: string; bgColor: string; textColor: string; } } = {
        comment: { label: 'הערה כללית', icon: <MessageSquareQuoteIcon className="w-4 h-4" />, borderColor: 'border-blue-400', bgColor: 'bg-blue-100', textColor: 'text-blue-800' },
        feature: { label: 'בקשת פיצ\'ר', icon: <LightbulbIcon className="w-4 h-4" />, borderColor: 'border-yellow-400', bgColor: 'bg-yellow-100', textColor: 'text-yellow-800' },
        bug: { label: 'דיווח על באג', icon: <AlertTriangleIcon className="w-4 h-4" />, borderColor: 'border-red-400', bgColor: 'bg-red-100', textColor: 'text-red-800' },
    };

    return (
        <div className="bg-gray-50 p-4 sm:p-6 rounded-lg shadow-md min-h-screen flex flex-col">
            <header className="flex-shrink-0 flex justify-between items-center mb-6">
                <div>
                    <button onClick={onBack} className="flex items-center text-indigo-600 font-bold">
                        <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
                    </button>
                    <h2 className="text-2xl font-bold">מרכז משוב</h2>
                </div>
            </header>

            <div className="flex border-b mb-4">
                <button onClick={() => setActiveTab('new')} className={`py-2 px-4 ${activeTab === 'new' ? 'border-b-2 border-indigo-500 text-indigo-600 font-semibold' : 'text-gray-500'}`}>
                    חדש ({newItems.length})
                </button>
                <button onClick={() => setActiveTab('archived')} className={`py-2 px-4 ${activeTab === 'archived' ? 'border-b-2 border-indigo-500 text-indigo-600 font-semibold' : 'text-gray-500'}`}>
                    ארכיון ({archivedItems.length})
                </button>
            </div>

            <div className="bg-white p-4 rounded-lg shadow-sm flex-grow border overflow-y-auto">
                {isLoading ? <LoadingSpinner /> : (
                    displayedItems.length > 0 ? (
                        <div className="space-y-4">
                            {displayedItems.map(item => {
                                const typeInfo = feedbackTypeDetails[item.type];
                                return (
                                    <div key={item.id} className={`bg-white p-4 rounded-lg shadow-md border-l-4 ${typeInfo.borderColor}`}>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <div className="flex items-center space-x-2 space-x-reverse mb-1">
                                                     <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${typeInfo.bgColor} ${typeInfo.textColor}`}>
                                                        {typeInfo.icon}
                                                        <span className="mr-1.5">{typeInfo.label}</span>
                                                    </span>
                                                    <span className="text-sm font-bold text-gray-800">{item.userName}</span>
                                                    <span className="text-xs text-gray-500">({item.userRole})</span>
                                                </div>
                                                <p className="text-xs text-gray-500">
                                                    {new Date(item.date).toLocaleString('he-IL', { dateStyle: 'short', timeStyle: 'short' })}
                                                </p>
                                            </div>
                                            {activeTab === 'new' ? (
                                                <button onClick={() => handleStatusChange(item.id, 'archived')} disabled={processingId === item.id} className="flex items-center text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-1.5 px-3 rounded-md transition-colors disabled:opacity-50">
                                                    <ArchiveIcon className="w-4 h-4 ml-1.5"/>
                                                    <span>שלח לארכיון</span>
                                                </button>
                                            ) : (
                                                <button onClick={() => handleStatusChange(item.id, 'new')} disabled={processingId === item.id} className="flex items-center text-sm bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold py-1.5 px-3 rounded-md transition-colors disabled:opacity-50">
                                                    <CornerUpLeftIcon className="w-4 h-4 ml-1.5"/>
                                                    <span>שחזר</span>
                                                </button>
                                            )}
                                        </div>
                                        <p className="mt-3 text-gray-700 whitespace-pre-wrap">{item.message}</p>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                         <p className="text-center text-gray-500 py-16">אין פריטים להצגה.</p>
                    )
                )}
            </div>
        </div>
    );
};

const AdminPanel: React.FC<{ 
    onManageUsersClick: () => void;
    onImportStudentsClick: () => void;
    onImportMentorsClick: () => void;
    onFeedbackCenterClick: () => void;
    onImportBackupClick: () => void;
}> = ({ onManageUsersClick, onImportStudentsClick, onImportMentorsClick, onFeedbackCenterClick, onImportBackupClick }) => {
    const { logout } = useAuth();
    const { addToast } = useToast();
    
    const handleResetData = async () => {
        if(window.confirm('האם אתה בטוח שברצונך לאפס את כל נתוני האפליקציה? פעולה זו אינה הפיכה.')) {
            await apiService.resetData();
            addToast('הנתונים אופסו בהצלחה. המערכת תתנתק כעת.', 'info');
            setTimeout(() => {
                logout();
                window.location.reload();
            }, 2000);
        }
    }
    
    return (
        <div className="bg-white p-4 rounded-lg shadow-md mt-6">
            <h2 className="text-xl font-bold text-gray-800 mb-4 border-b pb-2 flex items-center"><UsersIcon className="w-6 h-6 mr-2"/>Admin Panel</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <button onClick={onManageUsersClick} className="w-full text-right bg-indigo-100 hover:bg-indigo-200 text-indigo-800 font-bold py-2 px-4 rounded">
                    ניהול משתמשים ושיוכים
                </button>
                <button onClick={onFeedbackCenterClick} className="w-full text-right bg-blue-100 hover:bg-blue-200 text-blue-800 font-bold py-2 px-4 rounded flex items-center">
                    <MessageSquareQuoteIcon className="w-5 h-5 ml-2" />
                    <span>מרכז משוב</span>
                </button>
                <button onClick={onImportStudentsClick} className="w-full text-right bg-green-100 hover:bg-green-200 text-green-800 font-bold py-2 px-4 rounded flex items-center">
                    <UploadCloudIcon className="w-5 h-5 ml-2" />
                    <span>ייבוא רשימת תלמידים</span>
                </button>
                 <button onClick={onImportMentorsClick} className="w-full text-right bg-teal-100 hover:bg-teal-200 text-teal-800 font-bold py-2 px-4 rounded flex items-center">
                    <UploadCloudIcon className="w-5 h-5 ml-2" />
                    <span>ייבוא רשימת חונכים וצוות</span>
                </button>
                <button onClick={onImportBackupClick} className="w-full text-right bg-purple-100 hover:bg-purple-200 text-purple-800 font-bold py-2 px-4 rounded flex items-center">
                    <UploadCloudIcon className="w-5 h-5 ml-2" />
                    <span>ייבא והצג גיבוי חונך</span>
                </button>
                <button onClick={handleResetData} className="w-full text-right bg-red-100 hover:bg-red-200 text-red-800 font-bold py-2 px-4 rounded">
                    איפוס כללי של נתוני האפליקציה
                </button>
            </div>
        </div>
    );
};

const AdminPanelScreen: React.FC = () => {
    const [view, setView] = useState<'main' | 'user-management' | 'feedback'>('main');
    const [isImportStudentsModalOpen, setIsImportStudentsModalOpen] = useState(false);
    const [isImportMentorsModalOpen, setIsImportMentorsModalOpen] = useState(false);
    const { setAdminView, startImpersonation } = useAuth();
    const fileInputRef = React.useRef<HTMLInputElement>(null);

    const handleImportBackupClick = () => {
        fileInputRef.current?.click();
    };

    const handleFileSelected = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const jsonData = await file.text();
        await startImpersonation(jsonData);
        
        // Reset file input
        if(event.target) {
            event.target.value = '';
        }
    };
    
    if (view === 'user-management') {
        return <UserManagementView onBack={() => setView('main')} />;
    }

    if (view === 'feedback') {
        return <FeedbackView onBack={() => setView('main')} />;
    }

    return (
        <div className="p-4">
            <button onClick={() => setAdminView(false)} className="flex items-center text-indigo-600 font-bold mb-4">
                <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור לדשבורד</span>
            </button>
            <AdminPanel 
                onManageUsersClick={() => setView('user-management')}
                onImportStudentsClick={() => setIsImportStudentsModalOpen(true)}
                onImportMentorsClick={() => setIsImportMentorsModalOpen(true)}
                onFeedbackCenterClick={() => setView('feedback')}
                onImportBackupClick={handleImportBackupClick}
            />
             <input 
                type="file" 
                ref={fileInputRef} 
                style={{ display: 'none' }} 
                accept=".json"
                onChange={handleFileSelected}
            />
            <ImportStudentsModal
                isOpen={isImportStudentsModalOpen}
                onClose={() => setIsImportStudentsModalOpen(false)}
                onImportSuccess={() => {}}
            />
             <ImportMentorsModal
                isOpen={isImportMentorsModalOpen}
                onClose={() => setIsImportMentorsModalOpen(false)}
                onImportSuccess={() => {}}
            />
        </div>
    );
}

export default AdminPanelScreen;
