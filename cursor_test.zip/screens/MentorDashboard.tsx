

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { useAuth } from '../hooks/useAuth';
import { Student, MoodRecord, Session, VoiceNote, User, Tool, ToolType, Intervention, InterventionStatus, AlertSeverity, Role, Alert } from '../types';
import apiService from '../services/apiService';
import { getActionRecommendation, getConsultationAdvice } from '../services/geminiService';
import { useSpeechRecognition } from '../hooks/useSpeechRecognition';
import { useToast } from '../hooks/useToast';
import { UsersIcon, CalendarIcon, BarChartIcon, AlertTriangleIcon, ChevronLeftIcon, MailIcon, PhoneIcon, FileTextIcon, MicIcon, XIcon, SmileIcon, Users2Icon, BookOpenIcon, HomeIcon, BriefcaseIcon, BookCheckIcon, CheckCircleIcon, SparklesIcon, EyeIcon, StarIcon, EditIcon, ChevronDownIcon, LightbulbIcon, PlayCircleIcon, PlusCircleIcon } from '../components/Icons';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import CalendarView from './CalendarView';
import WellbeingForm, { WellbeingFormData } from '../components/WellbeingForm';

const formatDateWithDay = (isoString: string) => {
    if (!isoString) return '';
    return new Date(isoString).toLocaleDateString('he-IL', {
        weekday: 'short', year: 'numeric', month: 'numeric', day: 'numeric'
    });
};

const formatDateTimeWithDay = (isoString: string) => {
    if (!isoString) return '';
    return new Date(isoString).toLocaleString('he-IL', {
        weekday: 'short', year: 'numeric', month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
};

const LoadingSpinner: React.FC = () => (
    <div className="flex justify-center items-center p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
    </div>
);

const DashboardCard: React.FC<{
    title: string;
    indicator: number | string;
    icon: React.ReactNode;
    onClick: () => void;
    className?: string;
}> = ({ title, indicator, icon, onClick, className }) => (
    <button
        onClick={onClick}
        className={`relative rounded-2xl shadow-lg p-4 w-full aspect-square flex flex-col justify-between items-center hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden ${className}`}
    >
        <div className="w-full flex justify-start">
            <span className="bg-black bg-opacity-20 text-xs font-bold py-1 px-2.5 rounded-full">
                {indicator}
            </span>
        </div>
        
        <div className="flex flex-col items-center justify-center gap-2 flex-grow">
            <div className="text-gray-700">
                {icon}
            </div>
            <h3 className="text-base sm:text-lg font-bold text-center">{title}</h3>
        </div>
    </button>
);


const AddImpressionModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (transcription: string) => void;
    isSubmitting: boolean;
}> = ({ isOpen, onClose, onSubmit, isSubmitting }) => {
    const [transcription, setTranscription] = useState('');
    const {
        text,
        interimText,
        isListening,
        startListening,
        stopListening,
        hasRecognitionSupport,
        error: speechError
    } = useSpeechRecognition();

    useEffect(() => {
        if (text) {
            setTranscription(prev => (prev ? prev.trim() + ' ' : '') + text);
        }
    }, [text]);

    if (!isOpen) return null;

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (transcription.trim()) {
            onSubmit(transcription);
            setTranscription('');
        }
    };

    const handleClose = () => {
        stopListening();
        setTranscription('');
        onClose();
    };

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4" onClick={handleClose}>
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-lg" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-2xl font-bold mb-4 text-gray-800">הוספת התרשמות / פעולה</h2>
                <form onSubmit={handleFormSubmit}>
                    <div className="relative">
                        <textarea
                            value={transcription + (interimText ? ' ' + interimText : '')}
                            onChange={(e) => setTranscription(e.target.value)}
                            placeholder="רשום כאן את סיכום הפגישה, או לחץ על המיקרופון כדי להתחיל תמלול..."
                            rows={6}
                            className="w-full p-2 pr-4 border rounded-md mb-2 text-base"
                            required
                        />
                        {hasRecognitionSupport && (
                             <button
                                type="button"
                                onClick={isListening ? stopListening : startListening}
                                className={`absolute bottom-4 left-3 p-2 rounded-full transition-colors ${
                                    isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                                }`}
                                title={isListening ? 'הפסק הקלטה' : 'התחל הקלטה'}
                            >
                                <MicIcon className="w-5 h-5" />
                            </button>
                        )}
                    </div>
                     {speechError && <p className="text-xs text-red-500 mb-2">{speechError}</p>}
                    <div className="flex justify-end space-x-3 space-x-reverse">
                        <button type="button" onClick={handleClose} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50">ביטול</button>
                        <button type="submit" disabled={isSubmitting || isListening} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400">
                            {isSubmitting ? 'שומר...' : 'שמור'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

const ReportDetailModal: React.FC<{ 
    data: { record: MoodRecord; session?: Session }; 
    onClose: () => void; 
    tools: Tool[];
}> = ({ data, onClose, tools }) => {
    const { record, session } = data;
    
    const DetailRow: React.FC<{ label: string, score: number | null, evidence: string, Icon: React.FC<{className?: string}>, color: string }> = ({ label, score, evidence, Icon, color }) => (
        <div>
            <div className="flex items-center mb-1">
                <Icon className={`w-5 h-5 ml-2 ${color}`} />
                <p className="font-bold">{label}: {score !== null ? <span className={color}>{score}/10</span> : <span className="text-gray-500 font-normal">לא דורג</span>}</p>
            </div>
            {score !== null && <p className="text-sm text-gray-600 pr-2 border-r-2 border-gray-200 mr-2">{evidence || 'לא צוינה עדות'}</p>}
        </div>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={onClose} dir="rtl">
            <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-lg relative" onClick={(e) => e.stopPropagation()}>
                 <button onClick={onClose} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors">
                     <XIcon className="w-6 h-6" />
                 </button>
                <h2 className="text-2xl font-bold mb-2 text-gray-900">
                    פרטי דיווח - {formatDateWithDay(record.date)}
                </h2>
                <div className="text-center my-6">
                    <p className="text-gray-500 text-sm">ממוצע דיווח</p>
                    <p className={`text-6xl font-bold ${record.averageScore > 7 ? 'text-green-500' : record.averageScore < 5 ? 'text-red-500' : 'text-yellow-500'}`}>
                        {record.averageScore.toFixed(1)}
                    </p>
                </div>
                <div className="space-y-4">
                    <DetailRow label="חברתי" score={record.socialScore} evidence={record.socialEvidence} Icon={Users2Icon} color="text-green-500" />
                    <DetailRow label="לימודי" score={record.academicScore} evidence={record.academicEvidence} Icon={BookOpenIcon} color="text-orange-500" />
                    <DetailRow label="רגשי" score={record.emotionalScore} evidence={record.emotionalEvidence} Icon={SmileIcon} color="text-blue-500" />
                    <DetailRow label="בגדול" score={record.personalScore} evidence={record.personalEvidence} Icon={HomeIcon} color="text-purple-500" />
                </div>
                
                {session && (session.mentorImpression || session.usedToolId) && (
                    <div className="mt-6 pt-4 border-t">
                        <h3 className="text-lg font-bold text-gray-800 mb-2">התרשמות החונך מהפגישה</h3>
                        {session.mentorImpression && (
                            <p className="text-sm text-gray-600 whitespace-pre-wrap">{session.mentorImpression}</p>
                        )}
                        {session.usedToolId && (
                            <div className="mt-2">
                                <span className="font-semibold text-sm">כלי בשימוש: </span>
                                <span className="text-sm text-indigo-600">{tools.find(t => t.id.toString() === session.usedToolId)?.name || 'לא ידוע'}</span>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
};

const StudentDetailsModal: React.FC<{ student: Student; onClose: () => void; }> = ({ student, onClose }) => {
    const [mentorName, setMentorName] = useState('טוען...');
    useEffect(() => {
        apiService.getUserById(student.mentorId).then(mentorUser => {
            setMentorName(mentorUser ? `${mentorUser.firstName} ${mentorUser.lastName}` : 'לא משויך');
        });
    }, [student.mentorId]);

    const DetailItem: React.FC<{ icon: React.ReactNode, label: string, value?: string }> = ({ icon, label, value }) => (
        value ? (
            <div className="flex items-start space-x-2 space-x-reverse text-sm">
                <div className="text-gray-500 mt-1">{icon}</div>
                <div>
                    <span className="font-semibold text-gray-800">{label}:</span>
                    <span className="text-gray-600 mr-1 whitespace-pre-wrap">{value}</span>
                </div>
            </div>
        ) : null
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={onClose} dir="rtl">
            <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-lg relative" onClick={(e) => e.stopPropagation()}>
                 <button onClick={onClose} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors">
                     <XIcon className="w-6 h-6" />
                 </button>
                <h2 className="text-2xl font-bold mb-4 text-gray-900">
                    פרטים כלליים
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4">
                    <div className="space-y-3">
                        <DetailItem icon={<UsersIcon className="w-4 h-4"/>} label="חונך" value={mentorName} />
                        <DetailItem icon={<PhoneIcon className="w-4 h-4"/>} label="טלפון תלמיד/ה" value={student.phone} />
                        <DetailItem icon={<MailIcon className="w-4 h-4"/>} label="אימייל תלמיד/ה" value={student.email} />
                    </div>
                     <div className="space-y-3">
                        <DetailItem icon={<PhoneIcon className="w-4 h-4"/>} label="טלפון הורה" value={student.parentPhone} />
                        <DetailItem icon={<MailIcon className="w-4 h-4"/>} label="אימייל הורה" value={student.parentEmail} />
                    </div>
                </div>
                {student.notes && <div className="mt-4 pt-4 border-t"><DetailItem icon={<FileTextIcon className="w-4 h-4"/>} label="הערות כלליות" value={student.notes} /></div>}
            </div>
        </div>
    );
};

const StudentProfileView: React.FC<{ student: Student; onBack: () => void; }> = ({ student, onBack }) => {
    const { user: mentor } = useAuth();
    const { addToast } = useToast();
    const [isLoading, setIsLoading] = useState(true);
    const [isCreatingReport, setIsCreatingReport] = useState(false);
    const [reportingForSession, setReportingForSession] = useState<Session | null>(null);
    const [isSubmittingReport, setIsSubmittingReport] = useState(false);
    const [data, setData] = useState<{
        moodRecords: MoodRecord[];
        sessions: Session[];
        voiceNotes: VoiceNote[];
        interventions: Intervention[];
        tools: Tool[];
        users: { [id: string]: User };
    } | null>(null);

    const [reportModalData, setReportModalData] = useState<{ record: MoodRecord; session?: Session } | null>(null);
    const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false);

    const fetchData = useCallback(async () => {
        setIsLoading(true);
        try {
            const [moodRecords, sessions, voiceNotes, interventions, tools, mentorUser] = await Promise.all([
                apiService.getMoodRecordsForStudent(student.id),
                apiService.getSessionsForStudent(student.id),
                apiService.getVoiceNotesForStudent(student.id),
                apiService.getInterventionsForStudent(student.id),
                apiService.getTools(),
                apiService.getUserById(student.mentorId)
            ]);
            
            const userIds = new Set([
              ...voiceNotes.map(vn => vn.mentorId),
              ...interventions.map(i => i.mentorId)
            ]);
            const usersPromises = Array.from(userIds).map(id => apiService.getUserById(id));
            const usersList = await Promise.all(usersPromises);
            const users = usersList.reduce((acc, u) => u ? ({...acc, [u.id]: u}) : acc, {});
            
            if(mentorUser) users[mentorUser.id] = mentorUser;
            
            setData({ moodRecords, sessions, voiceNotes, interventions, tools, users });
        } catch (error) {
            console.error("Failed to fetch student profile data:", error);
            addToast("שגיאה בטעינת פרופיל התלמיד", "error");
        } finally {
            setIsLoading(false);
        }
    }, [student.id, addToast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const { combinedHistory, globalAverage, reversedMoodRecords, chartData } = useMemo(() => {
        if (!data) return { combinedHistory: [], globalAverage: 'N/A', reversedMoodRecords: [], chartData: [] };
        
        const toolsMap = new Map(data.tools.map(t => [t.id, t]));
        
        const historyItems: (
          { type: 'session'; itemData: Session } | 
          { type: 'mood_independent'; itemData: MoodRecord } |
          { type: 'intervention'; itemData: Intervention & { toolTitle?: string } }
        )[] = [];
        
        data.sessions.forEach(s => historyItems.push({ type: 'session', itemData: s }));
        data.moodRecords.filter(r => !r.sessionId).forEach(r => historyItems.push({ type: 'mood_independent', itemData: r }));
        data.interventions.forEach(i => historyItems.push({ type: 'intervention', itemData: {...i, toolTitle: toolsMap.get(Number(i.toolId))?.name } }));

        const combinedHistory = historyItems.sort((a, b) => new Date(b.itemData.date).getTime() - new Date(a.itemData.date).getTime());

        const globalAverage = data.moodRecords.length === 0 ? 'N/A' : (data.moodRecords.reduce((acc, record) => acc + record.averageScore, 0) / data.moodRecords.length).toFixed(1);
        
        const reversedMoodRecords = [...data.moodRecords].reverse();

        const chartData = reversedMoodRecords.map(r => ({
            name: new Date(r.date).toLocaleDateString('he-IL', { month: 'short', day: 'numeric' }),
            'ממוצע': r.averageScore,
            isIndependent: !r.sessionId,
            recordId: r.id,
        }));
        
        return { combinedHistory, globalAverage, reversedMoodRecords, chartData };
    }, [data]);
    
    const [isImpressionModalOpen, setIsImpressionModalOpen] = useState(false);
    const [isSubmittingImpression, setIsSubmittingImpression] = useState(false);

    const handleBarClick = async (_data: any, index: number) => {
        if (!data) return;
        const clickedRecord = reversedMoodRecords[index];
        if (clickedRecord) {
            const associatedSession = clickedRecord.sessionId ? await apiService.getSessionById(clickedRecord.sessionId) : undefined;
            setReportModalData({ record: clickedRecord, session: associatedSession });
        }
    };
    
    const handleHistoryClick = async (record: MoodRecord) => {
         const associatedSession = record.sessionId ? await apiService.getSessionById(record.sessionId) : undefined;
         setReportModalData({ record, session: associatedSession });
    };

    const handleAddImpression = async (transcription: string) => {
        if (!mentor) return;
        setIsSubmittingImpression(true);
        try {
            await apiService.addVoiceNote({
                studentId: student.id,
                mentorId: mentor.id,
                date: new Date().toISOString(),
                transcription: transcription
            });
            addToast('ההתרשמות נשמרה בהצלחה');
            await fetchData();
        } catch (error) {
            addToast("שגיאה בשמירת ההתרשמות", "error");
        } finally {
            setIsSubmittingImpression(false);
            setIsImpressionModalOpen(false);
        }
    };
    
    const handleCreateReportSubmit = async (recordData: WellbeingFormData) => {
        if (!mentor) return;
        setIsSubmittingReport(true);
        try {
            await apiService.addSessionWithReport(recordData, mentor.id);
            addToast('הדיווח והמפגש נוצרו בהצלחה!');
            setIsCreatingReport(false);
            await fetchData();
        } catch(error) {
            addToast("שגיאה ביצירת הדיווח", "error");
        } finally {
            setIsSubmittingReport(false);
        }
    };

    const handleUpdateSessionReportSubmit = async (recordData: WellbeingFormData) => {
        if (!mentor || !reportingForSession) return;
        setIsSubmittingReport(true);
        try {
            await apiService.addReportToExistingSession(reportingForSession.id, recordData);
            addToast('הדיווח עודכן בהצלחה!');
            setReportingForSession(null);
            await fetchData();
        } catch (error) {
            addToast("שגיאה בעדכון הדיווח", "error");
        } finally {
            setIsSubmittingReport(false);
        }
    };
    
    if (isLoading) return <div className="p-4"><LoadingSpinner /></div>;
    if (!data) return <p className="p-4 text-center text-red-500">שגיאה בטעינת נתונים</p>;

    const isReporting = isCreatingReport || !!reportingForSession;

    const viewContent = isReporting ? (
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
            <button onClick={() => { setIsCreatingReport(false); setReportingForSession(null); }} className="flex items-center text-indigo-600 font-bold mb-4">
                <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
            </button>
            <h2 className="text-2xl font-bold mb-1">
                 {isCreatingReport ? "דיווח מ'מצב חדש (מפגש ספונטני)" : `הוספת דיווח לפגישה מיום ${formatDateWithDay(reportingForSession!.date)}`}
            </h2>
            <p className="text-lg text-gray-600 mb-4">עבור: {student.firstName} {student.lastName}</p>
            <WellbeingForm 
                student={student} 
                onSubmit={reportingForSession ? handleUpdateSessionReportSubmit : handleCreateReportSubmit}
                isSubmitting={isSubmittingReport} 
                onCancel={() => { setIsCreatingReport(false); setReportingForSession(null); }} 
                role={mentor!.role} 
                tools={data.tools}
            />
        </div>
    ) : (
        <div className="space-y-6">
            <header className="pb-4 border-b flex justify-between items-center">
                <div>
                    <h2 className="text-3xl font-bold text-gray-900">{student.firstName} {student.lastName}</h2>
                    <p className="text-lg text-gray-500">{student.class}</p>
                </div>
                <button onClick={() => setIsDetailsModalOpen(true)} className="bg-white text-indigo-600 border border-indigo-300 font-bold py-2 px-4 rounded-lg hover:bg-indigo-50 transition-colors">פרטים</button>
            </header>
            
            <div className="bg-white p-6 rounded-xl shadow-lg">
                 <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-800">התרשמויות ופעולות</h3>
                     <button onClick={() => setIsImpressionModalOpen(true)} className="flex items-center bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors"><MicIcon className="w-5 h-5 ml-2"/><span>הוסף התרשמות</span></button>
                </div>
                 <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                    {data.voiceNotes.length > 0 ? (
                        [...data.voiceNotes].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(note => {
                            const author = data.users[note.mentorId];
                            const authorName = author ? `${author.firstName} ${author.lastName}` : 'לא ידוע';
                            return (
                                <div key={note.id} className="bg-indigo-50 p-4 rounded-lg border-r-4 border-indigo-400">
                                    <p className="text-sm font-semibold text-gray-600 mb-1">
                                        {formatDateTimeWithDay(note.date)} <span className="font-normal text-gray-500">(נרשם ע"י: {authorName})</span>
                                    </p>
                                    <p className="text-gray-800">{note.transcription}</p>
                                </div>
                            );
                        })
                    ) : <p className="text-center text-gray-500 py-4">אין התרשמויות רשומות.</p>}
                </div>
            </div>
            
             <div className="bg-white p-6 rounded-xl shadow-lg">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-800">ציר הזמן של ההתקדמות</h3>
                    <button onClick={() => setIsCreatingReport(true)} className="bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors text-sm">צור מ'מצב חדש</button>
                </div>
                 <div className="flex items-baseline justify-between mb-4">
                    <div className="flex items-baseline space-x-4 space-x-reverse">
                        <div className="text-lg">ממוצע כללי:</div>
                        <div className="text-3xl font-bold text-indigo-600">{globalAverage}</div>
                    </div>
                    {data.moodRecords.length > 0 && <p className="text-sm text-gray-500">נכון לתאריך {formatDateWithDay(data.moodRecords[0].date)}</p>}
                 </div>
                 <div className="h-72 w-full">
                     <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={chartData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis domain={[0, 10]} allowDecimals={false} />
                            <Tooltip cursor={{ fill: 'rgba(238, 242, 255, 0.6)' }} contentStyle={{ backgroundColor: '#fff', border: '1px solid #ddd', borderRadius: '0.5rem', direction: 'rtl' }} labelStyle={{ fontWeight: 'bold' }} formatter={(value, name, props) => { const payload = props.payload; return [`${(value as number).toFixed(1)}`, payload.isIndependent ? 'דיווח עצמאי' : 'מפגש עם חונך']; }} />
                            <Bar dataKey="ממוצע" radius={[4, 4, 0, 0]} onClick={handleBarClick} cursor="pointer">
                                {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.isIndependent ? '#fb7185' : '#818cf8'} />)}
                            </Bar>
                        </BarChart>
                    </ResponsiveContainer>
                    <div className="flex justify-center items-center space-x-6 space-x-reverse -mt-4 text-sm text-gray-600">
                        <div className="flex items-center"><span className="w-3 h-3 rounded-sm bg-[#818cf8] ml-2"></span><span>מפגש עם חונך</span></div>
                        <div className="flex items-center"><span className="w-3 h-3 rounded-sm bg-[#fb7185] ml-2"></span><span>דיווח עצמאי</span></div>
                    </div>
                </div>
                <div className="space-y-4 max-h-96 overflow-y-auto p-1 mt-6 border-t pt-4">
                    {combinedHistory.length > 0 ? (
                        combinedHistory.map((historyItem, index) => {
                            if (historyItem.type === 'session') {
                                const session = historyItem.itemData;
                                const linkedRecord = data.moodRecords.find(r => r.sessionId === session.id);
                                const isPastAndUnreported = new Date(session.date) < new Date(new Date().setHours(0,0,0,0)) && !linkedRecord;
                                const isFuture = new Date(session.date) >= new Date(new Date().setHours(0,0,0,0));
                                
                                return linkedRecord ? (
                                     <button 
                                        key={`session-${session.id}-${index}`}
                                        onClick={() => handleHistoryClick(linkedRecord)}
                                        className="w-full text-right bg-green-50 p-3 rounded-lg hover:shadow-md transition-shadow flex justify-between items-center border border-green-200"
                                    >
                                        <div className="flex items-center space-x-4 space-x-reverse">
                                            <div className="text-center bg-green-200 text-green-800 rounded-lg px-2 py-1">
                                                <p className="text-xs font-bold">דווח</p>
                                                <p className="text-lg font-bold">{linkedRecord.averageScore.toFixed(1)}</p>
                                            </div>
                                            <div>
                                                <p className="font-semibold text-gray-800">{session.title}</p>
                                                <p className="text-sm text-gray-600">{formatDateTimeWithDay(session.date)}</p>
                                            </div>
                                        </div>
                                    </button>
                                ) : (
                                    <div key={`session-${session.id}-${index}`} className="bg-gray-100 p-3 rounded-lg flex justify-between items-center">
                                        <div>
                                          <p className="font-bold text-gray-800">{session.title}</p>
                                          <p className="text-sm text-gray-600">{formatDateWithDay(session.date)} - {session.time} @ {session.place}</p>
                                        </div>
                                        {isPastAndUnreported ? (
                                             <button onClick={() => setReportingForSession(session)} className="text-xs font-bold py-1.5 px-3 rounded-full bg-yellow-400 text-yellow-900 hover:bg-yellow-500 transition-colors">
                                                הוסף דיווח
                                             </button>
                                        ) : (
                                            <span className={`text-xs font-bold py-1 px-3 rounded-full ${isFuture ? "bg-blue-200 text-blue-800" : "bg-gray-300 text-gray-700"}`}>
                                                {isFuture ? "פגישה עתידית" : "הושלם"}
                                            </span>
                                        )}
                                    </div>
                                );
                            } else if (historyItem.type === 'intervention') {
                                const intervention = historyItem.itemData;
                                const author = data.users[intervention.mentorId];
                                const authorName = author ? `${author.firstName} ${author.lastName}` : 'לא ידוע';
                                return (
                                    <details key={`intervention-${intervention.id}-${index}`} className="bg-cyan-50 p-3 rounded-lg border border-cyan-200 open:shadow-md transition-shadow">
                                        <summary className="flex justify-between items-center font-semibold cursor-pointer list-none">
                                            <div className="flex items-center">
                                                <UsersIcon className="w-5 h-5 text-cyan-600 ml-3"/>
                                                <div>
                                                    <p className="text-gray-800">התערבות: {intervention.toolTitle || 'כלי לא ידוע'}</p>
                                                    <p className="font-normal text-sm text-gray-600">{formatDateWithDay(intervention.date)}</p>
                                                </div>
                                            </div>
                                            <span className="text-xs font-bold bg-cyan-200 text-cyan-800 py-1 px-3 rounded-full">{intervention.status}</span>
                                        </summary>
                                        <div className="mt-4 pt-3 border-t">
                                            <p className="text-sm text-gray-700 whitespace-pre-wrap">{intervention.notes}</p>
                                            <p className="text-xs text-gray-500 mt-2">בוצע ע"י: {authorName}</p>
                                        </div>
                                    </details>
                                );
                            } else { // mood_independent
                                const record = historyItem.itemData;
                                return (
                                    <details key={`record-${record.id}-${index}`} className="bg-rose-50 border border-rose-200 p-3 rounded-lg open:shadow-md transition-shadow">
                                        <summary className="flex justify-between items-center font-semibold cursor-pointer list-none">
                                            <div><p className="text-gray-800">דיווח "מ'מצב?"</p><p className="font-normal text-sm text-gray-600">{formatDateWithDay(record.date)}</p></div>
                                            <div className="text-left"><span className="bg-rose-200 text-rose-800 text-xs font-bold py-1 px-3 rounded-full">דיווח עצמאי</span><p className={`text-lg font-bold mt-1 ${record.averageScore > 7 ? 'text-green-600' : record.averageScore < 5 ? 'text-red-600' : 'text-yellow-600'}`}>{record.averageScore.toFixed(1)}</p></div>
                                        </summary>
                                        <div className="mt-4 pt-3 border-t grid grid-cols-1 sm:grid-cols-2 gap-4">
                                            <div><p><strong>רגשי: {record.emotionalScore !== null ? `${record.emotionalScore}/10` : 'לא דורג'}</strong></p><p className="text-sm text-gray-600 pl-2 border-r-2">{record.emotionalScore !== null ? record.emotionalEvidence || 'אין עדות' : ''}</p></div>
                                            <div><p><strong>חברתי: {record.socialScore !== null ? `${record.socialScore}/10` : 'לא דורג'}</strong></p><p className="text-sm text-gray-600 pl-2 border-r-2">{record.socialScore !== null ? record.socialEvidence || 'אין עדות' : ''}</p></div>
                                            <div><p><strong>לימודי: {record.academicScore !== null ? `${record.academicScore}/10` : 'לא דורג'}</strong></p><p className="text-sm text-gray-600 pl-2 border-r-2">{record.academicScore !== null ? record.academicEvidence || 'אין עדות' : ''}</p></div>
                                            <div><p><strong>אישי: {record.personalScore !== null ? `${record.personalScore}/10` : 'לא דורג'}</strong></p><p className="text-sm text-gray-600 pl-2 border-r-2">{record.personalScore !== null ? record.personalEvidence || 'אין עדות' : ''}</p></div>
                                        </div>
                                    </details>
                                );
                            }
                        })
                    ) : <p className="text-center text-gray-500 py-4">אין היסטוריית פעילות להצגה.</p>}
                </div>
            </div>
        </div>
    );
    
    return (
        <div className="p-4">
            <button onClick={onBack} className="flex items-center text-indigo-600 font-bold mb-4">
                <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
            </button>
            {viewContent}
            <AddImpressionModal isOpen={isImpressionModalOpen} onClose={() => setIsImpressionModalOpen(false)} onSubmit={handleAddImpression} isSubmitting={isSubmittingImpression}/>
            {reportModalData && <ReportDetailModal data={reportModalData} tools={data.tools} onClose={() => setReportModalData(null)} />}
            {isDetailsModalOpen && <StudentDetailsModal student={student} onClose={() => setIsDetailsModalOpen(false)} />}
        </div>
    );
};

const NeedsAttentionView: React.FC<{
    onBack: () => void;
    onSelectStudent: (student: Student) => void;
}> = ({ onBack, onSelectStudent }) => {
    const { user } = useAuth();
    const [isLoading, setIsLoading] = useState(true);
    const [alerts, setAlerts] = useState<Alert[]>([]);
    const [tools, setTools] = useState<Tool[]>([]);
    const { addToast } = useToast();
    const [recommendations, setRecommendations] = useState<{[key: string]: string}>({});
    const [loadingRecs, setLoadingRecs] = useState<{[key: string]: boolean}>({});
    const [dismissingIds, setDismissingIds] = useState<string[]>([]);
    const [reportModalData, setReportModalData] = useState<{ record: MoodRecord; session?: Session } | null>(null);

    const fetchData = useCallback(async () => {
        if (!user) return;
        setIsLoading(true);
        try {
            const [fetchedAlerts, fetchedTools] = await Promise.all([
                apiService.getAlerts(user.id),
                apiService.getTools(),
            ]);
            setAlerts(fetchedAlerts);
            setTools(fetchedTools);
        } catch(e) {
            addToast("שגיאה בטעינת ההתראות", "error");
        } finally {
            setIsLoading(false);
        }
    }, [user, addToast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);

    const handleGetRecommendation = async (student: Student, record: MoodRecord) => {
        setLoadingRecs(prev => ({ ...prev, [record.id]: true }));
        const rec = await getActionRecommendation(student, record);
        setRecommendations(prev => ({ ...prev, [record.id]: rec }));
        setLoadingRecs(prev => ({ ...prev, [record.id]: false }));
    };
    
    const handleDismissAlert = async (alert: Alert) => {
        setDismissingIds(prev => [...prev, alert.id]);
        try {
            const success = await apiService.acknowledgeAlert(alert.id, alert.source.type);
            if (success) {
                addToast('ההתראה שוחררה בהצלחה');
                fetchData(); // Refresh list
            } else {
                addToast('שגיאה בשחרור ההתראה', 'error');
            }
        } catch(e) {
             addToast('שגיאה בשחרור ההתראה', 'error');
        } finally {
            setDismissingIds(prev => prev.filter(id => id !== alert.id));
        }
    };
    
    const handleShowDetails = async (alert: Alert) => {
        if(alert.source.type === 'mood_record') {
            const record = alert.source.record;
            const session = record.sessionId ? await apiService.getSessionById(record.sessionId) : undefined;
            setReportModalData({ record, session });
        } else {
            addToast("הצגת פרטי התערבות עדיין בפיתוח.", "info");
        }
    }

    if (isLoading) return <div className="p-4"><LoadingSpinner /></div>

    return (
         <div className="bg-white p-4 rounded-lg shadow-md">
            <button onClick={onBack} className="flex items-center text-indigo-600 font-bold mb-4">
                <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
            </button>
            <h2 className="text-2xl font-bold mb-4">דורש תשומת לב</h2>
            {alerts.length === 0 ? <p>כל הכבוד! אין תלמידים שדורשים תשומת לב מיוחדת כרגע.</p> :
            <div className="space-y-4">
                {alerts.map((alert) => {
                    const isUrgent = alert.severity === 'דחוף';
                    const isFollowUp = alert.severity === 'מעקב';
                    const reasonText = {
                        'low_score': 'ציונים נמוכים בדיווח',
                        'independent_report': 'הגיש/ה דיווח עצמאי',
                        'task_follow_up': 'מעקב אחר משימה'
                    }[alert.reason];

                    const cardClasses = isUrgent ? 'border-red-300 bg-red-50' : isFollowUp ? 'border-cyan-300 bg-cyan-50' : 'border-orange-300 bg-orange-50';
                    const titleColor = isUrgent ? 'text-red-800' : isFollowUp ? 'text-cyan-800' : 'text-orange-800';
                    const severityColor = isUrgent ? 'text-red-600' : isFollowUp ? 'text-cyan-600' : 'text-orange-600';
                    const isDismissing = dismissingIds.includes(alert.id);
                    const student = alert.student;

                    return (
                        <div key={alert.id} className={`border ${cardClasses} p-4 rounded-lg`}>
                            <div className="flex justify-between items-start">
                                <div>
                                    <h3 className={`font-bold text-lg ${titleColor}`}>{student.firstName} {student.lastName}</h3>
                                    <p className="text-sm font-semibold">
                                        <span className={`font-bold ${severityColor}`}>{alert.severity}</span>
                                        <span className="text-gray-400 mx-2">|</span>
                                        <span className={titleColor}>{reasonText}</span>
                                    </p>
                                    <p className="text-sm text-gray-600 mt-1">תאריך: {formatDateWithDay(alert.date)}</p>
                                     {alert.source.type === 'mood_record' && <p className="font-bold text-gray-700 my-2">ממוצע דיווח: {alert.source.record.averageScore.toFixed(1)}</p>}
                                     {alert.source.type === 'intervention' && <p className="font-bold text-gray-700 my-2">כלי: {alert.source.intervention.toolName}</p>}
                                </div>
                                 <div className="flex flex-col items-end gap-2">
                                     <button onClick={() => onSelectStudent(student)} className="text-sm text-indigo-600 hover:underline">צפה בפרופיל</button>
                                      
                                        <button onClick={() => handleShowDetails(alert)} className="text-sm text-indigo-600 hover:underline flex items-center">
                                         <EyeIcon className="w-4 h-4 ml-1" />
                                         הצג פרטי דיווח
                                     </button>
                                     
                                 </div>
                            </div>
                            
                             <div className="mt-3 pt-3 border-t border-gray-300/50 flex items-center justify-between gap-4">
                                {alert.source.type === 'mood_record' ? (
                                    recommendations[alert.id] ? (
                                        <div className="bg-yellow-100 border-l-4 border-yellow-400 text-yellow-800 p-3 rounded mt-2 text-sm flex-grow">
                                            <p className="font-bold">המלצת AI:</p> <div className="whitespace-pre-wrap">{recommendations[alert.id]}</div>
                                        </div>
                                    ) : (
                                        <button onClick={() => {
                                            if (alert.source.type === 'mood_record') {
                                                handleGetRecommendation(student, alert.source.record)
                                            }
                                        }} disabled={loadingRecs[alert.id]} className="text-sm bg-indigo-500 text-white py-1.5 px-3 rounded-md hover:bg-indigo-600 disabled:bg-gray-400">
                                            {loadingRecs[alert.id] ? 'חושב...' : 'קבל המלצת AI'}
                                        </button>
                                    )
                                ) : <div className="flex-grow"></div>}

                                <button onClick={() => handleDismissAlert(alert)} disabled={isDismissing} className="bg-green-100 text-green-700 hover:bg-green-200 text-sm font-semibold py-1.5 px-3 rounded-md flex items-center disabled:opacity-50 disabled:cursor-not-allowed flex-shrink-0">
                                    {isDismissing ? <div className="w-4 h-4 border-2 border-green-700 border-t-transparent rounded-full animate-spin"></div> : <CheckCircleIcon className="w-5 h-5"/>}
                                    <span className="mr-2">{isDismissing ? '' : 'טופל'}</span>
                                </button>
                            </div>

                        </div>
                    )
                })}
            </div>
            }
            {reportModalData && <ReportDetailModal data={reportModalData} tools={tools} onClose={() => setReportModalData(null)} />}
        </div>
    );
};

const StudentListView: React.FC<{ 
    onBack: () => void; 
    onSelectStudent: (student: Student) => void; 
    students: Student[]; 
    onCreateReport: () => void;
    onAssignStudents: () => void;
}> = ({ onBack, onSelectStudent, students, onCreateReport, onAssignStudents }) => {
    const [studentDetails, setStudentDetails] = useState<{[id: string]: { average: string, details: Student } }>({});
    const [isLoading, setIsLoading] = useState(true);
    const [selectedStudentForDetails, setSelectedStudentForDetails] = useState<Student | null>(null);

    useEffect(() => {
        const fetchDetails = async () => {
            setIsLoading(true);
            const details: {[id: string]: { average: string, details: Student }} = {};
            try {
                for (const s of students) {
                    const [records, studentData] = await Promise.all([
                        apiService.getMoodRecordsForStudent(s.id),
                        apiService.getStudentById(s.id)
                    ]);

                    const globalAverage = records.length > 0
                        ? (records.reduce((total, record) => total + record.averageScore, 0) / records.length).toFixed(1)
                        : 'N/A';
                    
                    details[s.id] = {
                        average: globalAverage,
                        details: studentData as Student
                    };
                }
            } catch (e) {
                console.error("Error fetching student details for list view", e);
            }
            setStudentDetails(details);
            setIsLoading(false);
        };
        fetchDetails();
    }, [students]);

    return (
        <div className="bg-white p-4 rounded-lg shadow-md">
            <div className="flex justify-between items-center mb-4">
                <button onClick={onBack} className="flex items-center text-indigo-600 font-bold">
                    <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /><span className="ml-1">חזור</span>
                </button>
                 <div className="flex items-center space-x-2 space-x-reverse">
                    <button onClick={onAssignStudents} className="flex items-center bg-purple-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-purple-700 transition-colors text-sm">
                        <UsersIcon className="w-5 h-5 ml-1" />
                        <span>שיוך תלמידים לחונך</span>
                    </button>
                    <button onClick={onCreateReport} className="flex items-center bg-indigo-600 text-white font-bold py-2 px-3 rounded-lg hover:bg-indigo-700 transition-colors text-sm">
                        <PlusCircleIcon className="w-5 h-5 ml-1" />
                        <span>צור מפגש חדש</span>
                    </button>
                 </div>
            </div>
            <h2 className="text-2xl font-bold mb-4">מ'מצב תלמידים</h2>
            {isLoading ? <LoadingSpinner /> : (
                students.map(s => (
                    <div 
                        key={s.id} 
                        role="button"
                        tabIndex={0}
                        onClick={() => onSelectStudent(s)}
                        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onSelectStudent(s); }}
                        className="p-3 bg-gray-50 rounded-md mb-2 flex justify-between items-center hover:bg-indigo-50 hover:shadow-sm transition-all cursor-pointer focus:outline-none focus:ring-2 focus:ring-indigo-300"
                    >
                        <span className="font-semibold">{s.firstName} {s.lastName}</span>
                        <div className="flex items-center space-x-4 space-x-reverse">
                            <span className="font-bold">{studentDetails[s.id]?.average || 'N/A'}</span>
                            <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    setSelectedStudentForDetails(studentDetails[s.id]?.details)
                                }} 
                                onKeyDown={(e) => e.stopPropagation()}
                                className="text-sm text-indigo-600 hover:underline z-10 relative"
                            >
                                פרטים
                            </button>
                        </div>
                    </div>
                ))
            )}
            {selectedStudentForDetails && <StudentDetailsModal student={selectedStudentForDetails} onClose={() => setSelectedStudentForDetails(null)} />}
        </div>
    );
};
type ParsedAdvice = {
    understanding?: string;
    recommendations: { id: number; name: string }[];
    error?: string;
};

const MentorGuideView: React.FC = () => {
    const steps = [
        { id: 1, title: "שלב 1: היכרות וכללי המשחק", text: "זהו השלב הראשוני והחשוב ביותר. הציגו את עצמכם, את מטרת המערכת ('כלי שעוזר לנו לדבר על מה שחשוב'), ואת שיטת העבודה. זה המקום לספר קצת על עצמכם ועל הגישה שלכם לחונכות." },
        { id: 2, title: "שלב 2: בניית אמון ואותנטיות", text: "אמון הוא המטבע החשוב ביותר. הביאו את עצמכם לקשר - היו אותנטיים, שתפו במידה, והראו אכפתיות אמיתית. תלמיד שמרגיש בטוח ישתף יותר ויהיה פתוח יותר לתהליך." },
        { id: 3, title: "שלב 3: אינטייק ופגישה ראשונה", text: "השתמשו בפגישה הראשונה כדי להכיר את עולמו של התלמיד. שאלו שאלות פתוחות, הקשיבו היטב, והימנעו משיפוטיות. אפשר למלא דיווח 'מ'מצב?' ראשון יחד כדי להכיר את הכלי." },
        { id: 4, title: "שלב 4: חוזה ליווי ותיאום ציפיות", text: "הגדירו יחד את מסגרת הקשר: תדירות פגישות, דרכי התקשרות בין מפגשים, גבולות וסודיות. כשהכללים ברורים, שני הצדדים מרגישים בטוחים יותר." },
        { id: 5, title: "שלב 5: שיטת הדירוג ככלי להמשגה", text: "הסבירו לתלמיד שהסרגלים הם לא 'מבחן', אלא דרך קלה לדבר על רגשות. שאלו: 'מה זה אומר עבורך 4 חברתי?', 'מה יעזור לך לעלות ל-5?'. זה הופך רגשות מופשטים לשיחה קונקרטית." },
        { id: 6, title: "שלב 6: נוכחות: זיהוי, החזקה ופעולה", text: "זהו לב התהליך. היו נוכחים. זהו מגמות בגרפים, 'החזיקו' (Hold) את הקושי שהתלמיד מציג בלי למהר לפתור, ורק אז, הפכו את התובנה לפעולה בעזרת 'ארגז הכלים'." },
        { id: 7, title: "שלב 7: שמירה על קשר ומעקב יזום", text: "היוזמה שלכם בין הפגישות שווה המון. הודעה קצרה, בדיקה לשלום, או התעניינות במשימה מראה לתלמיד שאכפת לכם ושהוא לא לבד. זה בונה את תחושת הליווי והרצינות." },
        { id: 8, title: "שלב 8: כוחו של תיעוד", text: "תיעוד ההתרשמויות שלכם חיוני. הוא עוזר לכם לזכור את פרטי התהליך, לזהות דפוסים, ולשתף את שאר אנשי הצוות בתמונה המלאה כדי לספק לתלמיד את התמיכה הטובה ביותר." }
    ];
    return (
        <div className="space-y-3">
            {steps.map((step) => (
                <details key={step.id} className="p-4 bg-gray-50 rounded-lg border-l-4 border-indigo-500 group transition-all duration-300">
                    <summary className="font-bold text-lg text-indigo-800 cursor-pointer list-none flex justify-between items-center">
                        {step.title}
                        <ChevronDownIcon className="w-5 h-5 text-indigo-600 transition-transform duration-300 group-open:rotate-180" />
                    </summary>
                    <div className="text-gray-700 mt-2 pt-2 border-t border-indigo-100">
                      <p>{step.text}</p>
                      <div className="flex items-center text-sm text-indigo-500 mt-3 cursor-pointer hover:underline">
                        <PlayCircleIcon className="w-4 h-4 ml-1" />
                        <span>צפה בסרטון הדרכה (בקרוב)</span>
                      </div>
                    </div>
                </details>
            ))}
        </div>
    );
};
const ToolkitView: React.FC<{ onBack: () => void; tools: Tool[] }> = ({ onBack, tools }) => {
    const [view, setView] = useState<'main' | 'library' | 'guide'>('main');
    const [filter, setFilter] = useState<ToolType | 'all'>('all');
    const [query, setQuery] = useState('');
    const [advice, setAdvice] = useState<ParsedAdvice | null>(null);
    const [isLoadingAdvice, setIsLoadingAdvice] = useState(false);
    const toolRefs = useRef<Map<number, HTMLDetailsElement | null>>(new Map());
    const { addToast } = useToast();
     const {
        text,
        interimText,
        isListening,
        startListening,
        stopListening,
        hasRecognitionSupport
    } = useSpeechRecognition();
    
    useEffect(() => {
        if(text) setQuery(prev => (prev ? prev.trim() + ' ' : '') + text)
    }, [text])

    const handleGetConsultation = async () => {
        if (!query.trim()) {
            addToast("יש לכתוב שאלה כדי לקבל המלצה", "error");
            return;
        }
        setIsLoadingAdvice(true);
        setAdvice(null);
        try {
            const result = await getConsultationAdvice(query);
            const parsedResult = JSON.parse(result) as ParsedAdvice;
            setAdvice(parsedResult);
        } catch (error) {
            console.error(error);
            setAdvice({ error: "שגיאה בניתוח תשובת ה-AI.", recommendations: [] });
        } finally {
            setIsLoadingAdvice(false);
        }
    };
    
    const handleRecommendationClick = (toolId: number) => {
        const toolElement = toolRefs.current.get(toolId);
        if (toolElement) {
            toolElement.open = true;
            toolElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
            toolElement.classList.add('bg-yellow-100', 'ring-2', 'ring-yellow-400');
            setTimeout(() => {
                toolElement.classList.remove('bg-yellow-100', 'ring-2', 'ring-yellow-400');
            }, 2500);
        }
    };


    const filteredTools = useMemo(() => {
        if (filter === 'all') return tools;
        return tools.filter(tool => tool.category === filter);
    }, [filter, tools]);

    const renderMain = () => (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <button onClick={() => setView('library')} className="p-6 bg-indigo-50 hover:bg-indigo-100 rounded-lg text-center transition-colors">
                <BriefcaseIcon className="w-12 h-12 mx-auto text-indigo-600 mb-2"/>
                <h3 className="text-xl font-bold text-indigo-800">ספריית הכלים</h3>
                <p className="text-sm text-gray-600">מאגר פעילויות ותרגילים לשימושך</p>
            </button>
            <button onClick={() => setView('guide')} className="p-6 bg-green-50 hover:bg-green-100 rounded-lg text-center transition-colors">
                <BookCheckIcon className="w-12 h-12 mx-auto text-green-600 mb-2"/>
                <h3 className="text-xl font-bold text-green-800">8 השלבים לחונכות אפקטיבית</h3>
                <p className="text-sm text-gray-600">המדריך המלא לתהליך חונכות מוצלח</p>
            </button>
        </div>
    );
    
    const renderLibrary = () => (
        <div>
             <div className="bg-white p-4 rounded-lg shadow-md mb-6 border border-indigo-100">
                <h3 className="text-lg font-bold flex items-center mb-3"><SparklesIcon className="w-5 h-5 ml-2 text-indigo-500"/>חיפוש כלי/פעילות מתאימה עבור תלמיד/ה</h3>
                 <div className="relative">
                     <textarea 
                        value={query + (interimText ? ' ' + interimText : '')}
                        onChange={(e) => setQuery(e.target.value)}
                        placeholder="תאר/י את הבעיה או האתגר של התלמיד/ה..."
                        rows={3}
                        className="w-full p-2 border rounded-md resize-none pr-10"
                    />
                     {hasRecognitionSupport && (
                        <button
                            type="button"
                            onClick={isListening ? stopListening : startListening}
                            className={`absolute top-2 right-2 p-2 rounded-full transition-colors ${
                                isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                            }`}
                        >
                            <MicIcon className="w-5 h-5" />
                        </button>
                     )}
                </div>
                <div className="mt-3 flex justify-end">
                     <button onClick={handleGetConsultation} disabled={isLoadingAdvice} className="bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-400">
                         {isLoadingAdvice ? 'מאבחן...' : 'מצא לי כלי מתאים'}
                     </button>
                 </div>

                 {advice && (
                    <div className="mt-4 pt-3 border-t">
                        <h4 className="font-bold text-gray-800">כלים מומלצים מהמאגר:</h4>
                        {advice.error ? <p className="text-red-500">{advice.error}</p> : (
                            <div>
                                <p className="text-gray-600 mb-2 italic">"{advice.understanding}"</p>
                                <div className="flex flex-wrap gap-2">
                                    {(advice.recommendations || []).map(rec => (
                                        <button key={rec.id} onClick={() => handleRecommendationClick(rec.id)} className="bg-yellow-200 text-yellow-800 text-sm font-semibold py-1 px-3 rounded-full hover:bg-yellow-300">
                                            {rec.name}
                                        </button>
                                    ))}
                                    {advice.recommendations && advice.recommendations.length === 0 && <p className="text-sm text-gray-500">לא נמצאו כלים מתאימים מהמאגר.</p>}
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
            
             <div className="flex items-center space-x-2 space-x-reverse mb-4">
                <span className="font-semibold">סנן לפי:</span>
                <button onClick={() => setFilter('all')} className={`px-3 py-1 text-sm rounded-full ${filter==='all' ? 'bg-indigo-600 text-white' : 'bg-gray-200'}`}>הכל</button>
                <button onClick={() => setFilter('במפגש')} className={`px-3 py-1 text-sm rounded-full ${filter==='במפגש' ? 'bg-sky-500 text-white' : 'bg-gray-200'}`}>במפגש</button>
                <button onClick={() => setFilter('משימה לתלמיד')} className={`px-3 py-1 text-sm rounded-full ${filter==='משימה לתלמיד' ? 'bg-amber-500 text-white' : 'bg-gray-200'}`}>משימה לתלמיד</button>
                <button onClick={() => setFilter('תהליך ארוך טווח')} className={`px-3 py-1 text-sm rounded-full ${filter==='תהליך ארוך טווח' ? 'bg-teal-500 text-white' : 'bg-gray-200'}`}>תהליך ארוך טווח</button>
            </div>
            
             <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                 {filteredTools.map(tool => {
                     const categoryColorClasses = {
                        'במפגש': 'bg-sky-100 text-sky-800',
                        'משימה לתלמיד': 'bg-amber-100 text-amber-800',
                        'תהליך ארוך טווח': 'bg-teal-100 text-teal-800',
                    };
                    
                    return (
                         <details key={tool.id} ref={el => { toolRefs.current.set(tool.id, el); }} className="p-4 border rounded-lg group transition-all duration-300 bg-white shadow-sm open:shadow-lg">
                            <summary className="font-bold text-lg cursor-pointer list-none flex justify-between items-center">
                                 <div className="flex flex-col sm:flex-row sm:items-center sm:space-x-4 sm:space-x-reverse">
                                    <p className="text-gray-800">{tool.name}</p>
                                    <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${categoryColorClasses[tool.category]}`}>{tool.category}</span>
                                </div>
                                <ChevronDownIcon className="w-5 h-5 text-gray-500 transition-transform duration-300 group-open:rotate-180 flex-shrink-0" />
                            </summary>
                             <div className="mt-4 pt-3 border-t">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                                    <div>
                                        <h4 className="font-bold text-base mb-2">איך משתמשים?</h4>
                                        <p className="text-sm text-gray-600 mb-2"><strong>הכנה:</strong> {tool.how_to.prep}</p>
                                        <ul className="list-decimal list-inside space-y-1 text-sm text-gray-700">
                                            {tool.how_to.steps.map((step, i) => <li key={i}>{step}</li>)}
                                        </ul>
                                    </div>
                                    <div className="space-y-4">
                                         <div>
                                            <h4 className="font-bold text-base mb-1">מאחורי הקלעים</h4>
                                            <p className="text-sm text-gray-600">{tool.explanation}</p>
                                            <p className="text-sm text-gray-600 mt-1"><strong>תוצאה מקווה:</strong> {tool.expected_outcome}</p>
                                        </div>
                                         <div>
                                            <h4 className="font-bold text-base mb-1">דגשים חשובים</h4>
                                            <ul className="list-disc list-inside space-y-1 text-sm">
                                                {tool.do_nots.map((dn, i) => <li key={i} className="text-red-600"><span className="text-gray-700">{dn}</span></li>)}
                                                {tool.success_signs.map((ss, i) => <li key={i} className="text-green-600"><span className="text-gray-700">{ss}</span></li>)}
                                            </ul>
                                        </div>
                                    </div>
                                     <div className="md:col-span-2">
                                        <h4 className="font-bold text-base mb-1">דיסציפלינות קשורות</h4>
                                         <div className="flex flex-wrap gap-2">
                                            {tool.disciplines.map((d, i) => {
                                                const match = d.match(/\[(.*?)\]\((.*?)\)/);
                                                if(match) return <a key={i} href={match[2]} target="_blank" rel="noopener noreferrer" className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded hover:bg-gray-300">{match[1]}</a>
                                                return <span key={i} className="text-xs bg-gray-200 text-gray-800 px-2 py-1 rounded">{d}</span>
                                            })}
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </details>
                    )
                 })}
             </div>
        </div>
    );
    
     const renderGuide = () => <MentorGuideView />;

    let viewContent;
    let title = "כלים לחונך";
    let showBackButton = true;

    if (view === 'library') {
        title = "ספריית הכלים";
    } else if (view === 'guide') {
        title = "8 השלבים לחונכות אפקטיבית";
    } else {
        showBackButton = false;
    }

    return (
        <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
            <header className="flex items-center mb-6">
                {view !== 'main' && (
                    <button onClick={() => setView('main')} className="text-indigo-600 ml-4">
                         <ChevronLeftIcon className="w-8 h-8 transform rotate-180" />
                    </button>
                )}
                 <button onClick={onBack} className="flex items-center text-indigo-600 font-bold">
                    <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1 hidden sm:inline">חזור לדשבורד</span>
                </button>
                <h2 className="text-2xl font-bold mr-4">{title}</h2>
            </header>
            
            {view === 'main' && renderMain()}
            {view === 'library' && renderLibrary()}
            {view === 'guide' && renderGuide()}
        </div>
    );
};

const AssignStudentsView: React.FC<{
    onBack: () => void;
    onAssignSuccess: () => void;
    mentor: User;
}> = ({ onBack, onAssignSuccess, mentor }) => {
    const [unassignedStudents, setUnassignedStudents] = useState<Student[]>([]);
    const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const { addToast } = useToast();

    useEffect(() => {
        const fetchUnassigned = async () => {
            setIsLoading(true);
            try {
                const students = await apiService.getUnassignedStudents();
                setUnassignedStudents(students);
            } catch (e) {
                addToast("שגיאה בטעינת תלמידים פנויים", "error");
            } finally {
                setIsLoading(false);
            }
        };
        fetchUnassigned();
    }, [addToast]);

    const toggleSelection = (studentId: string) => {
        setSelectedIds(prev => {
            const newSet = new Set(prev);
            if (newSet.has(studentId)) {
                newSet.delete(studentId);
            } else {
                newSet.add(studentId);
            }
            return newSet;
        });
    };

    const handleAssign = async () => {
        if (selectedIds.size === 0) {
            addToast("יש לבחור לפחות תלמיד אחד", "info");
            return;
        }
        setIsSubmitting(true);
        try {
            const currentAssignedIds = new Set(mentor.assignedStudentIds || []);
            selectedIds.forEach(id => currentAssignedIds.add(id));
            
            await apiService.updateUser(mentor.id, { assignedStudentIds: Array.from(currentAssignedIds) });
            
            addToast(`שויכו ${selectedIds.size} תלמידים בהצלחה!`, 'success');
            onAssignSuccess();

        } catch (e) {
            addToast("שגיאה בשיוך התלמידים", "error");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <div className="bg-white p-4 rounded-lg shadow-md">
            <button onClick={onBack} className="flex items-center text-indigo-600 font-bold mb-4">
                <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
            </button>
            <h2 className="text-2xl font-bold mb-4">שיוך תלמידים לחונך</h2>
            {isLoading ? <LoadingSpinner /> : (
                <div className="space-y-2 max-h-96 overflow-y-auto border p-2 rounded-md">
                    {unassignedStudents.length > 0 ? (
                        unassignedStudents.map(student => (
                            <label key={student.id} className="flex items-center p-2 rounded-md hover:bg-indigo-50 cursor-pointer">
                                <input
                                    type="checkbox"
                                    checked={selectedIds.has(student.id)}
                                    onChange={() => toggleSelection(student.id)}
                                    className="h-5 w-5 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                />
                                <span className="mr-3 font-semibold">{student.firstName} {student.lastName}</span>
                                <span className="text-sm text-gray-500">({student.class})</span>
                            </label>
                        ))
                    ) : (
                        <p className="text-center text-gray-500 py-4">כל הכבוד! אין תלמידים שממתינים לשיוך.</p>
                    )}
                </div>
            )}
            <div className="mt-6 flex justify-end">
                <button
                    onClick={handleAssign}
                    disabled={isSubmitting || isLoading || selectedIds.size === 0}
                    className="bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors disabled:bg-gray-400"
                >
                    {isSubmitting ? "משייך..." : "שייך נבחרים"}
                </button>
            </div>
        </div>
    );
};


type View = 'main' | 'student-profile' | 'meetings' | 'attention' | 'status' | 'toolkit' | 'create-report-student-select' | 'create-report-form' | 'assign-students';

const MentorDashboard: React.FC = () => {
    const { user } = useAuth();
    const { addToast } = useToast();
    const [view, setView] = useState<View>('main');
    const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
    const [isDataLoading, setIsDataLoading] = useState(true);
    const [data, setData] = useState<{students: Student[], alerts: Alert[], sessions: Session[], tools: Tool[] } | null>(null);

    const fetchData = useCallback(async () => {
        if (!user) return;
        setIsDataLoading(true);
        try {
            const [students, alerts, sessions, tools] = await Promise.all([
                apiService.getStudentsForMentor(user.id),
                apiService.getAlerts(user.id),
                apiService.getSessionsForMentor(user.id),
                apiService.getTools()
            ]);
            setData({ students, alerts, sessions, tools });
        } catch(e) {
            addToast("שגיאה בטעינת נתוני החונך", "error");
        } finally {
            setIsDataLoading(false);
        }
    }, [user, addToast]);

    useEffect(() => {
        fetchData();
    }, [fetchData]);
    
    const handleSelectStudent = (student: Student) => {
        setSelectedStudent(student);
        setView('student-profile');
    };

    const handleCreateReport = () => {
        if(data?.students.length === 1) {
            setSelectedStudent(data.students[0]);
            setView('create-report-form');
        } else {
            setView('create-report-student-select');
        }
    }
    
    const handleAssignSuccess = () => {
        fetchData();
        setView('status');
    };

    const upcomingSessionsToday = useMemo(() => {
        if (!data) return [];
        const todayStart = new Date();
        todayStart.setHours(0, 0, 0, 0);
        const todayEnd = new Date();
        todayEnd.setHours(23, 59, 59, 999);

        return data.sessions
            .filter(s => {
                const sessionDate = new Date(s.date);
                return sessionDate >= todayStart && sessionDate <= todayEnd && s.status === 'scheduled';
            });
    }, [data]);

    if (isDataLoading) {
        return <div className="p-4"><LoadingSpinner /></div>;
    }

    if (!data) {
        return <p className="p-4 text-center text-red-500">שגיאה בטעינת נתונים</p>;
    }

    let content;

    switch(view) {
        case 'student-profile':
            content = selectedStudent ? <StudentProfileView student={selectedStudent} onBack={() => { setSelectedStudent(null); setView('status'); }} /> : <p>לא נבחר תלמיד</p>;
            break;
        case 'meetings':
            content = <CalendarView mentorId={user!.id} onBack={() => setView('main')} />;
            break;
        case 'attention':
            content = <NeedsAttentionView onBack={() => setView('main')} onSelectStudent={handleSelectStudent} />;
            break;
        case 'status':
            content = <StudentListView 
                onBack={() => setView('main')} 
                onSelectStudent={handleSelectStudent} 
                students={data.students} 
                onCreateReport={handleCreateReport} 
                onAssignStudents={() => setView('assign-students')}
            />;
            break;
        case 'toolkit':
            content = <ToolkitView onBack={() => setView('main')} tools={data.tools} />;
            break;
        case 'assign-students':
             content = user ? <AssignStudentsView onBack={() => setView('status')} onAssignSuccess={handleAssignSuccess} mentor={user} /> : null;
             break;
        case 'create-report-student-select':
            content = (
                <div className="bg-white p-4 rounded-lg shadow-md">
                    <button onClick={() => setView('main')} className="flex items-center text-indigo-600 font-bold mb-4">
                        <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /><span className="ml-1">חזור</span>
                    </button>
                    <h2 className="text-2xl font-bold mb-4">בחר תלמיד לדיווח</h2>
                    <div className="space-y-2">
                        {data.students.map(s => (
                            <button key={s.id} onClick={() => { setSelectedStudent(s); setView('create-report-form'); }} className="w-full text-right p-3 bg-gray-50 rounded-md hover:bg-indigo-50 font-semibold">
                                {s.firstName} {s.lastName}
                            </button>
                        ))}
                    </div>
                </div>
            );
            break;
        case 'create-report-form':
             content = selectedStudent ? (
                <div className="bg-white p-4 sm:p-6 rounded-lg shadow-md">
                    <button onClick={() => setView(data.students.length > 1 ? 'create-report-student-select' : 'main')} className="flex items-center text-indigo-600 font-bold mb-4">
                        <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /> <span className="ml-1">חזור</span>
                    </button>
                    <h2 className="text-2xl font-bold mb-1">דיווח מ'מצב חדש</h2>
                    <p className="text-lg text-gray-600 mb-4">עבור: {selectedStudent.firstName} {selectedStudent.lastName}</p>
                    <WellbeingForm student={selectedStudent} onSubmit={async (recordData) => {
                        setIsDataLoading(true);
                        await apiService.addSessionWithReport(recordData, user!.id);
                        addToast("הדיווח נוצר בהצלחה!");
                        setView('main');
                        await fetchData();
                        setIsDataLoading(false);
                    }} isSubmitting={isDataLoading} onCancel={() => setView(data.students.length > 1 ? 'create-report-student-select' : 'main')} role={user!.role} tools={data.tools} />
                </div>
            ) : <p>לא נבחר תלמיד</p>;
            break;
        case 'main':
        default:
            content = (
                <div className="space-y-6">
                    <h1 className="text-3xl font-bold text-gray-800">ברוך/ה שוב/ה, {user?.firstName}</h1>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-4 gap-4">
                         <DashboardCard title="יומן מפגשים" indicator={upcomingSessionsToday.length} icon={<CalendarIcon className="w-10 h-10" />} onClick={() => setView('meetings')} className="bg-blue-200 text-blue-800"/>
                         <DashboardCard title="מ'מצב תלמידים" indicator={data.students.length} icon={<BarChartIcon className="w-10 h-10" />} onClick={() => setView('status')} className="bg-green-200 text-green-800"/>
                         <DashboardCard title="כלים לחונך" indicator={data.tools.length} icon={<BriefcaseIcon className="w-10 h-10" />} onClick={() => setView('toolkit')} className="bg-yellow-200 text-yellow-800"/>
                         <DashboardCard title="שים לב" indicator={data.alerts.length} icon={<AlertTriangleIcon className="w-10 h-10" />} onClick={() => setView('attention')} className="bg-red-200 text-red-800"/>
                    </div>
                     <div>
                        <h2 className="text-2xl font-bold text-gray-800 mb-3">משימות למעקב</h2>
                         <div className="bg-white p-4 rounded-lg shadow-md space-y-3">
                            <p className="text-center text-gray-500 py-4">תכונה זו בפיתוח.</p>
                        </div>
                    </div>
                </div>
            );
            break;
    }

    return <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">{content}</div>;
};

export default MentorDashboard;
