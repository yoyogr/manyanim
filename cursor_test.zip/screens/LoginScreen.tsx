import React, { useState } from 'react';
import { useAuth } from '../hooks/useAuth';

const LoginScreen: React.FC = () => {
  const [phone, setPhone] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [error, setError] = useState('');
  const { login, loading } = useAuth();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!phone) {
      setError('יש להזין טלפון או אימייל');
      return;
    }
    const success = await login(phone, rememberMe);
    if (!success) {
      setError('פרטי ההתחברות שגויים. אנא נסה שוב.');
    }
  };
  
  const handleQuickLogin = async (quickLoginPhone: string) => {
    setPhone(quickLoginPhone); // Optional: fill the input for visual feedback
    setError('');
    const success = await login(quickLoginPhone, true); // Always remember quick logins
    if (!success) {
      setError('פרטי ההתחברות שגויים. אנא נסה שוב.');
    }
  }

  const quickLoginUsers = [
    { name: 'אדמין (יורם)', phone: '0501234567' },
    { name: 'חונך (דנה)', phone: '0529876543' },
    { name: 'תלמיד (אבי)', phone: '0541112222' }
  ];

  return (
    <div className="min-h-screen flex bg-gray-100">
      {/* Form Panel */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-4">
        <div className="max-w-md w-full space-y-8">
          <div>
            <h1 className="text-center text-5xl font-extrabold text-indigo-600 lg:hidden" style={{ fontFamily: "'Heebo', sans-serif", fontWeight: 800 }}>
              מ׳ניינים?
            </h1>
            <h2 className="mt-6 text-center text-3xl font-bold text-gray-900">
              כניסה למערכת
            </h2>
          </div>
          
          <div className="bg-white p-8 shadow-2xl rounded-2xl">
            <form className="space-y-6" onSubmit={handleLogin}>
                <div>
                  <label htmlFor="phone" className="sr-only">
                    טלפון או דוא״ל (אדמין)
                  </label>
                  <input
                    id="phone"
                    name="phone"
                    type="text"
                    autoComplete="tel"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="appearance-none relative block w-full px-3 py-3 border border-gray-300 placeholder-gray-500 text-gray-900 rounded-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    placeholder="טלפון או דוא״ל (אדמין)"
                  />
                </div>
              
              {error && <p className="text-sm text-red-600 text-center">{error}</p>}

              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <input
                    id="remember-me"
                    name="remember-me"
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
                  />
                  <label htmlFor="remember-me" className="mr-2 block text-sm text-gray-900">
                    זכור אותי
                  </label>
                </div>
              </div>

              <div>
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-lg font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400"
                >
                  {loading ? 'מתחבר...' : 'כניסה'}
                </button>
              </div>
            </form>
            <div className="mt-6 pt-4 border-t">
              <h3 className="text-center text-sm font-semibold text-gray-600 mb-3">או התחבר במהירות:</h3>
              <div className="space-y-2">
                {quickLoginUsers.map(user => (
                  <div key={user.phone} className="flex justify-between items-center text-sm">
                    <span className="text-gray-700">{user.name}:</span>
                    <button onClick={() => handleQuickLogin(user.phone)} disabled={loading} className="bg-gray-200 text-gray-800 hover:bg-gray-300 font-bold py-1 px-3 rounded-md text-xs transition-colors">התחבר</button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Branding Panel */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-tr from-indigo-800 to-purple-700 items-center justify-center p-12 text-center text-white relative">
          <div className="absolute top-0 left-0 w-full h-full bg-black opacity-20"></div>
          <div className="z-10 w-full">
            <h1 className="text-7xl font-bold" style={{ fontFamily: "'Heebo', sans-serif", fontWeight: 800 }}>
              מ׳ניינים?
            </h1>
            <p className="text-2xl mt-4 font-light max-w-md mx-auto">
              הכלי שמחבר בין חונכים לתלמידים, ומאפשר צמיחה אישית ולימודית בסביבה תומכת.
            </p>
            <div className="mt-12 w-full flex justify-center">
                <svg className="w-64 h-64 text-purple-400 opacity-30" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                    <path fill="currentColor" d="M63.7,-25.3C73.4,-0.4,65.8,30.9,47.4,50.4C29,69.9,-10.1,77.5,-35.1,65.5C-60.1,53.5,-71,21.9,-65.8,-6.4C-60.6,-34.7,-39.3,-59.7,-14.8,-63.5C9.7,-67.3,54,-50.2,63.7,-25.3Z" transform="translate(100 100)" />
                </svg>
            </div>
          </div>
      </div>
    </div>
  );
};

export default LoginScreen;