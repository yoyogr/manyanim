
import React from 'react';

interface WelcomeScreenProps {
  onEnter: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onEnter }) => {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col justify-center items-center p-4 text-center">
      <div className="w-full max-w-sm">
        <h1 className="text-6xl font-bold text-indigo-600 mb-4" style={{ fontFamily: "'Heebo', sans-serif", fontWeight: 800 }}>
          מ׳ניינים?
        </h1>
        <p className="text-xl text-gray-600 mb-12">
          ניהול חונכות ומעקב אישי לתלמידים.
        </p>
        <button
          onClick={onEnter}
          className="w-full bg-indigo-600 text-white font-bold py-4 px-6 rounded-lg shadow-lg hover:bg-indigo-700 transform hover:-translate-y-1 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          כניסה
        </button>
      </div>
    </div>
  );
};

export default WelcomeScreen;
