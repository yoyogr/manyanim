

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '../hooks/useAuth';
import { useToast } from '../hooks/useToast';
import { MoodRecord, Student, Role, User } from '../types';
import apiService from '../services/apiService';
import WellbeingForm from '../components/WellbeingForm';
import { ChevronLeftIcon, BoyAvatarIcon, GirlAvatarIcon, StarIcon, XIcon, SmileIcon, Users2Icon, BookOpenIcon, HomeIcon, GiftIcon } from '../components/Icons';

type StudentView = 'dashboard' | 'report_form' | 'fun_corner';
type TrendType = 'up' | 'down' | 'same' | 'none';

const LEVEL_NAMES: { [key: number]: string } = {
  1: "עכבר שדה",
  2: "שועל ממולח",
  3: "זאב בודד",
  4: "נץ מהיר",
  5: "דב חזק",
  6: "נמר חמקן",
  7: "כריש עסקים",
  8: "פנתר על",
  9: "דרקון אש",
  10: "אריה מלך המ'ניינים"
};

const getLevelName = (level: number) => LEVEL_NAMES[level] || LEVEL_NAMES[10];

const ReportDetailsModal: React.FC<{ record: MoodRecord; onClose: () => void; }> = ({ record, onClose }) => {
    const DetailRow: React.FC<{ label: string, score: number | null, evidence: string, Icon: React.FC<{className?: string}>, color: string }> = ({ label, score, evidence, Icon, color }) => (
        <div>
            <div className="flex items-center mb-1">
                <Icon className={`w-5 h-5 ml-2 ${color}`} />
                <p className="font-bold">{label}: {score !== null ? <span className={color}>{score}/10</span> : <span className="text-gray-500 font-normal">לא דורג</span>}</p>
            </div>
             {score !== null && <p className="text-sm text-gray-600 pr-2 border-r-2 border-gray-200 mr-2">{evidence || 'לא צוינה עדות'}</p>}
        </div>
    );

    return (
        <div className="fixed inset-0 bg-black bg-opacity-60 flex justify-center items-center z-50 p-4" onClick={onClose} dir="rtl">
            <div className="bg-white rounded-2xl shadow-xl p-6 w-full max-w-lg relative" onClick={(e) => e.stopPropagation()}>
                 <button onClick={onClose} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors">
                     <XIcon className="w-6 h-6" />
                 </button>
                <h2 className="text-2xl font-bold mb-2 text-gray-900">
                    פרטי דיווח
                </h2>
                <p className="text-sm text-gray-500 mb-4">מתאריך: {new Date(record.date).toLocaleDateString('he-IL', { weekday: 'short', year: 'numeric', month: 'numeric', day: 'numeric' })}</p>
                <div className="text-center my-6">
                    <p className="text-gray-500 text-sm">ממוצע דיווח</p>
                    <p className={`text-6xl font-bold ${record.averageScore > 7 ? 'text-green-500' : record.averageScore < 5 ? 'text-red-500' : 'text-yellow-500'}`}>
                        {record.averageScore.toFixed(1)}
                    </p>
                </div>
                <div className="space-y-4">
                    <DetailRow label="רגשי" score={record.emotionalScore} evidence={record.emotionalEvidence} Icon={SmileIcon} color="text-blue-500" />
                    <DetailRow label="חברתי" score={record.socialScore} evidence={record.socialEvidence} Icon={Users2Icon} color="text-green-500" />
                    <DetailRow label="לימודי" score={record.academicScore} evidence={record.academicEvidence} Icon={BookOpenIcon} color="text-orange-500" />
                    <DetailRow label="אישי" score={record.personalScore} evidence={record.personalEvidence} Icon={HomeIcon} color="text-purple-500" />
                </div>
            </div>
        </div>
    );
};

interface PersonalPowerCenterProps {
  student: Student;
  globalAverage: number | null;
  moodRecords: MoodRecord[];
  onStartReport: () => void;
  onGoToFunCorner: () => void;
  mentor: User | null;
}

const ResilienceDialIcon: React.FC<{ score: number | null }> = ({ score }) => {
    // Sizing
    const dialSize = 80;
    const center = dialSize / 2;
    const strokeWidth = 2;
    const radius = dialSize / 2 - strokeWidth;
    const travelRadius = radius * 0.8; // Dot travels on a slightly smaller circle

    // Colors
    const upBg = '#ccfbf1';   // teal-100
    const downBg = '#fff1f2'; // rose-100
    
    let dotColor = '#f59e0b'; // Mid-score amber-500
    if (score !== null) {
        if (score > 7) dotColor = '#10b981'; // High-score emerald-500
        else if (score < 4) dotColor = '#ef4444'; // Low-score red-500
    }

    // Map score (0-10) to an angle on a circular arc.
    // 0=bottom, 5=left, 10=top. This corresponds to an arc from 90 to 270 degrees.
    const angle_deg = score !== null ? 90 + (score / 10) * 180 : 90;
    const angleRad = angle_deg * (Math.PI / 180);

    // Calculate dot position using trigonometry
    const dotCx = center + travelRadius * Math.cos(angleRad);
    const dotCy = center + travelRadius * Math.sin(angleRad);

    const showDot = score !== null;

    return (
        <div className="w-20 h-20 flex-shrink-0">
            <svg width={dialSize} height={dialSize} viewBox={`0 0 ${dialSize} ${dialSize}`}>
                {/* Bottom half (rose) */}
                <path 
                    d={`M ${center - radius},${center} A ${radius},${radius} 0 0 0 ${center + radius},${center} L ${center},${center} Z`}
                    fill={downBg}
                />
                {/* Top half (teal) */}
                 <path 
                    d={`M ${center - radius},${center} A ${radius},${radius} 0 0 1 ${center + radius},${center} L ${center},${center} Z`}
                    fill={upBg}
                />
                {/* Equator line */}
                <line 
                    x1={center - radius} 
                    y1={center} 
                    x2={center + radius} 
                    y2={center} 
                    stroke="#9ca3af" // gray-400
                    strokeWidth="1.5" 
                />
                {/* Score dot */}
                {showDot && (
                    <circle 
                        cx={dotCx} 
                        cy={dotCy} 
                        r="4"
                        fill={dotColor}
                        stroke="#fff"
                        strokeWidth="2"
                        className="transition-all duration-700 ease-out"
                    />
                )}
            </svg>
        </div>
    );
};

const PersonalPowerCenter: React.FC<PersonalPowerCenterProps> = ({ student, globalAverage, moodRecords, onStartReport, onGoToFunCorner, mentor }) => {
    const [isModalOpen, setIsModalOpen] = useState(false);
  
    const { trend, trendText, trendRecord } = useMemo((): { trend: TrendType; trendText: string; trendRecord: MoodRecord | null; } => {
        if (moodRecords.length === 0) {
            return { trend: 'none', trendText: 'זה יהיה הדיווח הראשון שלך, כל הכבוד על ההתחלה!', trendRecord: null };
        }
        
        if (moodRecords.length === 1) {
            return { trend: 'same', trendText: 'המשך כך, נשווה את הדיווח הבא לזה.', trendRecord: moodRecords[0] };
        }

        const latestRecord = moodRecords[0];
        const previousRecords = moodRecords.slice(1);
        const historicalAverage = previousRecords.reduce((acc, r) => acc + r.averageScore, 0) / previousRecords.length;
        
        const diff = latestRecord.averageScore - historicalAverage;

        if (diff > 0.2) {
             return { trend: 'up', trendText: 'איזה יופי, יש שיפור בהרגשה שלך!', trendRecord: latestRecord };
        }
        if (diff < -0.2) {
             const mentorName = mentor?.firstName || 'החונך';
             return { trend: 'down', trendText: `אוי, יש קצת ירידה, לא נורא... אולי תרצה לשתף את ${mentorName}?`, trendRecord: latestRecord };
        }
        return { trend: 'same', trendText: 'ההרגשה שלך יציבה, וזה גם טוב! המשך כך.', trendRecord: latestRecord };

    }, [moodRecords, mentor]);
    
    const TrendTextComponent = () => {
        if (trend === 'none' || !trendRecord) {
            return <p className="text-sm text-gray-500">{trendText}</p>;
        }
        
        const colorClass = trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-orange-600';
        
        return (
             <button onClick={() => setIsModalOpen(true)} className={`text-sm font-semibold ${colorClass} hover:underline focus:outline-none`}>
                {trendText}
            </button>
        );
    };
    
    const Avatar = student.gender === 'female' 
        ? <GirlAvatarIcon className="w-24 h-24 text-indigo-200" />
        : <BoyAvatarIcon className="w-24 h-24 text-indigo-200" />;

    return (
        <div className="p-4 bg-gray-50 min-h-[calc(100vh-5rem)] flex flex-col items-center justify-center text-center">
            <div className="w-full max-w-sm">
                <header className="mb-8">
                    <div className="flex justify-center items-center mb-4">
                        <div className="p-4 bg-white rounded-full shadow-lg">
                            {Avatar}
                        </div>
                    </div>
                    <h1 className="text-3xl font-bold text-gray-800">
                        מרכז הכוח של {student.firstName}
                    </h1>
                     <div className="mt-2 text-lg font-semibold bg-yellow-200 text-yellow-800 inline-block px-4 py-1 rounded-full">
                         <StarIcon className="w-5 h-5 inline-block ml-2 mb-1" />
                         דרגה {student.gamification.level}: {getLevelName(student.gamification.level)}
                     </div>
                </header>

                <div className="bg-white p-6 rounded-2xl shadow-xl mb-8">
                    <p className="text-sm text-gray-500 mb-1">מדד החוסן הכללי שלך</p>
                    <div className="flex justify-center items-center space-x-4 space-x-reverse">
                        <p className={`text-7xl font-bold ${globalAverage ? (globalAverage > 7 ? 'text-green-500' : globalAverage < 5 ? 'text-red-500' : 'text-yellow-500') : 'text-gray-400'}`}>
                            {globalAverage ? globalAverage.toFixed(1) : 'N/A'}
                        </p>
                         <ResilienceDialIcon score={globalAverage} />
                    </div>
                    <div className="mt-2 h-6">
                        <TrendTextComponent />
                    </div>
                </div>

                <div className="text-center space-y-4">
                     <button 
                        onClick={onStartReport}
                        className="w-full bg-indigo-600 text-white font-bold py-4 px-6 rounded-lg shadow-lg hover:bg-indigo-700 transform hover:-translate-y-1 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        מלא דיווח מ'מצב
                    </button>
                    <button 
                       onClick={onGoToFunCorner}
                       className="w-full bg-pink-500 text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-pink-600 transform hover:-translate-y-1 transition-all duration-300 ease-in-out focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-400 flex items-center justify-center"
                   >
                       <GiftIcon className="w-6 h-6 ml-2" />
                       <span>פינת הכיף</span>
                   </button>
                </div>
            </div>
            
            {isModalOpen && trendRecord && (
                <ReportDetailsModal record={trendRecord} onClose={() => setIsModalOpen(false)} />
            )}
        </div>
    );
};

const FunCorner: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const funItems = [
        {
          id: 1,
          title: "תרגיל נשימות מרגיע",
          description: "סרטון קצר שילמד אתכם איך להירגע בכמה דקות בעזרת נשימות פשוטות.",
          imageUrl: "https://images.unsplash.com/photo-1506126613408-4e61f36d50da?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://www.youtube.com/watch?v=bF_1KAl_S_I",
          category: 'סרטון',
          categoryColor: 'bg-red-100 text-red-800'
        },
        {
          id: 2,
          title: "משחק ציור אינטראקטיבי",
          description: "ציירו, קשקשו ותנו ליצירתיות שלכם להתפרץ במשחק ציור כיפי ומרגיע.",
          imageUrl: "https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://sketch.io/sketchpad/",
          category: 'משחק',
          categoryColor: 'bg-blue-100 text-blue-800'
        },
        {
          id: 3,
          title: "להבין את הרגשות שלנו",
          description: "כתבה קצרה שמסבירה למה אנחנו מרגישים מה שאנחנו מרגישים ואיך אפשר להתמודד.",
          imageUrl: "https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://www.mental.org.il/blog/how-to-deal-with-emotions-and-feelings/",
          category: 'כתבה',
          categoryColor: 'bg-green-100 text-green-800'
        },
        {
          id: 4,
          title: "פלייליסט רגוע לריכוז",
          description: "מוזיקה שקטה ונעימה שתעזור לכם להתרכז בלימודים או פשוט לנוח.",
          imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://www.youtube.com/watch?v=5qap5aO4i9A",
          category: 'סרטון',
          categoryColor: 'bg-red-100 text-red-800'
        },
         {
          id: 5,
          title: "פאזלים מאתגרים",
          description: "אתגרו את המוח שלכם עם פאזלים כיפיים ברמות שונות. זמן מצוין להתרכז ולהירגע.",
          imageUrl: "https://images.unsplash.com/photo-1593941707882-6b29355ade6f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://www.jigsawplanet.com/",
          category: 'משחק',
          categoryColor: 'bg-blue-100 text-blue-800'
        },
        {
          id: 6,
          title: "תרגיל התמקדות בטבע",
          description: "תרגיל קצר שיעזור לכם להתחבר לרגע הנוכחי דרך התבוננות בטבע שמסביבכם.",
          imageUrl: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=60",
          link: "https://www.youtube.com/watch?v=Td9j_gu-S_A",
          category: 'תרגיל',
          categoryColor: 'bg-yellow-100 text-yellow-800'
        }
    ];

    const FunCard = ({ item }: { item: typeof funItems[0] }) => (
        <a href={item.link} target="_blank" rel="noopener noreferrer" className="block bg-white rounded-xl shadow-lg hover:shadow-2xl transform hover:-translate-y-2 transition-all duration-300 overflow-hidden group">
            <div className="relative">
                <img src={item.imageUrl} alt={item.title} className="w-full h-40 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                <span className={`absolute top-2 left-2 text-xs font-bold py-1 px-2.5 rounded-full ${item.categoryColor}`}>{item.category}</span>
            </div>
            <div className="p-4">
                <h3 className="font-bold text-lg text-gray-800 mb-2 group-hover:text-indigo-600 transition-colors">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.description}</p>
            </div>
        </a>
    );

    return (
        <div className="p-4 bg-gray-100 min-h-screen">
            <div className="max-w-5xl mx-auto">
                <header className="flex items-center mb-6">
                    <button onClick={onBack} className="text-indigo-600">
                        <ChevronLeftIcon className="w-8 h-8 transform rotate-180" />
                    </button>
                    <h1 className="text-3xl font-bold text-gray-800 mr-2">
                        פינת הכיף
                    </h1>
                </header>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {funItems.sort((a, b) => a.id - b.id).map(item => <FunCard key={item.id} item={item} />)}
                </div>
            </div>
        </div>
    );
};


const StudentDashboard: React.FC = () => {
  const { user } = useAuth();
  const { addToast } = useToast();
  const [student, setStudent] = useState<Student | null>(null);
  const [mentor, setMentor] = useState<User | null>(null);
  const [moodRecords, setMoodRecords] = useState<MoodRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [view, setView] = useState<StudentView>('dashboard');

  const fetchData = useCallback(async () => {
    if (user) {
      setIsLoading(true);
      try {
        const [studentData, recordsData] = await Promise.all([
            apiService.getStudentById(user.id),
            apiService.getMoodRecordsForStudent(user.id)
        ]);
        setStudent(studentData as Student);
        setMoodRecords(recordsData);
        if (studentData?.mentorId) {
            const mentorData = await apiService.getUserById(studentData.mentorId);
            setMentor(mentorData || null);
        }
      } catch (error) {
        console.error("Failed to fetch student data:", error);
        addToast("שגיאה בטעינת הנתונים", "error");
      } finally {
        setIsLoading(false);
      }
    }
  }, [user, addToast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const globalAverage = useMemo(() => {
    if (moodRecords.length === 0) return null;
    const sum = moodRecords.reduce((acc, record) => acc + record.averageScore, 0);
    return sum / moodRecords.length;
  }, [moodRecords]);

  const handleSubmit = async (recordData: Omit<MoodRecord, 'id' | 'averageScore' | 'date'>) => {
    if (!student) return;
    setIsSubmitting(true);
    try {
      const fullRecordData = {...recordData, date: new Date().toISOString()};
      await apiService.addMoodRecord(fullRecordData);
      addToast('הדיווח נשלח, כל הכבוד!');
      await fetchData();
      setView('dashboard');
    } catch (error) {
      addToast("שגיאה בשליחת הדיווח", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading || !student) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <p className="text-xl text-gray-600">טוען את מרכז הכוח שלך...</p>
      </div>
    );
  }
  
  switch(view) {
    case 'report_form':
        return (
            <div className="p-4 bg-gray-100 min-h-screen">
                 <div className="max-w-3xl mx-auto">
                     <header className="flex items-center mb-6">
                        <button onClick={() => setView('dashboard')} className="text-indigo-600">
                            <ChevronLeftIcon className="w-8 h-8 transform rotate-180" />
                        </button>
                         <h1 className="text-3xl font-bold text-gray-800 mr-2">
                            מ׳מצב, {student.firstName}?
                         </h1>
                    </header>
                    <WellbeingForm 
                        student={student} 
                        onSubmit={handleSubmit} 
                        isSubmitting={isSubmitting} 
                        onCancel={() => setView('dashboard')}
                        role={student.role}
                        tools={[]}
                    />
                 </div>
            </div>
        );
    case 'fun_corner':
        return <FunCorner onBack={() => setView('dashboard')} />;
    case 'dashboard':
    default:
        return <PersonalPowerCenter 
            student={student} 
            globalAverage={globalAverage}
            moodRecords={moodRecords}
            onStartReport={() => setView('report_form')} 
            onGoToFunCorner={() => setView('fun_corner')} 
            mentor={mentor}
        />;
  }
};

export default StudentDashboard;