import React, { useState, useEffect, useCallback } from 'react';
import { Session, Student, SessionData, RecurringType } from '../types';
import apiService from '../services/apiService';
import { ChevronLeftIcon, XIcon } from '../components/Icons';
import { useToast } from '../hooks/useToast';

// Helper to format date to YYYY-MM-DD for input[type=date]
const toInputDateString = (date: Date): string => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
};

// --- Day Details Modal ---
const DayDetailsModal: React.FC<{
    date: Date | null;
    sessions: Session[];
    onClose: () => void;
    onAddSession: (date: Date) => void;
}> = ({ date, sessions, onClose, onAddSession }) => {
    if (!date) return null;

    const daySessions = sessions
        .filter(s => new Date(s.date).toDateString() === date.toDateString())
        .sort((a, b) => a.time.localeCompare(b.time));

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                 <button onClick={onClose} className="absolute top-4 left-4 text-gray-400 hover:text-gray-600 transition-colors">
                     <XIcon className="w-6 h-6" />
                 </button>
                <h2 className="text-2xl font-bold mb-2 text-gray-800">
                    פגישות ליום
                </h2>
                <p className="text-gray-600 mb-4">{date.toLocaleDateString('he-IL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                
                <div className="space-y-3 max-h-60 overflow-y-auto mb-4 pr-2">
                    {daySessions.length > 0 ? (
                        daySessions.map(session => (
                            <div key={session.id} className="bg-indigo-50 p-3 rounded-md border-r-4 border-indigo-400">
                                <p className="font-bold text-indigo-900">{session.title}</p>
                                <p className="text-sm text-gray-700">{session.time}, {session.place}</p>
                            </div>
                        ))
                    ) : (
                        <p className="text-center text-gray-500 py-4">אין פגישות מתוכננות ליום זה.</p>
                    )}
                </div>

                <div className="mt-6 flex justify-end space-x-3 space-x-reverse">
                    <button
                        type="button"
                        onClick={onClose}
                        className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        ביטול
                    </button>
                    <button
                        onClick={() => onAddSession(date)}
                        className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                        הוסף פגישה חדשה
                    </button>
                </div>
            </div>
        </div>
    );
};

// --- Create Session Modal ---
const CreateSessionModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSubmit: (data: SessionData) => void;
    mentorId: string;
    initialDate: Date;
    isSubmitting: boolean;
}> = ({ isOpen, onClose, onSubmit, mentorId, initialDate, isSubmitting }) => {
    const [students, setStudents] = useState<Student[]>([]);
    const [studentId, setStudentId] = useState('');
    const [place, setPlace] = useState('');
    const [time, setTime] = useState('12:00');
    const [recurring, setRecurring] = useState<RecurringType>('none');
    const [endDate, setEndDate] = useState<string>(toInputDateString(initialDate));

    useEffect(() => {
        apiService.getStudentsForMentor(mentorId).then(setStudents);
    }, [mentorId]);

    useEffect(() => {
        if (students.length > 0 && !studentId) {
            setStudentId(students[0].id);
        }
    }, [students, studentId]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!studentId) {
            alert('יש לבחור תלמיד');
            return;
        }
        onSubmit({
            mentorId,
            studentId,
            title: '', // Title will be generated in dataService
            place,
            startDate: initialDate.toISOString(),
            time,
            recurring,
            endDate: recurring !== 'none' ? new Date(endDate).toISOString() : undefined,
        });
    };

    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md" onClick={(e) => e.stopPropagation()}>
                <h2 className="text-2xl font-bold mb-4 text-gray-800">יצירת פגישה חדשה</h2>
                <p className="mb-4 text-gray-600">בתאריך: {initialDate.toLocaleDateString('he-IL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
                <form onSubmit={handleSubmit}>
                    <div className="space-y-4">
                        <div>
                            <label htmlFor="student" className="block text-sm font-medium text-gray-700">תלמיד/ה</label>
                            <select id="student" value={studentId} onChange={(e) => setStudentId(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                {students.map(s => <option key={s.id} value={s.id}>{s.firstName} {s.lastName}</option>)}
                            </select>
                        </div>
                        <div>
                            <label htmlFor="place" className="block text-sm font-medium text-gray-700">מקום</label>
                            <input type="text" id="place" value={place} onChange={(e) => setPlace(e.target.value)} required className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                        </div>
                        <div>
                            <label htmlFor="time" className="block text-sm font-medium text-gray-700">שעה</label>
                            <input type="time" id="time" value={time} onChange={(e) => setTime(e.target.value)} required className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                        </div>
                        <div>
                            <label htmlFor="recurring" className="block text-sm font-medium text-gray-700">חזרה</label>
                            <select id="recurring" value={recurring} onChange={(e) => setRecurring(e.target.value as RecurringType)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md">
                                <option value="none">ללא חזרה</option>
                                <option value="daily">יומי</option>
                                <option value="weekly">שבועי</option>
                                <option value="monthly">חודשי</option>
                            </select>
                        </div>
                        {recurring !== 'none' && (
                            <div>
                                <label htmlFor="endDate" className="block text-sm font-medium text-gray-700">עד תאריך</label>
                                <input type="date" id="endDate" value={endDate} onChange={(e) => setEndDate(e.target.value)} required className="mt-1 block w-full shadow-sm sm:text-sm border-gray-300 rounded-md" />
                            </div>
                        )}
                    </div>
                    <div className="mt-6 flex justify-end space-x-3 space-x-reverse">
                        <button type="button" onClick={onClose} className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">ביטול</button>
                        <button type="submit" disabled={isSubmitting} className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:bg-gray-400">
                           {isSubmitting ? 'שומר...' : 'שמור פגישה'}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};


const CalendarView: React.FC<{ mentorId: string; onBack: () => void; }> = ({ mentorId, onBack }) => {
    const { addToast } = useToast();
    const [currentDate, setCurrentDate] = useState(new Date());
    const [view, setView] = useState<'month' | 'week' | 'day'>('month');
    const [sessions, setSessions] = useState<Session[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    
    // State for modals
    const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
    const [isDayDetailsModalOpen, setIsDayDetailsModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState<Date | null>(null);

    const [isSubmitting, setIsSubmitting] = useState(false);

    const fetchSessions = useCallback(async () => {
        setIsLoading(true);
        try {
            const fetchedSessions = await apiService.getSessionsForMentor(mentorId);
            setSessions(fetchedSessions);
        } catch (error) {
            console.error("Failed to fetch sessions:", error);
            addToast("שגיאה בטעינת המפגשים", "error");
        } finally {
            setIsLoading(false);
        }
    }, [mentorId, addToast]);

    useEffect(() => {
        fetchSessions();
    }, [fetchSessions]);

    const handleDayClick = (date: Date) => {
        setSelectedDate(date);
        setIsDayDetailsModalOpen(true);
    };

    const handleOpenCreateModal = (date: Date) => {
        setSelectedDate(date);
        setIsDayDetailsModalOpen(false);
        setIsCreateModalOpen(true);
    };

    const handleSessionSubmit = async (data: SessionData) => {
        setIsSubmitting(true);
        try {
            await apiService.addSession(data);
            await fetchSessions();
            addToast("המפגש נוצר בהצלחה");
        } catch(error) {
            addToast("שגיאה ביצירת המפגש", "error");
        } finally {
            setIsSubmitting(false);
            setIsCreateModalOpen(false);
        }
    };

    const changeDate = (amount: number) => {
        const newDate = new Date(currentDate);
        if (view === 'month') newDate.setMonth(newDate.getMonth() + amount);
        else if (view === 'week') newDate.setDate(newDate.getDate() + (amount * 7));
        else newDate.setDate(newDate.getDate() + amount);
        setCurrentDate(newDate);
    };

    const today = new Date();
    const isSameDay = (d1: Date, d2: Date) => d1.getFullYear() === d2.getFullYear() && d1.getMonth() === d2.getMonth() && d1.getDate() === d2.getDate();

    const renderHeader = () => {
        const getWeekHeader = () => {
            const startOfWeek = new Date(currentDate);
            startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
            const endOfWeek = new Date(startOfWeek);
            endOfWeek.setDate(startOfWeek.getDate() + 6);
            
            if (startOfWeek.getMonth() === endOfWeek.getMonth()){
                 return `שבוע של ${startOfWeek.toLocaleDateString('he-IL', {day: 'numeric'})} - ${endOfWeek.toLocaleDateString('he-IL', {day: 'numeric', month: 'long', year: 'numeric'})}`;
            }
            return `שבוע של ${startOfWeek.toLocaleDateString('he-IL', {day: 'numeric', month: 'long'})} - ${endOfWeek.toLocaleDateString('he-IL', {day: 'numeric', month: 'long', year: 'numeric'})}`;
        };

        return (
            <div className="flex items-center justify-between mb-4 p-2 bg-gray-50 rounded-lg">
                <div className="flex items-center">
                     <button onClick={onBack} className="flex items-center text-indigo-600 font-bold">
                        <ChevronLeftIcon className="w-5 h-5 transform rotate-180" /><span className="ml-1 hidden sm:inline">חזור</span>
                    </button>
                    <span className="border-r border-gray-300 h-6 mx-4"></span>
                    <button onClick={() => changeDate(-1)} className="p-2 rounded-full hover:bg-gray-200">&lt;</button>
                    <button onClick={() => setCurrentDate(new Date())} className="mx-2 px-4 py-1.5 border border-gray-300 rounded-md text-sm font-semibold hover:bg-gray-200">היום</button>
                    <button onClick={() => changeDate(1)} className="p-2 rounded-full hover:bg-gray-200">&gt;</button>
                     <h2 className="text-xl font-bold text-gray-700 mr-4">
                        {view === 'month' && currentDate.toLocaleDateString('he-IL', { month: 'long', year: 'numeric' })}
                        {view === 'week' && getWeekHeader()}
                        {view === 'day' && currentDate.toLocaleDateString('he-IL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                    </h2>
                </div>
                <div className="flex items-center space-x-1 space-x-reverse bg-gray-200 rounded-lg p-1">
                    {(['month', 'week', 'day'] as const).map(v => (
                        <button key={v} onClick={() => setView(v)} className={`px-3 py-1 text-sm font-medium rounded-md ${view === v ? 'bg-white shadow' : 'hover:bg-gray-300'}`}>
                            {{ month: 'חודש', week: 'שבוע', day: 'יום' }[v]}
                        </button>
                    ))}
                </div>
            </div>
        );
    };
    
    const renderLoading = () => (
         <div className="flex justify-center items-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600"></div>
        </div>
    );

    const renderMonthView = () => {
        const year = currentDate.getFullYear();
        const month = currentDate.getMonth();
        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const days = Array.from({ length: firstDay + daysInMonth }, (_, i) => i < firstDay ? null : new Date(year, month, i - firstDay + 1));
        const dayNames = ['א', 'ב', 'ג', 'ד', 'ה', 'ו', 'ש'];

        return (
            <div className="grid grid-cols-7 gap-px bg-gray-200 border border-gray-200 rounded-lg overflow-hidden">
                {dayNames.map(day => <div key={day} className="text-center font-semibold py-2 bg-gray-50 text-sm">{day}</div>)}
                {days.map((day, index) => (
                    <div key={index} className={`p-2 bg-white min-h-[120px] ${day ? 'cursor-pointer hover:bg-gray-50' : 'bg-gray-50'}`} onClick={() => day && handleDayClick(day)}>
                        {day && (
                            <>
                                <span className={`text-sm ${isSameDay(day, today) ? 'bg-indigo-600 text-white rounded-full w-6 h-6 flex items-center justify-center font-bold' : ''}`}>{day.getDate()}</span>
                                <div className="mt-1 space-y-1">
                                    {sessions.filter(s => isSameDay(new Date(s.date), day)).sort((a,b) => a.time.localeCompare(b.time)).map(s => (
                                        <div key={s.id} className="text-xs bg-indigo-100 text-indigo-800 p-1 rounded truncate">
                                            {s.time} - {s.title}
                                        </div>
                                    ))}
                                </div>
                            </>
                        )}
                    </div>
                ))}
            </div>
        );
    };

    const renderWeekView = () => {
        const startOfWeek = new Date(currentDate);
        startOfWeek.setDate(currentDate.getDate() - currentDate.getDay());
        const weekDays = Array.from({length: 7}, (_, i) => new Date(startOfWeek.getFullYear(), startOfWeek.getMonth(), startOfWeek.getDate() + i));
        const hours = Array.from({length: 12}, (_, i) => i + 8);

        return (
             <div className="grid grid-cols-8 text-sm border border-gray-200 rounded-lg bg-gray-200 overflow-hidden">
                <div className="bg-gray-50"></div>
                {weekDays.map(day => (
                     <div key={day.toISOString()} className="text-center font-semibold py-2 bg-gray-50 border-b border-r border-gray-200">
                        <span className="text-gray-500">{day.toLocaleDateString('he-IL', { weekday: 'short' })}</span><br/>
                        <span className={`text-lg ${isSameDay(day, today) ? 'bg-indigo-600 text-white rounded-full w-7 h-7 inline-flex items-center justify-center font-bold' : ''}`}>{day.getDate()}</span>
                    </div>
                ))}
                
                {hours.map(hour => (
                    <React.Fragment key={hour}>
                        <div className="flex items-start justify-center pt-1 bg-gray-50 border-b border-gray-200">
                            <span className="text-xs text-gray-500">{hour.toString().padStart(2, '0')}:00</span>
                        </div>
                         {weekDays.map(day => {
                             const daySessions = sessions.filter(s => isSameDay(new Date(s.date), day) && parseInt(s.time.split(':')[0]) === hour);
                             return (
                                <div key={day.toISOString()} className="relative bg-white border-b border-r border-gray-200 min-h-[60px] p-1 space-y-1" onClick={() => handleDayClick(day)}>
                                    {daySessions.map(s => (
                                        <div key={s.id} className="text-xs bg-indigo-100 text-indigo-800 p-1 rounded truncate cursor-pointer hover:bg-indigo-200">
                                            {s.time.split(':')[1]} - {s.title}
                                        </div>
                                    ))}
                                </div>
                             )
                         })}
                    </React.Fragment>
                ))}
             </div>
        );
    };

    const renderDayView = () => {
        const daySessions = sessions.filter(s => isSameDay(new Date(s.date), currentDate)).sort((a,b) => a.time.localeCompare(b.time));
        return (
             <div className="bg-white p-4 rounded-lg shadow-md">
                {daySessions.length > 0 ? (
                    daySessions.map(session => (
                        <div key={session.id} className="p-3 border-b">
                            <p className="font-bold text-lg">{session.time}</p>
                            <div className="pl-4">
                                <p className="text-indigo-700 font-semibold">{session.title}</p>
                                <p className="text-gray-600">{session.place}</p>
                            </div>
                        </div>
                    ))
                ) : (
                    <p className="text-center text-gray-500 py-16">אין פגישות מתוכננות להיום.</p>
                )}
                 <button onClick={() => handleOpenCreateModal(currentDate)} className="mt-4 w-full bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors">
                    הוסף פגישה
                </button>
            </div>
        );
    };

    return (
        <div className="p-4">
            {renderHeader()}
            {isLoading ? renderLoading() : (
                <>
                    {view === 'month' && renderMonthView()}
                    {view === 'week' && renderWeekView()}
                    {view === 'day' && renderDayView()}
                </>
            )}

            {isDayDetailsModalOpen && (
                <DayDetailsModal 
                    date={selectedDate} 
                    sessions={sessions} 
                    onClose={() => setIsDayDetailsModalOpen(false)} 
                    onAddSession={handleOpenCreateModal} 
                />
            )}

            {isCreateModalOpen && selectedDate && (
                <CreateSessionModal 
                    isOpen={isCreateModalOpen} 
                    onClose={() => setIsCreateModalOpen(false)} 
                    onSubmit={handleSessionSubmit} 
                    mentorId={mentorId}
                    initialDate={selectedDate}
                    isSubmitting={isSubmitting}
                />
            )}
        </div>
    );
};

export default CalendarView;