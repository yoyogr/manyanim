import React from 'react';
import { useAuth } from '../hooks/useAuth';
import MentorDashboard from './MentorDashboard';
import AdminPanelScreen from './AdminPanelScreen';


const AdminDashboard: React.FC = () => {
    const { adminView } = useAuth();

    return adminView ? <AdminPanelScreen /> : <MentorDashboard />;
};

export default AdminDashboard;