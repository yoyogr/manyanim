
import React, { createContext, useState, useContext, useEffect, ReactNode, useCallback } from 'react';
import { User, Role } from '../types';
import apiService from '../services/apiService';
import { useToast } from './useToast';

interface AuthContextType {
  user: User | null;
  login: (phone: string, rememberMe?: boolean) => Promise<boolean>;
  logout: () => void;
  loading: boolean;
  isAdmin: boolean;
  isMentor: boolean;
  isStudent: boolean;
  adminView: boolean;
  setAdminView: (isAdminView: boolean) => void;
  isImpersonating: boolean;
  exitImpersonation: () => Promise<void>;
  startImpersonation: (jsonData: string) => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [adminView, setAdminView] = useState(false);
  const [isImpersonating, setIsImpersonating] = useState(false);
  const { addToast } = useToast();

  const logout = useCallback(() => {
    setUser(null);
    setAdminView(false);
    setIsImpersonating(false);
    localStorage.removeItem('rememberedUserId');
    // Also clear impersonation state on logout
    localStorage.removeItem('impersonating_user_id');
    sessionStorage.removeItem('admin_data_backup');
    sessionStorage.removeItem('admin_id_backup');
  }, []);

  const performLogin = useCallback(async (userId: string) => {
    try {
        const loggedInUser = await apiService.getUserById(userId);
        if (loggedInUser) {
            setUser(loggedInUser);
        } else {
             // Handle case where user from storage is not found
             logout();
        }
    } catch (error) {
        console.error("Failed to login user:", error);
        logout();
    }
  }, [logout]);

  useEffect(() => {
    const checkUser = async () => {
      setLoading(true);
      const impersonatedUserId = localStorage.getItem('impersonating_user_id');
      const storedUserId = localStorage.getItem('rememberedUserId');
      
      if (impersonatedUserId) {
        setIsImpersonating(true);
        await performLogin(impersonatedUserId);
      } else if (storedUserId) {
        setIsImpersonating(false);
        await performLogin(storedUserId);
      } else {
        setIsImpersonating(false);
        setUser(null);
      }
      setLoading(false);
    }
    checkUser();
  }, [performLogin]);

  const login = useCallback(async (phone: string, rememberMe: boolean = false): Promise<boolean> => {
    setLoading(true);
    setAdminView(false); // Reset admin view on new login
    // Clear any potential impersonation state when doing a real login
    localStorage.removeItem('impersonating_user_id');
    sessionStorage.removeItem('admin_data_backup');
    sessionStorage.removeItem('admin_id_backup');
    setIsImpersonating(false);

    try {
        const loggedInUser = await apiService.login(phone);
        if (loggedInUser) {
          setUser(loggedInUser);
          if (rememberMe) {
            localStorage.setItem('rememberedUserId', loggedInUser.id);
          } else {
            localStorage.removeItem('rememberedUserId');
          }
          return true;
        }
        return false;
    } catch (error) {
        console.error("Login failed:", error);
        return false;
    } finally {
        setLoading(false);
    }
  }, []);

  const startImpersonation = useCallback(async (jsonData: string): Promise<boolean> => {
      setLoading(true);
      try {
          const result = await apiService.loadBackupForImpersonation(jsonData);
          if (result.success && result.impersonatedUserId) {
              addToast(`טוען גיבוי...`, 'info');
              await performLogin(result.impersonatedUserId);
              setIsImpersonating(true);
              return true;
          } else {
              addToast(result.error || 'שגיאה בטעינת הגיבוי', 'error');
              return false;
          }
      } catch (e: any) {
          addToast(`שגיאה קריטית: ${e.message}`, 'error');
          return false;
      } finally {
          setLoading(false);
      }
  }, [addToast, performLogin]);

  const exitImpersonation = useCallback(async () => {
    setLoading(true);
    try {
        const adminId = await apiService.exitImpersonation();
        if(adminId) {
            addToast("יוצא ממצב התחזות...", "info");
            await performLogin(adminId);
            setIsImpersonating(false);
        } else {
            addToast("שגיאה ביציאה ממצב התחזות", "error"); 
        }
    } catch (error) {
        addToast("שגיאה קריטית ביציאה ממצב התחזות", "error");
    } finally {
        setLoading(false);
    }
  }, [addToast, performLogin]);

  const value = {
    user,
    login,
    logout,
    loading,
    isAdmin: user?.role === Role.Admin,
    isMentor: user?.role === Role.Mentor || user?.role === Role.Admin,
    isStudent: user?.role === Role.Student,
    adminView,
    setAdminView,
    isImpersonating,
    exitImpersonation,
    startImpersonation,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
