import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { MoodRecord, Student, Tool, ToolType } from '../types';
import apiService from './apiService';

// The API key must be set in the environment variables.
// For this example, we assume `process.env.API_KEY` is available.
const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. Gemini features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const formatToolsForPrompt = (tools: Tool[]): string => {
  return tools.map(tool => 
    `---
    Tool ID: ${tool.id}
    Name: ${tool.name}
    Category: ${tool.category}
    Disciplines: ${tool.disciplines.join(', ').replace(/\[|\]\(https?:\/\/[^\)]+\)/g, '')}
    Good for: ${tool.fits_for.join(', ')}
    Explanation: ${tool.explanation}
    ---`
  ).join('\n');
};

export const getActionRecommendation = async (student: Student, record: MoodRecord): Promise<string> => {
  if (!API_KEY) {
    return "שירות ה-AI אינו זמין. יש להגדיר מפתח API.";
  }

  try {
    const tools = await apiService.getTools();
    const formattedTools = formatToolsForPrompt(tools);
    
    const formatScoreForPrompt = (score: number | null, evidence: string) => {
        if (score === null) return 'לא דורג';
        return `${score}/10 ("${evidence || 'לא צוין'}")`;
    }

    const prompt = `
      חוקת ה-AI:
      1. הזהות שלך: אתה מנוע המלצות כלים.
      2. המטרה: להמליץ לחונך על הכלי **האחד** המתאים ביותר מתוך "ארגז הכלים" שסופק לך.
      3. קווים אדומים: **אסור לך בתכלית האיסור לתת עצות כלליות.** תשובתך חייבת להתבסס **אך ורק** על הכלים מהרשימה.
      4. פורמט פלט: התשובה חייבת להיות **קצרה מאוד ותכליתית**, בפורמט של נקודות (בולטים), למשל:
        * **כלי מומלץ:** [שם הכלי]
        * **למה?** [הסבר קצרצר]

      **הקשר:**
      תלמיד: ${student.firstName} ${student.lastName}.
      דיווח אחרון:
      - רגשי: ${formatScoreForPrompt(record.emotionalScore, record.emotionalEvidence)}
      - חברתי: ${formatScoreForPrompt(record.socialScore, record.socialEvidence)}
      - לימודי: ${formatScoreForPrompt(record.academicScore, record.academicEvidence)}
      - אישי: ${formatScoreForPrompt(record.personalScore, record.personalEvidence)}

      **רשימת כלים זמינה:**
      ${formattedTools}

      **המשימה שלך:**
      1. נתח את דיווח התלמיד וזהה את האתגר המרכזי על סמך התחומים שדורגו.
      2. בחר את הכלי **האחד** המתאים ביותר מתוך הרשימה שסופקה לך.
      3. הגש את ההמלצה בפורמט המדויק שנדרש בחוקה. אל תוסיף שום מלל נוסף.
    `;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API:", error);
    return "אירעה שגיאה בקבלת המלצה מה-AI. נסה שוב מאוחר יותר.";
  }
};

export const getConsultationAdvice = async (query: string): Promise<string> => {
  if (!API_KEY) {
    return JSON.stringify({ error: "שירות ה-AI אינו זמין. יש להגדיר מפתח API." });
  }

  try {
    const allTools = await apiService.getTools();
    
    if (allTools.length === 0) {
      return JSON.stringify({
        understanding: `לא נמצאו כלים במערכת.`,
        recommendations: []
      });
    }

    const formattedTools = formatToolsForPrompt(allTools);

    const prompt = `
      חוקת ה-AI:
      1. הזהות שלך: יועץ AI מקצועי, אמפתי ותומך. מטרתך היא לעזור לחונך למצוא כלים מעשיים מתוך מאגר נתון.
      2. המטרה: להמליץ לחונך **אך ורק** על כלים רלוונטיים מתוך "ארגז הכלים" שסופק לך.
      3. קווים אדומים: **לעולם אל תאבחן מצב רפאי, נפשי או רגשי.** אתה יכול להציע אפשרויות על בסיס מידע, אך תמיד תבהיר שאינך כלי אבחוני. במקרה של חשש לפגיעה עצמית, הנחה את החונך לפנות לגורם המוסמך בבית הספר.
      4. פורמט פלט: התשובה חייבת להיות **אך ורק** בפורמט JSON.
      5. טון: **תמציתי, תכליתי, בפורמט של נקודות (bullet points) בלבד. התשובה חייבת להיות קצרה מאוד.**
      6. העצמה: תמיד הזכר לחונך שהקשר האישי והשיפוט שלו בשטח הם החשובים ביותר.
      
      חונך פנה אליך עם הסוגיה הבאה:
      "${query}"

      לרשותך "ארגז כלים". להלן רשימת הכלים:
      ${formattedTools}

      **המשימה שלך:**
      1. נתח את שאלת החונך.
      2. סכם במשפט אחד את הבנתך לגבי הבעיה המרכזית.
      3. בחר 1 עד 3 כלים מהרשימה שהם הרלוונטיים ביותר לבעיה שזיהית.
      4. החזר JSON ובו אובייקט עם שני שדות: 
         - 'understanding': סיכום קצר של הבעיה שהבנת מדברי החונך.
         - 'recommendations': מערך של אובייקטים, כל אחד עם 'id' (שהוא מספר) ו-'name' של הכלי המומלץ.
    `;
    
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            understanding: { type: Type.STRING },
            recommendations: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.NUMBER },
                  name: { type: Type.STRING }
                }
              }
            }
          }
        }
      }
    });
    
    return response.text;
  } catch (error) {
    console.error("Error calling Gemini API for consultation:", error);
    return JSON.stringify({ error: "אירעה שגיאה בקבלת ייעוץ מה-AI. נסה שוב מאוחר יותר." });
  }
};