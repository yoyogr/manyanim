import { Role, User, Student, MoodRecord, Session, SessionData, VoiceNote, Tool, Intervention, AlertSeverity, Gender, Alert, Feedback, FeedbackType, FeedbackStatus } from '../types';
import { WellbeingFormData } from '../components/WellbeingForm';


let users: (User | Student)[] = [];
let moodRecords: MoodRecord[] = [];
let sessions: Session[] = [];
let voiceNotes: VoiceNote[] = [];
let tools: Tool[] = [];
let interventions: Intervention[] = [];
let feedback: Feedback[] = [];

const initialToolsData: Omit<Tool, 'id'>[] = [
    {
        name: "נשימות 5-5-5",
        category: "במפגש",
        disciplines: ["Mindfulness"],
        fits_for: ["לחץ", "חרדה", "הצפה רגשית"],
        how_to: {
            prep: "טיימר/ספירה, מקום שקט.",
            steps: ["ישיבה זקופה, יד על הבטן.", "שאיפה 5 שניות, החזקת אוויר 5 שניות, נשיפה 5 שניות.", "לחזור על התהליך מספר פעמים.", "לסיום, לשאול: \"איך הגוף מרגיש עכשיו?\""]
        },
        explanation: "ויסות מערכת העצבים דרך נשימה קצובה.",
        expected_outcome: "ירידת עוררות ותחושת שליטה.",
        do_nots: ["לא ללחוץ אם יש סחרחורת או אסתמה."],
        success_signs: ["נשימה עמוקה יותר ודיווח על רגיעה."]
    },
    {
        name: "Grounding 5-4-3-2-1",
        category: "במפגש",
        disciplines: ["Grounding/ACT"],
        fits_for: ["חרדה", "דיסוציאציה", "הצפה תחושתית"],
        how_to: {
            prep: "אין צורך בהכנה מיוחדת.",
            steps: ["לזהות 5 דברים שרואים.", "לזהות 4 צלילים ששומעים.", "לזהות 3 תחושות מגע.", "לזהות 2 ריחות.", "לזהות טעם אחד או מחשבה מיטיבה אחת.", "לשמור על קצב איטי."]
        },
        explanation: "עיגון בחושים להחזרת נוכחות לכאן ועכשיו.",
        expected_outcome: "חזרה להווה וירידה בתחושת הניתוק.",
        do_nots: ["לא להכריח לעצום עיניים."],
        success_signs: ["נשימה מסתדרת, קול יציב."]
    },
    {
        name: "סריקת גוף מואצת",
        category: "במפגש",
        disciplines: ["Mindfulness"],
        fits_for: ["מתח כללי", "זיהוי דפוסים גופניים"],
        how_to: {
            prep: "מחצלת/כיסא נוח.",
            steps: ["הנחיה מבהונות לראש, לשים לב לתחושות בלי לנסות לשנות.", "סיום בנשימה עמוקה ושיתוף תחושות."]
        },
        explanation: "מודעות לא שיפוטית לגוף.",
        expected_outcome: "ירידת מתח וזיהוי דפוסי אחיזה גופניים.",
        do_nots: ["לא לנסות 'לתקן' תחושה, רק לשים לב."],
        success_signs: ["תיאור תחושות מדויק.", "ירידת מתח מדווחת."]
    },
    {
        name: "כיסא ריק",
        category: "במפגש",
        disciplines: ["פסיכודרמה"],
        fits_for: ["קונפליקט בין-אישי", "כעס", "אבל"],
        how_to: {
            prep: "שני כיסאות.",
            steps: ["כיסא ממול מייצג אדם/חלק.", "החונך מזמין דיאלוג בקול.", "לאחר מכן הילד מחליף כיסאות ומגיב כ'דמות'.", "סוגרים בסיכום אישי."]
        },
        explanation: "החצנת קונפליקט לדיאלוג מאפשרת מרחק ותובנות.",
        expected_outcome: "תחושת הקלה ותובנה חדשה.",
        do_nots: ["לא להכריח לשחק דמות אם יש מבוכה."],
        success_signs: ["אמירה חדשה או שינוי רגשי.", "רגיעה אחרי שיא רגשי."]
    },
    {
        name: "דיאלוג חלקים",
        category: "במפגש",
        disciplines: ["NLP/IES"],
        fits_for: ["אמביוולנטיות", "דחיינות", "קונפליקט פנימי"],
        how_to: {
            prep: "דף/פתקים לשמות החלקים.",
            steps: ["לזהות 2-3 'חלקים' שונים (למשל, ה'מבקר' וה'יצירתי').", "לתת לכל חלק קול או ציור.", "לחפש צורך משותף או פשרה."]
        },
        explanation: "חלקים הם משאבים בעלי כוונות חיוביות.",
        expected_outcome: "פיוס פנימי והסכמה על פעולה.",
        do_nots: ["לא לתייג חלק כ'רע'."],
        success_signs: ["מציאת פעולה שכל החלקים מסכימים עליה."]
    },
    {
        name: "ריפריימינג מהיר",
        category: "במפגש",
        disciplines: ["NLP/CBT/Cognitive Reframing"],
        fits_for: ["אמונות מגבילות", "ביקורת עצמית"],
        how_to: {
            prep: "דף ושני טורים.",
            steps: ["לרשום מחשבה שלילית.", "לשאול 'איך היא מגינה עליי?' או 'מה הכוונה החיובית שלה?'.", "לנסח חלופה מועילה וריאלית."]
        },
        explanation: "שינוי מסגור קוגניטיבי מגדיל את חופש הפעולה.",
        expected_outcome: "מחשבה גמישה ומאוזנת יותר.",
        do_nots: ["לא לקפוץ ל'חיובי מוגזם' ולא ריאלי."],
        success_signs: ["התלמיד אומר 'זה מרגיש אפשרי'."]
    },
    {
        name: "טבלת ראיות",
        category: "במפגש",
        disciplines: ["CBT"],
        fits_for: ["חרדה", "דיכאון", "חשיבה שלילית"],
        how_to: {
            prep: "טבלה: מחשבה / ראיות בעד / ראיות נגד / חלופה.",
            steps: ["למלא יחד את הטבלה.", "לבדוק אובייקטיביות של ה'ראיות'.", "לנסח מחשבה חלופית מאוזנת."]
        },
        explanation: "בדיקת מציאות מפחיתה עיוותי חשיבה.",
        expected_outcome: "מחשבה מאוזנת יותר.",
        do_nots: ["לא לקבל 'ככה הרגשתי' כראיה אובייקטיבית."],
        success_signs: ["ניסוח מחשבה חלופית וירידה מדווחת בעוצמת הרגש."]
    },
    {
        name: "סולם רגשות 0-10",
        category: "במפגש",
        disciplines: ["CBT/SEL"],
        fits_for: ["ויסות רגשי", "הצפה"],
        how_to: {
            prep: "סרגל/כרטיס עם סקאלה מ-0 עד 10.",
            steps: ["לדרג את עוצמת הרגש.", "לשאול 'מה יעזור להוריד את הציון בנקודה אחת?'.", "לבחור פעולה קטנה ולבדוק את הדירוג שוב בסוף."]
        },
        explanation: "כימות הרגש מקטין עמימות ומעודד פעולה.",
        expected_outcome: "זיהוי צעד ישים להרגעה.",
        do_nots: ["לא לשפוט את הציון שהתלמיד נותן."],
        success_signs: ["פעולה ברורה נבחרה ובוצעה."]
    },
    {
        name: "מטפורת האוטובוס",
        category: "במפגש",
        disciplines: ["ACT"],
        fits_for: ["הימנעות", "מחשבות חודרניות"],
        how_to: {
            prep: "דף לציור אוטובוס.",
            steps: ["הנהג הוא הערכים, הנוסעים הם מחשבות קשות.", "לזהות פעולה שניתן לעשות למרות ה'נוסעים' המפריעים."]
        },
        explanation: "לחיות לצד מחשבות, לא נגדן.",
        expected_outcome: "מחויבות לפעולה המונחית על ידי ערכים.",
        do_nots: ["לא להבטיח שה'נוסעים' ייעלמו."],
        success_signs: ["צעד שנעשה למרות מחשבה מטרידה."]
    },
    {
        name: "פסל חי",
        category: "במפגש",
        disciplines: ["פסיכודרמה / תרפיה באמנות"],
        fits_for: ["ביטוי לא-מילולי", "הצפה רגשית"],
        how_to: {
            prep: "חלל פנוי לתנועה.",
            steps: ["לבחור תנוחה שמייצגת רגש.", "לשנות את התנוחה ולבדוק את השינוי בתחושה."]
        },
        explanation: "הגוף כערוץ לביטוי ושינוי.",
        expected_outcome: "חוויית שינוי רגשי דרך הגוף.",
        do_nots: ["לא לגעת בלי רשות.", "לא לצלם ללא אישור מפורש."],
        success_signs: ["דיווח על תחושה אחרת אחרי שינוי התנוחה."]
    },
    {
        name: "מפת חוזקות מהירה",
        category: "במפגש",
        disciplines: ["פסיכולוגיה חיובית"],
        fits_for: ["דימוי עצמי", "מוטיבציה"],
        how_to: {
            prep: "רשימת חוזקות (למשל, מ-VIA) או כרטיסיות.",
            steps: ["לבחור 5 חוזקות בולטות.", "לתת דוגמה חיה לכל אחת.", "לבחור חוזקה אחת לשימוש למחרת."]
        },
        explanation: "זיהוי משאבים פנימיים מגביר מסוגלות.",
        expected_outcome: "תחושת מסוגלות מוגברת.",
        do_nots: ["לא להשוות לאחרים."],
        success_signs: ["שימוש יזום בחוזקה שנבחרה."]
    },
    {
        name: "חפץ עוגן",
        category: "במפגש",
        disciplines: ["Mindfulness/NLP"],
        fits_for: ["חרדה", "התקפי פאניקה"],
        how_to: {
            prep: "מבחר חפצים קטנים (אבן, צדף).",
            steps: ["לבחור חפץ.", "להתבונן בו בכל החושים.", "לקשר אותו לזיכרון נעים או תחושת רוגע.", "לתרגל אחיזה + נשימה."]
        },
        explanation: "קישור גירוי חושי לתחושת רוגע.",
        expected_outcome: "כלי זמין ומהיר לוויסות עצמי בשטח.",
        do_nots: ["לא לבחור חפץ מביך או גדול מדי."],
        success_signs: ["שימוש עצמאי בחפץ בזמן מצוקה."]
    },
    {
        name: "מכתב שלא יישלח",
        category: "משימה לתלמיד",
        disciplines: ["ביבליותרפיה"],
        fits_for: ["כעס", "אבל", "עלבון"],
        how_to: {
            prep: "דף וכלי כתיבה.",
            steps: ["כתיבה חופשית 5-10 דקות לאדם/אירוע.", "החלטה משותפת מה עושים עם המכתב בסוף."]
        },
        explanation: "פורקן רגשי ללא השלכות במציאות.",
        expected_outcome: "ארגון רגשות ותחושת הקלה.",
        do_nots: ["לא לקרוא את המכתב ללא הסכמה מפורשת."],
        success_signs: ["דיווח על תחושת הקלה או סגירת מעגל זמנית."]
    },
    {
        name: "הסיפור המקביל",
        category: "במפגש",
        disciplines: ["טיפול נרטיבי"],
        fits_for: ["זהות", "בדידות", "התמודדות"],
        how_to: {
            prep: "סיפור קצר או קליפ.",
            steps: ["למצוא גיבור עם התמודדות דומה.", "לדון בנקודות הדמיון והשוני.", "לשאול: 'מה הוא עשה שאני יכול לנסות?'"]
        },
        explanation: "הזדהות עקיפה מאפשרת למידה והרחבת אפשרויות.",
        expected_outcome: "יצירת אסטרטגיות התמודדות חדשות.",
        do_nots: ["לא לכפות סיפור שאינו מתאים תרבותית."],
        success_signs: ["רעיון לפעולה שנולד בהשראת הסיפור."]
    },
    {
        name: "רישום רגשות בצבע",
        category: "במפגש",
        disciplines: ["תרפיה באמנות"],
        fits_for: ["הצפה רגשית", "קושי במילול"],
        how_to: {
            prep: "דפים, צבעים (פנדה, מים).",
            steps: ["לבחור 3 רגשות.", "לתת לכל אחד צבע/צורה.", "למלא דף ולשוחח על העוצמות והמיקומים."]
        },
        explanation: "סימבוליזציה חזותית של רגשות.",
        expected_outcome: "יצירת שפה חזותית לרגש.",
        do_nots: ["לא לפרש את הציור בלי לשאול את הילד."],
        success_signs: ["הילד מסביר במילותיו את משמעות הציור."]
    },
    {
        name: "מנדלה מיינדפולית",
        category: "במפגש",
        disciplines: ["תרפיה באמנות / Mindfulness"],
        fits_for: ["הרגעה", "קשב", "אימפולסיביות"],
        how_to: {
            prep: "תבניות מנדלה מודפסות או דף וצבעים.",
            steps: ["לצבוע/לצייר בקצב הנשימה.", "לשים לב למחשבות חולפות ללא שיפוט."]
        },
        explanation: "פעולה מחזורית מרגיעה וממקדת.",
        expected_outcome: "ירידת עוררות.",
        do_nots: ["לא להפוך למשימת דיוק וביצוע."],
        success_signs: ["דיווח על 'כניסה לזרימה' או רגיעה."]
    },
    {
        name: "הרגש היה חיה/חפץ",
        category: "במפגש",
        disciplines: ["טיפול נרטיבי / תרפיה באמנות"],
        fits_for: ["מודעות רגשית", "ויסות"],
        how_to: {
            prep: "דף, צבעים.",
            steps: ["לשאול: 'אם הרגש הזה היה חיה או חפץ, מה הוא היה?'.", "לצייר/לתאר.", "לחזור לשאלה: 'ומה אני צריך עכשיו?'"]
        },
        explanation: "החצנת הרגש מפחיתה את האיום ומבהירה את הצורך.",
        expected_outcome: "זיהוי צורך רגשי.",
        do_nots: ["לא להישאר רק במטפורה, לחזור לצורך הממשי."],
        success_signs: ["ניסוח צורך או בקשה ברורה."]
    },
    {
        name: "שיחת SMART בזק",
        category: "במפגש",
        disciplines: ["Coaching", "פסיכולוגיה חיובית", "CBT/SMART"],
        fits_for: ["דחיינות", "חוסר בהירות"],
        how_to: {
            prep: "טופס SMART קצר.",
            steps: ["להפוך מטרה כללית למטרה ספציפית, מדידה, ברת השגה, רלוונטית ומוגבלת בזמן (SMART).", "לבחור צעד ראשון ותזמון."]
        },
        explanation: "מטרה ברורה מניעה לפעולה.",
        expected_outcome: "התחייבות לביצוע צעד קונקרטי.",
        do_nots: ["לא להגדיר מטרה של ההורה/מורה, אלא של התלמיד."],
        success_signs: ["צעד ראשון הוגדר ובוצע."]
    },
    {
        name: "גלגל ההשפעה",
        category: "במפגש",
        disciplines: ["Coaching"],
        fits_for: ["חוסר אונים", "לחץ סביבתי"],
        how_to: {
            prep: "דף עם שני מעגלים (שליטה/השפעה ומחוץ לשליטה).",
            steps: ["למיין גורמים לשני המעגלים.", "לבחור פעולה אחת במעגל הפנימי (שליטה/השפעה)."]
        },
        explanation: "מיקוד במה שאפשרי.",
        expected_outcome: "מעבר מחוסר אונים לפעולה.",
        do_nots: ["לא לבטל את תחושת חוסר האונים, אלא להוסיף עליה מיקוד שליטה."],
        success_signs: ["פעולה יזומה קטנה בוצעה."]
    },
    {
        name: "הדקה השקטה",
        category: "במפגש",
        disciplines: ["Mindfulness"],
        fits_for: ["מעברים", "הצפה רגשית"],
        how_to: {
            prep: "טיימר/פעמון.",
            steps: ["דקה של שקט, נשימה ותשומת לב.", "בסוף שיתוף קצר של תחושה."]
        },
        explanation: "'ריסט' קשבי קצר.",
        expected_outcome: "ירידת עוררות ומעבר חלק יותר בין פעילויות.",
        do_nots: ["לא להאריך בלי הסכמה."],
        success_signs: ["מעבר חלק יותר לשלב הבא במפגש."]
    },
    {
        name: "יומן מחשבות",
        category: "משימה לתלמיד",
        disciplines: ["CBT"],
        fits_for: ["חרדה", "דיכאון"],
        how_to: {
            prep: "טבלה מודפסת/דיגיטלית.",
            steps: ["כל ערב למלא 3-5 דק': מצב-מחשבה-רגש-תגובה-חלופה."]
        },
        explanation: "מעקב קוגניטיבי מזהה ומפחית עיוותי חשיבה.",
        expected_outcome: "מחשבות מאוזנות יותר.",
        do_nots: ["לא להפוך ל'יומן ייסורים', להתמקד בלמידה."],
        success_signs: ["שינוי בשפה, עקביות במילוי."]
    },
    {
        name: "שלושה דברים טובים",
        category: "משימה לתלמיד",
        disciplines: ["פסיכולוגיה חיובית"],
        fits_for: ["פסימיות", "מצב רוח ירוד"],
        how_to: {
            prep: "מחברת/אפליקציה.",
            steps: ["לפני השינה לרשום 3 דברים טובים שקרו ולמה הם קרו."]
        },
        explanation: "הטיית הקשב לחיובי.",
        expected_outcome: "שיפור במצב הרוח.",
        do_nots: ["לא לדרוש דברים 'גדולים', גם קטנים נחשבים."],
        success_signs: ["המשכיות גם בימים קשים."]
    },
    {
        name: "דקת נשימה מודעת",
        category: "משימה לתלמיד",
        disciplines: ["Mindfulness"],
        fits_for: ["לחץ יום-יומי", "קשב"],
        how_to: {
            prep: "התראה בנייד.",
            steps: ["3 פעמים ביום, דקה של נשימה או התבוננות.", "לרשום לפני/אחרי בקצרה."]
        },
        explanation: "אינטגרציה של מיינדפולנס לשגרה.",
        expected_outcome: "הורדת מתח כללית.",
        do_nots: ["לא לדלג כשלא נוח, דווקא אז חשוב."],
        success_signs: ["פחות התפרצויות, יותר ויסות."]
    },
    {
        name: "צעדי נדיבות",
        category: "משימה לתלמיד",
        disciplines: ["ACT/פסיכולוגיה חיובית"],
        fits_for: ["בדידות", "ירידה במשמעות"],
        how_to: {
            prep: "רשימת רעיונות קטנים.",
            steps: ["פעולה מיטיבה יומית (לחייך למישהו, לעזור).", "רישום תחושה ואפקט."]
        },
        explanation: "פעולה לפי ערכים חברתיים.",
        expected_outcome: "תחושת משמעות וחיבור.",
        do_nots: ["לא לעשות כדי לרצות אחרים, אלא מתוך בחירה."],
        success_signs: ["דיווח על חמימות/סיפוק."]
    },
    {
        name: "מכתב תודה",
        category: "משימה לתלמיד",
        disciplines: ["פסיכולוגיה חיובית"],
        fits_for: ["קשרים", "הכרת תודה"],
        how_to: {
            prep: "דף/מייל.",
            steps: ["כתיבת מכתב תודה מפורט למישהו.", "שליחה - לפי בחירת התלמיד.", "רפלקציה על הרגש."]
        },
        explanation: "הכרת תודה מגבירה רווחה נפשית וקירבה.",
        expected_outcome: "קשרים מחוזקים.",
        do_nots: ["לא לכפות שליחה."],
        success_signs: ["תחושת התרגשות והוקרה."]
    },
    {
        name: "צילום רגעים טובים",
        category: "משימה לתלמיד",
        disciplines: ["פסיכולוגיה חיובית/Mindfulness"],
        fits_for: ["מודעות", "דימוי עצמי"],
        how_to: {
            prep: "טלפון.",
            steps: ["לצלם רגע טוב קטן ביום ולכתוב שורה על למה הוא טוב.", "שיתוף שבועי."]
        },
        explanation: "תיעוד חיובי מחזק זיכרון וקשב לחיובי.",
        expected_outcome: "בניית בנק רגעים חיוביים.",
        do_nots: ["לא לשפוט את איכות הצילום."],
        success_signs: ["מציאת הטוב גם ביום אפור."]
    },
    {
        name: "יומן גוף-רגש",
        category: "משימה לתלמיד",
        disciplines: ["Mindfulness/CBT"],
        fits_for: ["ויסות רגשי", "סומטיזציה"],
        how_to: {
            prep: "טבלה פשוטה.",
            steps: ["פעם ביום: תחושה בגוף - רגש - מה עשיתי. 2 דק'."]
        },
        explanation: "חיבור בין גוף לרגש.",
        expected_outcome: "זיהוי מוקדם של הצפה.",
        do_nots: ["לא לפרש סימפטומים רפואיים."],
        success_signs: ["תגובה מוקדמת לפני 'פיצוץ'."]
    },
    {
        name: "חשיפה קטנה",
        category: "משימה לתלמיד",
        disciplines: ["Exposure Therapy/CBT"],
        fits_for: ["פוביות", "הימנעויות"],
        how_to: {
            prep: "היררכיית פחד קטנה.",
            steps: ["לבחור גירוי קל.", "להיחשף 5-10 דק'.", "למדוד חרדה לפני/אחרי."]
        },
        explanation: "הרגלה הדרגתית מפחיתה פחד.",
        expected_outcome: "ירידת פחד.",
        do_nots: ["לא לדלג על מדרגות בסולם החשיפה."],
        success_signs: ["ירידת ציון חרדה בין חשיפות."]
    },
    {
        name: "שאלת הערכים",
        category: "משימה לתלמיד",
        disciplines: ["ACT-Values"],
        fits_for: ["חוסר כיוון", "דחיינות"],
        how_to: {
            prep: "דף לשאלה שבועית.",
            steps: ["פעם בשבוע לענות: 'מה היה חשוב לי באמת השבוע? מה עשיתי בכיוון?'"]
        },
        explanation: "חיבור לערכים לאורך זמן.",
        expected_outcome: "עקביות ומוטיבציה.",
        do_nots: ["לא להאשים על 'פספוס'."],
        success_signs: ["פעולות קטנות ועקביות בכיוון הערכים."]
    },
    {
        name: "5 דקות יצירה",
        category: "משימה לתלמיד",
        disciplines: ["תרפיה באמנות"],
        fits_for: ["ביטוי עצמי", "הצפה רגשית"],
        how_to: {
            prep: "חומרי יצירה נגישים.",
            steps: ["כל יום 5 דק' יצירה חופשית, בלי מטרה.", "צילום או שמירה."]
        },
        explanation: "פורקן לא שיפוטי.",
        expected_outcome: "שחרור רגשי.",
        do_nots: ["לא לבקר את איכות התוצר."],
        success_signs: ["התמדה ללא לחץ לתוצאה 'יפה'."]
    },
    {
        name: "הליכת מודעות",
        category: "משימה לתלמיד",
        disciplines: ["Mindfulness"],
        fits_for: ["רוגע", "בהירות"],
        how_to: {
            prep: "מסלול הליכה בטוח.",
            steps: ["10 דק' הליכה קשובה לצעדים/נשימה.", "לרשום תובנה בסוף."]
        },
        explanation: "מדיטציה בתנועה.",
        expected_outcome: "רוגע ובהירות מחשבתית.",
        do_nots: ["לא עם מוזיקה או מסך."],
        success_signs: ["דיווח על שקט או בהירות."]
    },
    {
        name: "הגיבור הפנימי",
        category: "משימה לתלמיד",
        disciplines: ["טיפול נרטיבי"],
        fits_for: ["מוטיבציה", "אמונה עצמית"],
        how_to: {
            prep: "מחברת.",
            steps: ["לכתוב סיפור קצר על דמות כמוני שמתקדמת צעד קטן.", "לקרוא לעצמי לפני משימה."]
        },
        explanation: "סיפור כמודל לפעולה.",
        expected_outcome: "יצירת תרחישים חלופיים.",
        do_nots: ["לא לפנטז על הבלתי אפשרי."],
        success_signs: ["צעד בפועל שנלקח מהסיפור."]
    },
    {
        name: "רשימת דאגה מאורגנת",
        category: "משימה לתלמיד",
        disciplines: ["CBT/Rumination"],
        fits_for: ["מחשבות חוזרות", "דאגנות"],
        how_to: {
            prep: "מחברת 'דאגות'.",
            steps: ["להקדיש 10 דק' 'זמן דאגה' יומי.", "לרשום שם את הדאגות בלבד.", "מחוץ לזמן זה - לדחות את הדאגה ל'זמן דאגה'."]
        },
        explanation: "מתן גבולות לדאגה מפחית את חדירתה לשגרה.",
        expected_outcome: "פחות 'הצקות' של דאגות במהלך היום.",
        do_nots: ["לא להתעלם מדאגות קריטיות שדורשות פעולה מיידית."],
        success_signs: ["הפחתה במחשבות טורדניות מחוץ לזמן הדאגה."]
    },
    {
        name: "תיבת משאבים",
        category: "משימה לתלמיד",
        disciplines: ["פסיכולוגיה חיובית / NLP"],
        fits_for: ["חוסר מוטיבציה", "הצפה"],
        how_to: {
            prep: "קופסה/תיקייה דיגיטלית.",
            steps: ["להוסיף בכל שבוע משהו מחזק (תמונה, ציטוט, זיכרון).", "להשתמש בזמני קושי."]
        },
        explanation: "מאגר עוגנים זמין לחוסן.",
        expected_outcome: "עלייה בתחושת מסוגלות.",
        do_nots: ["לא לשמור רק דברים 'מושלמים'."],
        success_signs: ["שימוש יזום בתיבה בזמן מצוקה."]
    },
    {
        name: "אתגר פחות מסך",
        category: "משימה לתלמיד",
        disciplines: ["SEL"],
        fits_for: ["קשב", "התמכרות למסכים"],
        how_to: {
            prep: "לקבוע שעה קבועה.",
            steps: ["שעה ביום ללא מסכים.", "לרשום מה עשיתי ומה הרגשתי."]
        },
        explanation: "הפחתת גירוי יתר.",
        expected_outcome: "שיפור ריכוז והרגלים.",
        do_nots: ["לא להעניש על פספוס."],
        success_signs: ["קל יותר לעמוד בשעה, שימוש בתחליף מוגדר."]
    },
    {
        name: "תוכנית חשיפה מדורגת",
        category: "תהליך ארוך טווח",
        disciplines: ["CBT/Exposure Therapy"],
        fits_for: ["חרדה חברתית/ספציפית"],
        how_to: {
            prep: "לבנות היררכיית פחד מ-0 עד 100.",
            steps: ["להתחיל מדרגה נמוכה.", "להיחשף עד ירידת חרדה ב-50%.", "להתקדם בהדרגה."]
        },
        explanation: "הרגלה שיטתית משנה תגובת פחד.",
        expected_outcome: "ירידת הימנעות.",
        do_nots: ["לא לדלג על מדרגות בסולם."],
        success_signs: ["שלבים נכבשים, חרדה יורדת מהר יותר."]
    },
    {
        name: "מסע הערכים",
        category: "תהליך ארוך טווח",
        disciplines: ["ACT-Values"],
        fits_for: ["חוסר כיוון", "דחיינות"],
        how_to: {
            prep: "כרטיסי ערכים/שאלון.",
            steps: ["לבחור 4 ערכי ליבה.", "להציב מטרות חודשיות לכל ערך.", "מעקב שבועי."]
        },
        explanation: "פעולה מונחית ערכים.",
        expected_outcome: "התמדה ומשמעות.",
        do_nots: ["לא להפוך ערכים ליעדים מדידים בלבד."],
        success_signs: ["פעולה עקבית גם כשקשה."]
    },
    {
        name: "מעקב חוזקות VIA",
        category: "תהליך ארוך טווח",
        disciplines: ["פסיכולוגיה חיובית"],
        fits_for: ["דימוי עצמי", "שעמום"],
        how_to: {
            prep: "מבחן VIA מקוון.",
            steps: ["לבחור 2 חוזקות לשימוש יתר בחודש.", "ליצור משימות שבועיות קטנות."]
        },
        explanation: "שימוש מודע בחוזקות.",
        expected_outcome: "חוסן והנאה.",
        do_nots: ["לא לכפות חוזקה לא אותנטית."],
        success_signs: ["שימוש יזום בחוזקה."]
    },
    {
        name: 'פרויקט "גיבור המסע"',
        category: "תהליך ארוך טווח",
        disciplines: ["טיפול נרטיבי"],
        fits_for: ["זהות", "טראומה", "שינוי"],
        how_to: {
            prep: "תבנית 12 שלבי מסע הגיבור.",
            steps: ["בכל מפגש שלב אחר בסיפור האישי.", "יצירה/וידאו/קומיקס: הצגה בסיום."]
        },
        explanation: "ארגון נרטיב מעניק משמעות.",
        expected_outcome: "תובנות וגאווה.",
        do_nots: ["לא לכפות חשיפה לטראומה."],
        success_signs: ["תוצר משמעותי ושפה סיפורית על הקושי."]
    },
    {
        name: "יומן מיינדפולנס",
        category: "תהליך ארוך טווח",
        disciplines: ["Mindfulness"],
        fits_for: ["לחץ כרוני", "קשב"],
        how_to: {
            prep: "מחברת/אפליקציה.",
            steps: ["5-10 דק' תרגול יומי + רישום חוויה קצר.", "סקירה חודשית."]
        },
        explanation: "בניית 'שריר' הקשיבות.",
        expected_outcome: "ויסות מתמשך.",
        do_nots: ["לא 'להמציא' חוויות עמוקות."],
        success_signs: ["תרגול עקבי וירידה בתגובתיות."]
    },
    {
        name: "עוגנים חיוביים מתקדמים",
        category: "תהליך ארוך טווח",
        disciplines: ["NLP"],
        fits_for: ["חרדה", "ביטחון עצמי"],
        how_to: {
            prep: "לבחור מצבים רצויים וסימן פיזי (לחיצה/תנועה).",
            steps: ["העלאת חוויה רצויה.", "יצירת עוגן גופני.", "שינון והכללה למצבים קשים."]
        },
        explanation: "גישה מהירה למשאב רגשי.",
        expected_outcome: "הפעלה עצמית של רוגע/ביטחון.",
        do_nots: ["לא ליצור עוגן בזמן מצוקה."],
        success_signs: ["שימוש בעוגן לפני אירוע מלחיץ."]
    },
    {
        name: "שנת השירות העצמית",
        category: "תהליך ארוך טווח",
        disciplines: ["Coaching / פסיכולוגיה חיובית"],
        fits_for: ["רווחה נפשית כללית"],
        how_to: {
            prep: "רשימת 12 תחומי רווחה (שינה, תזונה..).",
            steps: ["כל חודש יעד קטן ומדיד בתחום אחר.", "מעקב שבועי."]
        },
        explanation: "הטמעת הרגלים מיטיבים ברוטינה.",
        expected_outcome: "עלייה ברווחה הנפשית (Well-Being).",
        do_nots: ["לא לבחור מטרות ענק."],
        success_signs: ["8/12 יעדים הושגו חלקית."]
    },
    {
        name: "קבוצת למידה רגשית",
        category: "תהליך ארוך טווח",
        disciplines: ["SEL"],
        fits_for: ["שייכות", "תמיכה"],
        how_to: {
            prep: "קבוצה וכללי סודיות.",
            steps: ["מפגש שבועי קבוע: פתיחה, תרגיל, שיתוף, משימה לבית."]
        },
        explanation: "למידה דרך קבוצה בטוחה.",
        expected_outcome: "תחושת שייכות וכלים חברתיים.",
        do_nots: ["לא לאפשר לעג או שיפוטיות."],
        success_signs: ["שיתופים פתוחים, נוכחות יציבה."]
    },
    {
        name: "מודל ABC מתמשך",
        category: "תהליך ארוך טווח",
        disciplines: ["CBT/ABC Model"],
        fits_for: ["דפוסים קוגניטיביים"],
        how_to: {
            prep: "טפסי ABC.",
            steps: ["לזהות אירוע-אמונה-תגובה (A-B-C) על מצבים חוזרים.", "לעדכן אמונות ליבה."]
        },
        explanation: "הבנת הקשר בין אמונה לתגובה.",
        expected_outcome: "שינוי אמונות מגבילות.",
        do_nots: ["לא למהר לתקן בלי הבנה מעמיקה."],
        success_signs: ["אמונה חדשה מיושמת בשטח."]
    },
    {
        name: "מפת רשת תמיכה",
        category: "תהליך ארוך טווח",
        disciplines: ["SEL/Narrative"],
        fits_for: ["בדידות", "הסתגרות"],
        how_to: {
            prep: "דף מיפוי.",
            steps: ["למפות אנשים/מקומות/פעילויות תומכים.", "לבחור לחזק קשר אחד בכל רבעון."]
        },
        explanation: "מודעות למשאבי תמיכה קיימים ופוטנציאליים.",
        expected_outcome: "פנייה יזומה לעזרה.",
        do_nots: ["לא לשפוט את הבחירות של התלמיד."],
        success_signs: ["קשר חדש נוצר או קשר קיים הועמק."]
    },
    {
        name: "יומן יצירה מתמשך",
        category: "תהליך ארוך טווח",
        disciplines: ["תרפיה באמנות"],
        fits_for: ["ביטוי עצמי", "התמדה"],
        how_to: {
            prep: "בחירת מדיום לשנה (קומיקס/מחברת/צילום).",
            steps: ["יעד חודשי קטן.", "הצגת תוצר רבעונית."]
        },
        explanation: "יצירה ככלי לעיבוד רגשי מתמשך.",
        expected_outcome: "ביטוי עשיר והתמדה.",
        do_nots: ["לא לבקר את איכות התוצר."],
        success_signs: ["המשך יצירה גם ללא משימה מוגדרת."]
    },
    {
        name: "תכנית מיומנויות חברתיות",
        category: "תהליך ארוך טווח",
        disciplines: ["CHISEL"],
        fits_for: ["חרדה חברתית", "מיומנויות חסרות"],
        how_to: {
            prep: "לבחור 4 מיומנויות (פתיחת שיחה, בקשת עזרה...).",
            steps: ["כל שבוע: הסבר, הדגמה, תרגול, משוב.", "תיעוד."]
        },
        explanation: "אימון ממוקד בכישורים.",
        expected_outcome: "ביטחון בין-אישי.",
        do_nots: ["לא להעמיד 'על במה' בלי הסכמה."],
        success_signs: ["יצירת יוזמות קטנות."]
    },
    {
        name: "קופסת ההישגים",
        category: "תהליך ארוך טווח",
        disciplines: ["פסיכולוגיה חיובית"],
        fits_for: ["הערכה עצמית", "מוטיבציה"],
        how_to: {
            prep: "קופסה/תיקייה.",
            steps: ["לאסוף 'הצלחות קטנות'.", "לפתוח פעם בחודש ולעדכן."]
        },
        explanation: "הוכחות מצטברות ליכולת.",
        expected_outcome: "חיזוק עצמי.",
        do_nots: ["לא לפסול הצלחות כ'קטנות מדי'."],
        success_signs: ["פתיחה יזומה של הקופסה בזמן ספק."]
    },
    {
        name: "חוזה אישי",
        category: "תהליך ארוך טווח",
        disciplines: ["Coaching/Narrative"],
        fits_for: ["אחריות", "דחיינות"],
        how_to: {
            prep: "תבנית חוזה (מטרות, חוקים, תגמול).",
            steps: ["ניסוח, חתימה, סקירה דו-חודשית והתאמות."]
        },
        explanation: "מסגרת מחייבת עם גמישות.",
        expected_outcome: "עמידה בהתחייבויות.",
        do_nots: ["לא ליצור ענישה קשה מדי."],
        success_signs: ["עדכון חוזה מתוך למידה, לא מתוך אשמה."]
    },
    {
        name: "מעבדת ניסויים אישית",
        category: "תהליך ארוך טווח",
        disciplines: ["Design Thinking/CBT"],
        fits_for: ["שינוי הרגלים", "גמישות קוגניטיבית"],
        how_to: {
            prep: "טמפלט ניסוי: השערה/מדד/משך.",
            steps: ["לבחור הרגל לשיפור ולהגדיר ניסוי שבועי קטן.", "למדוד תוצאה (מדד ברור).", "ללמוד מהתוצאות ולהתאים.", "לחזור 6–8 מחזורים."]
        },
        explanation: "חשיבה ניסויית מחליפה שיפוט עצמי בלמידה מתמשכת.",
        expected_outcome: "שיפור מדורג או תובנות המובילות לשינוי אסטרטגיה.",
        do_nots: ["לא לשפוט כישלון – לראות בו נתון.", "לא לשנות כמה משתנים יחד (קשה ללמוד)."],
        success_signs: ["שיפור במדד שנבחר או הבנה מה לשנות.", "התמדה במחזורים עד השגת יעד."]
    }
];

const initialData = {
  users: [
    {"id":"admin-1","firstName":"יורם","lastName":"גרניט","phone":"0501234567","email":"yoram.granit@gmail.com","role":"admin","rememberMe":false,"assignedStudentIds":["student-12","student-28","student-44"]},
    {"id":"mentor-1","firstName":"דנה","lastName":"כהן","phone":"0529876543","role":"mentor","rememberMe":false,"assignedStudentIds":["student-1","student-13","student-29","student-45"]},
    {"id":"admin-2","firstName":"טלי","lastName":"פרידמן","phone":"0583456789","email":"tali.f@gmail.com","role":"admin","rememberMe":false,"assignedStudentIds":["student-2","student-14","student-30","student-46"]},
    {"id":"mentor-2","firstName":"שירה","lastName":"יוסף","phone":"0548765432","role":"mentor","rememberMe":false,"assignedStudentIds":["student-3","student-15","student-31","student-47"]},
    {"id":"mentor-3","firstName":"דוד","lastName":"דוד","phone":"0501122334","role":"mentor","rememberMe":false,"assignedStudentIds":["student-4","student-16","student-32","student-48"]},
    {"id":"mentor-4","firstName":"מיכל","lastName":"גבאי","phone":"0523344556","role":"mentor","rememberMe":false,"assignedStudentIds":["student-5","student-17","student-33","student-49"]},
    {"id":"mentor-5","firstName":"יובל","lastName":"עמר","phone":"0534455667","role":"mentor","rememberMe":false,"assignedStudentIds":["student-6","student-18","student-34","student-50"]},
    {"id":"mentor-6","firstName":"עדי","lastName":"אוחיון","phone":"0545566778","role":"mentor","rememberMe":false,"assignedStudentIds":["student-7","student-19","student-35"]},
    {"id":"mentor-7","firstName":"עומר","lastName":"חדד","phone":"0506677889","role":"mentor","rememberMe":false,"assignedStudentIds":["student-8","student-20","student-36"]},
    {"id":"mentor-8","firstName":"הילה","lastName":"אזולאי","phone":"0527788990","role":"mentor","rememberMe":false,"assignedStudentIds":["student-9","student-21","student-37"]},
    {"id":"mentor-9","firstName":"ליאור","lastName":"קליין","phone":"0538899001","role":"mentor","rememberMe":false,"assignedStudentIds":["student-10","student-22","student-38"]},
    {"id":"mentor-10","firstName":"טל","lastName":"שפירא","phone":"0549900112","role":"mentor","rememberMe":false,"assignedStudentIds":["student-11","student-23","student-39"]},
    {"id":"mentor-11","firstName":"דניאל","lastName":"שטרן","phone":"0501212123","role":"mentor","rememberMe":false,"assignedStudentIds":["student-24","student-40"]},
    {"id":"mentor-12","firstName":"רוני","lastName":"רוזנברג","phone":"0522323234","role":"mentor","rememberMe":false,"assignedStudentIds":["student-25","student-41"]},
    {"id":"mentor-13","firstName":"אריאל","lastName":"לביא","phone":"0533434345","role":"mentor","rememberMe":false,"assignedStudentIds":["student-26","student-42"]},
    {"id":"mentor-14","firstName":"אגם","lastName":"זהבי","phone":"0544545456","role":"mentor","rememberMe":false,"assignedStudentIds":["student-27","student-43"]},
    {"id":"student-1","firstName":"אבי","lastName":"לוי","phone":"0541112222","email":"avi.l@school.com","parentPhone":"050-111-2222","parentEmail":"parent.l@email.com","role":"student","rememberMe":false,"class":"א'1","mentorId":"mentor-1","gender":"male","notes":"תלמיד חדש, מראה פוטנציאל רב בתחום המדעים.","gamification":{"xp":25,"level":1}},
    {"id":"student-2","firstName":"מאיה","lastName":"שחר","phone":"0543334444","role":"student","rememberMe":false,"class":"א'2","mentorId":"admin-2","gender":"female","notes":"מתקשה להשתלב חברתית.","gamification":{"xp":60,"level":2}},
    {"id":"student-3","firstName":"רון","lastName":"ברק","phone":"0545556666","email":"ron.b@school.com","role":"student","rememberMe":false,"class":"א'3","mentorId":"mentor-2","gender":"male","gamification":{"xp":0,"level":1}},
    {"id":"student-4","firstName":"נועה","lastName":"כהן","phone":"0502345678","role":"student","rememberMe":false,"class":"ב'1","mentorId":"mentor-3","gender":"female","gamification":{"xp":120,"level":3}},
    {"id":"student-5","firstName":"איתי","lastName":"פרץ","phone":"0523456789","role":"student","rememberMe":false,"class":"ב'2","mentorId":"mentor-4","gender":"male","gamification":{"xp":45,"level":1}},
    {"id":"student-6","firstName":"יעל","lastName":"ביטון","phone":"0534567890","role":"student","rememberMe":false,"class":"ב'3","mentorId":"mentor-5","gender":"female","gamification":{"xp":80,"level":2}},
    {"id":"student-7","firstName":"עמית","lastName":"דהן","phone":"0545678901","role":"student","rememberMe":false,"class":"ג'1","mentorId":"mentor-6","gender":"other","gamification":{"xp":10,"level":1}},
    {"id":"student-8","firstName":"שירה","lastName":"אברהם","phone":"0506789012","role":"student","rememberMe":false,"class":"ג'2","mentorId":"mentor-7","gender":"female","gamification":{"xp":200,"level":4}},
    {"id":"student-9","firstName":"בן","lastName":"פרידמן","phone":"0527890123","role":"student","rememberMe":false,"class":"ג'3","mentorId":"mentor-8","gender":"male","gamification":{"xp":55,"level":2}},
    {"id":"student-10","firstName":"תמר","lastName":"כץ","phone":"0538901234","role":"student","rememberMe":false,"class":"ד'1","mentorId":"mentor-9","gender":"female","gamification":{"xp":90,"level":2}},
    {"id":"student-11","firstName":"גיא","lastName":"יוסף","phone":"0549012345","role":"student","rememberMe":false,"class":"ד'2","mentorId":"mentor-10","gender":"male","gamification":{"xp":150,"level":3}},
    {"id":"student-12","firstName":"רוני","lastName":"דוד","phone":"0501111111","role":"student","rememberMe":false,"class":"ד'3","mentorId":"admin-1","gender":"female","gamification":{"xp":30,"level":1}},
    {"id":"student-13","firstName":"דניאל","lastName":"גבאי","phone":"0522222222","role":"student","rememberMe":false,"class":"ה'1","mentorId":"mentor-1","gender":"male","gamification":{"xp":130,"level":3}},
    {"id":"student-14","firstName":"הילה","lastName":"עמר","phone":"0533333333","role":"student","rememberMe":false,"class":"ה'2","mentorId":"admin-2","gender":"female","gamification":{"xp":5,"level":1}},
    {"id":"student-15","firstName":"נדב","lastName":"אוחיון","phone":"0544444444","role":"student","rememberMe":false,"class":"ה'3","mentorId":"mentor-2","gender":"male","gamification":{"xp":75,"level":2}},
    {"id":"student-16","firstName":"לירון","lastName":"חדד","phone":"0505555555","role":"student","rememberMe":false,"class":"ו'1","mentorId":"mentor-3","gender":"other","gamification":{"xp":88,"level":2}},
    {"id":"student-17","firstName":"אור","lastName":"אזולאי","phone":"0526666666","role":"student","rememberMe":false,"class":"ו'2","mentorId":"mentor-4","gender":"female","gamification":{"xp":110,"level":3}},
    {"id":"student-18","firstName":"אסף","lastName":"קליין","phone":"0537777777","role":"student","rememberMe":false,"class":"ו'3","mentorId":"mentor-5","gender":"male","gamification":{"xp":20,"level":1}},
    {"id":"student-19","firstName":"זוהר","lastName":"שפירא","phone":"0548888888","role":"student","rememberMe":false,"class":"ז'1","mentorId":"mentor-6","gender":"female","gamification":{"xp":40,"level":1}},
    {"id":"student-20","firstName":"שי","lastName":"שטרן","phone":"0509999999","role":"student","rememberMe":false,"class":"ז'2","mentorId":"mentor-7","gender":"male","gamification":{"xp":160,"level":4}},
    {"id":"student-21","firstName":"שחר","lastName":"רוזנברג","phone":"0521010101","role":"student","rememberMe":false,"class":"ז'3","mentorId":"mentor-8","gender":"other","gamification":{"xp":65,"level":2}},
    {"id":"student-22","firstName":"יואב","lastName":"לביא","phone":"0532121212","role":"student","rememberMe":false,"class":"ח'1","mentorId":"mentor-9","gender":"male","gamification":{"xp":95,"level":2}},
    {"id":"student-23","firstName":"גאיה","lastName":"זהבי","phone":"0543232323","role":"student","rememberMe":false,"class":"ח'2","mentorId":"mentor-10","gender":"female","gamification":{"xp":180,"level":4}},
    {"id":"student-24","firstName":"אלעד","lastName":"ברק","phone":"0504343434","role":"student","rememberMe":false,"class":"ח'3","mentorId":"mentor-11","gender":"male","gamification":{"xp":10,"level":1}},
    {"id":"student-25","firstName":"עינב","lastName":"טל","phone":"0525454545","role":"student","rememberMe":false,"class":"א'1","mentorId":"mentor-12","gender":"female","gamification":{"xp":50,"level":2}},
    {"id":"student-26","firstName":"ארז","lastName":"שחר","phone":"0536565656","role":"student","rememberMe":false,"class":"א'2","mentorId":"mentor-13","gender":"male","gamification":{"xp":25,"level":1}},
    {"id":"student-27","firstName":"סיוון","lastName":"כהן","phone":"0547676767","role":"student","rememberMe":false,"class":"א'3","mentorId":"mentor-14","gender":"female","gamification":{"xp":140,"level":3}},
    {"id":"student-28","firstName":"גלעד","lastName":"לוי","phone":"0508787878","role":"student","rememberMe":false,"class":"ב'1","mentorId":"admin-1","gender":"male","gamification":{"xp":70,"level":2}},
    {"id":"student-29","firstName":"מורן","lastName":"מזרחי","phone":"0529898989","role":"student","rememberMe":false,"class":"ב'2","mentorId":"mentor-1","gender":"female","gamification":{"xp":100,"level":3}},
    {"id":"student-30","firstName":"יהונתן","lastName":"פרץ","phone":"0531919191","role":"student","rememberMe":false,"class":"ב'3","mentorId":"admin-2","gender":"male","gamification":{"xp":15,"level":1}},
    {"id":"student-31","firstName":"ליאת","lastName":"ביטון","phone":"0542828282","role":"student","rememberMe":false,"class":"ג'1","mentorId":"mentor-2","gender":"female","gamification":{"xp":85,"level":2}},
    {"id":"student-32","firstName":"רועי","lastName":"דהן","phone":"0503737373","role":"student","rememberMe":false,"class":"ג'2","mentorId":"mentor-3","gender":"male","gamification":{"xp":45,"level":1}},
    {"id":"student-33","firstName":"קרן","lastName":"אברהם","phone":"0524646464","role":"student","rememberMe":false,"class":"ג'3","mentorId":"mentor-4","gender":"female","gamification":{"xp":125,"level":3}},
    {"id":"student-34","firstName":"מתן","lastName":"פרידמן","phone":"0535555555","role":"student","rememberMe":false,"class":"ד'1","mentorId":"mentor-5","gender":"male","gamification":{"xp":60,"level":2}},
    {"id":"student-35","firstName":"אלה","lastName":"כץ","phone":"0546464646","role":"student","rememberMe":false,"class":"ד'2","mentorId":"mentor-6","gender":"female","gamification":{"xp":190,"level":4}},
    {"id":"student-36","firstName":"נועם","lastName":"יוסף","phone":"0507373737","role":"student","rememberMe":false,"class":"ד'3","mentorId":"mentor-7","gender":"male","gamification":{"xp":35,"level":1}},
    {"id":"student-37","firstName":"ליה","lastName":"דוד","phone":"0528282828","role":"student","rememberMe":false,"class":"ה'1","mentorId":"mentor-8","gender":"female","gamification":{"xp":115,"level":3}},
    {"id":"student-38","firstName":"אריאל","lastName":"גבאי","phone":"0539191919","role":"student","rememberMe":false,"class":"ה'2","mentorId":"mentor-9","gender":"male","gamification":{"xp":22,"level":1}},
    {"id":"student-39","firstName":"שני","lastName":"עמר","phone":"0541818181","role":"student","rememberMe":false,"class":"ה'3","mentorId":"mentor-10","gender":"female","gamification":{"xp":78,"level":2}},
    {"id":"student-40","firstName":"תומר","lastName":"אוחיון","phone":"0502727272","role":"student","rememberMe":false,"class":"ו'1","mentorId":"mentor-11","gender":"male","gamification":{"xp":98,"level":2}},
    {"id":"student-41","firstName":"דנה","lastName":"חדד","phone":"0523636363","role":"student","rememberMe":false,"class":"ו'2","mentorId":"mentor-12","gender":"female","gamification":{"xp":170,"level":4}},
    {"id":"student-42","firstName":"אורי","lastName":"אזולאי","phone":"0534545454","role":"student","rememberMe":false,"class":"ו'3","mentorId":"mentor-13","gender":"male","gamification":{"xp":12,"level":1}},
    {"id":"student-43","firstName":"אגם","lastName":"קליין","phone":"0545454545","role":"student","rememberMe":false,"class":"ז'1","mentorId":"mentor-14","gender":"female","gamification":{"xp":58,"level":2}},
    {"id":"student-44","firstName":"ליאור","lastName":"שפירא","phone":"0506363636","role":"student","rememberMe":false,"class":"ז'2","mentorId":"admin-1","gender":"male","gamification":{"xp":135,"level":3}},
    {"id":"student-45","firstName":"עדי","lastName":"שטרן","phone":"0527272727","role":"student","rememberMe":false,"class":"ז'3","mentorId":"mentor-1","gender":"female","gamification":{"xp":33,"level":1}},
    {"id":"student-46","firstName":"עומר","lastName":"רוזנברג","phone":"0538181818","role":"student","rememberMe":false,"class":"ח'1","mentorId":"admin-2","gender":"male","gamification":{"xp":81,"level":2}},
    {"id":"student-47","firstName":"מיכל","lastName":"לביא","phone":"0549090909","role":"student","rememberMe":false,"class":"ח'2","mentorId":"mentor-2","gender":"female","gamification":{"xp":177,"level":4}},
    {"id":"student-48","firstName":"יובל","lastName":"זהבי","phone":"0501919191","role":"student","rememberMe":false,"class":"ח'3","mentorId":"mentor-3","gender":"male","gamification":{"xp":49,"level":1}},
    {"id":"student-49","firstName":"תמר","lastName":"ברק","phone":"0522828282","role":"student","rememberMe":false,"class":"ח'1","mentorId":"mentor-4","gender":"female","gamification":{"xp":93,"level":2}},
    {"id":"student-50","firstName":"דוד","lastName":"טל","phone":"0533737373","role":"student","rememberMe":false,"class":"ח'2","mentorId":"mentor-5","gender":"male","gamification":{"xp":145,"level":3}}
  ],
  moodRecords: [
    { id: 'record-1', studentId: 'student-1', date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), emotionalScore: 7, socialScore: 8, academicScore: 6, personalScore: 7, emotionalEvidence: 'היה שבוע בסדר', socialEvidence: 'כיף עם חברים', academicEvidence: 'קצת קשה במתמטיקה', personalEvidence: 'הכל טוב בבית', averageScore: 7, sessionId: 'session-1', isAcknowledged: true },
    { id: 'record-2', studentId: 'student-1', date: new Date().toISOString(), emotionalScore: 5, socialScore: 4, academicScore: 3, personalScore: 5, emotionalEvidence: 'מרגיש קצת לחוץ', socialEvidence: 'רבתי עם חבר', academicEvidence: 'לא מבין את החומר למבחן', personalEvidence: 'בסדר', averageScore: 4.25, sessionId: 'session-2', isAcknowledged: false },
    { id: 'record-5', studentId: 'student-2', date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), emotionalScore: 8, socialScore: 8, academicScore: 9, personalScore: 7, emotionalEvidence: 'הרגשה טובה השבוע', socialEvidence: 'היה כיף במסיבה', academicEvidence: 'קיבלתי 100 בתנ״ך', personalEvidence: 'התחלתי חוג חדש', averageScore: 8, isAcknowledged: false }, // Independent report
    { id: 'record-3', studentId: 'student-3', date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), emotionalScore: 3, socialScore: 4, academicScore: 2, personalScore: 5, emotionalEvidence: 'שבוע נוראי', socialEvidence: 'מרגיש לבד', academicEvidence: 'נכשלתי במבחן', personalEvidence: '', averageScore: 3.5, isAcknowledged: false },
    { id: 'record-4', studentId: 'student-4', date: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000).toISOString(), emotionalScore: 6, socialScore: 6, academicScore: 7, personalScore: 5, emotionalEvidence: 'בסדר', socialEvidence: '', academicEvidence: 'סביר', personalEvidence: '', averageScore: 6, isAcknowledged: true },
  ],
  sessions: [
      { id: 'session-1', title: 'פגישה עם אבי לוי', studentId: 'student-1', mentorId: 'mentor-1', date: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(), time: '14:00', place: 'חדר יועצת', status: 'completed', linkedMoodRecordId: 'record-1', mentorImpression: 'נראה שאבי מתמודד עם לחץ לקראת המבחנים. דיברנו על טכניקות למידה.', usedToolId: '18' },
      { id: 'session-2', title: 'פגישה עם אבי לוי', studentId: 'student-1', mentorId: 'mentor-1', date: new Date().toISOString(), time: '10:00', place: 'ספרייה', status: 'completed', linkedMoodRecordId: 'record-2', mentorImpression: 'הריב עם החבר עדיין יושב עליו. נראה שנצטרך לעבוד על כישורים חברתיים.' },
      { id: 'session-4', title: 'פגישה עם מאיה שחר', studentId: 'student-2', mentorId: 'admin-2', date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), time: '11:00', place: 'ספרייה', status: 'scheduled' }, // A session without a report
      { id: 'session-3', title: 'פגישה עם רון ברק', studentId: 'student-3', mentorId: 'mentor-2', date: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(), time: '12:30', place: 'קפיטריה', status: 'scheduled' },
  ],
  voiceNotes: [
      { id: 'vn-1', studentId: 'student-1', mentorId: 'mentor-1', date: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(), transcription: 'השיחה התמקדה בקשיים במתמטיקה. אבי הביע תסכול אבל גם נכונות להשקיע. המלצתי על שיעור עזר והצעתי לבדוק איתו שוב שבוע הבא.'},
      { id: 'vn-2', studentId: 'student-2', mentorId: 'admin-2', date: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(), transcription: 'מאיה שיתפה שהיא מרגישה בודדה בהפסקות. סיכמנו שננסה לחבר אותה לקבוצת העניין בתיאטרון.'},
  ],
  tools: initialToolsData.map((tool, index) => ({ ...tool, id: index + 1 })),
  "interventions": [],
  "feedback": [],
};

interface AppData {
  users: (User | Student)[];
  moodRecords: MoodRecord[];
  sessions: Session[];
  voiceNotes: VoiceNote[];
  tools: Tool[];
  interventions: Intervention[];
  feedback: Feedback[];
}

const APP_DATA_KEY = 'menaynim_app_data';

const loadData = () => {
    try {
        const storedData = localStorage.getItem(APP_DATA_KEY);
        if (storedData) {
            const parsedData: AppData = JSON.parse(storedData);
            users = parsedData.users || [];
            moodRecords = parsedData.moodRecords || [];
            sessions = parsedData.sessions || [];
            voiceNotes = parsedData.voiceNotes || [];
            interventions = parsedData.interventions || [];
            feedback = parsedData.feedback || [];
            
            // Ensure tools are always up to date from the initialData source on load
            tools = JSON.parse(JSON.stringify(initialData.tools));
            saveData();

        } else {
            resetData();
        }
    } catch (error) {
        console.error("Failed to load data from localStorage", error);
        resetData();
    }
}

const saveData = () => {
    try {
        const dataToStore: AppData = { users, moodRecords, sessions, voiceNotes, tools, interventions, feedback };
        localStorage.setItem(APP_DATA_KEY, JSON.stringify(dataToStore));
    } catch (error) {
        console.error("Failed to save data to localStorage", error);
    }
}

export const resetData = () => {
    users = JSON.parse(JSON.stringify(initialData.users));
    moodRecords = JSON.parse(JSON.stringify(initialData.moodRecords));
    sessions = JSON.parse(JSON.stringify(initialData.sessions));
    voiceNotes = JSON.parse(JSON.stringify(initialData.voiceNotes));
    tools = JSON.parse(JSON.stringify(initialData.tools));
    interventions = JSON.parse(JSON.stringify(initialData.interventions));
    feedback = JSON.parse(JSON.stringify(initialData.feedback));
    saveData();
}

// Gamification Logic Constants
const XP_PER_REPORT = 15;
const xpForLevel = (level: number) => 50 + (level * 25);


const updateGamificationStats = (studentId: string) => {
    const student = dbGetStudentById(studentId);
    if (!student) return;

    let gamification = student.gamification;

    // 1. Award XP for the new report
    gamification.xp += XP_PER_REPORT;

    // 2. Level up
    let neededXP = xpForLevel(gamification.level);
    while (gamification.xp >= neededXP) {
        gamification.level += 1;
        gamification.xp -= neededXP;
        neededXP = xpForLevel(gamification.level);
    }
    
    student.gamification = gamification;
}

const calculateAverageScore = (recordData: Partial<MoodRecord>): number => {
    const scores = [recordData.emotionalScore, recordData.socialScore, recordData.academicScore, recordData.personalScore]
        .filter(s => s !== null && s !== undefined) as number[];
    if (scores.length === 0) return 0; // Should be prevented by form validation
    return scores.reduce((acc, score) => acc + score, 0) / scores.length;
};

// Load data on initial script load
loadData();


export const dbLogin = (phone: string, password?: string): User | null => {
    let userToFind: User | Student | undefined;
    if (phone === 'yoram.granit@gmail.com' || phone === '0501234567') {
      userToFind = users.find(u => u.id === 'admin-1');
    } else {
      userToFind = users.find(u => u.phone === phone);
    }
    
    if (userToFind) {
      return { ...userToFind };
    }
    return null;
};

export const dbGetUserById = (id: string): User | undefined => {
    const user = users.find(u => u.id === id);
    return user ? { ...user } : undefined;
}

export const dbGetAllUsers = (): (User | Student)[] => users;

export const dbAddUser = (userData: Partial<Omit<Student, 'role'>> & { role?: Role }): User | Student => {
    const newUser = {
      ...userData,
      id: `${userData.role}-${Date.now()}`,
      rememberMe: false,
    } as User | Student;

    if (newUser.role === Role.Student) {
      (newUser as Student).gamification = { xp: 0, level: 1 };
    }
    
    users.push(newUser);
    
    // Handle assignments
    if (newUser.role === Role.Student && (newUser as Student).mentorId) {
        const mentor = users.find(u => u.id === (newUser as Student).mentorId) as User;
        if (mentor && mentor.assignedStudentIds) {
            mentor.assignedStudentIds.push(newUser.id);
        } else if (mentor) {
            mentor.assignedStudentIds = [newUser.id];
        }
    }

    saveData();
    return newUser;
};

export const dbAddMultipleUsers = (newStudentsData: any[]): { success: number, failures: number } => {
    let success = 0;
    let failures = 0;

    newStudentsData.forEach(data => {
         // Check if student already exists by phone
        if (data.studentPhone && users.some(u => u.phone === data.studentPhone)) {
            failures++;
            console.warn(`Student with phone ${data.studentPhone} already exists. Skipping.`);
            return;
        }

        const newStudent: Student = {
            id: `student-${Date.now()}-${Math.random()}`,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.studentPhone || '',
            class: data.class,
            gender: data.gender.toLowerCase() === 'זכר' ? 'male' : (data.gender.toLowerCase() === 'נקבה' ? 'female' : 'other'),
            mentorId: '', // Students are unassigned by default
            role: Role.Student,
            rememberMe: false,
            gamification: { xp: 0, level: 1 }
        };

        users.push(newStudent);
        success++;
    });

    saveData();
    return { success, failures };
};


export const dbAddMultipleMentors = (newMentorsData: any[]): { success: number, failures: number } => {
    let success = 0;
    let failures = 0;

    newMentorsData.forEach(data => {
        const role = data.role.toLowerCase() === 'admin' ? Role.Admin : Role.Mentor;
        
        const newUser: User = {
            id: `${role}-${Date.now()}-${Math.random()}`,
            firstName: data.firstName,
            lastName: data.lastName,
            phone: data.phone,
            role: role,
            rememberMe: false,
            assignedStudentIds: [],
        };

        users.push(newUser);
        success++;
    });

    saveData();
    return { success, failures };
};


// This is a complex function, adding comments to clarify logic.
export const dbUpdateUser = (userId: string, updatedData: Partial<Omit<Student, 'role'>> & { role?: Role }): User | Student | null => {
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return null;

    const oldUser = { ...users[userIndex] };
    const updatedUser = { ...oldUser, ...updatedData } as User | Student;
    
    users[userIndex] = updatedUser;

    // --- LOGIC FOR UPDATING RELATIONSHIPS ---

    // CASE 1: The updated user is a STUDENT
    if (updatedUser.role === Role.Student) {
        const oldStudentData = oldUser as Student;
        const newStudentData = updatedUser as Student;
        // If the student's assigned mentor has changed...
        if (oldStudentData.mentorId !== newStudentData.mentorId) {
            // Remove the student from their OLD mentor's list
            if (oldStudentData.mentorId) {
                const oldMentor = users.find(u => u.id === oldStudentData.mentorId) as User;
                if (oldMentor && oldMentor.assignedStudentIds) {
                    oldMentor.assignedStudentIds = oldMentor.assignedStudentIds.filter(id => id !== userId);
                }
            }
            // Add the student to their NEW mentor's list
            if (newStudentData.mentorId) {
                const newMentor = users.find(u => u.id === newStudentData.mentorId) as User;
                if (newMentor) {
                    if (!newMentor.assignedStudentIds) newMentor.assignedStudentIds = [];
                    if (!newMentor.assignedStudentIds.includes(userId)) {
                        newMentor.assignedStudentIds.push(userId);
                    }
                }
            }
        }
    } 
    // CASE 2: The updated user is a MENTOR or ADMIN
    else if (updatedUser.role === Role.Mentor || updatedUser.role === Role.Admin) {
        const oldMentorData = oldUser as User;
        const newMentorData = updatedUser as User;
        
        const oldAssignedIds = new Set(oldMentorData.assignedStudentIds || []);
        const newAssignedIds = new Set(newMentorData.assignedStudentIds || []);

        // Find students that were REMOVED from this mentor's list
        oldAssignedIds.forEach(studentId => {
            if (!newAssignedIds.has(studentId)) {
                const student = users.find(u => u.id === studentId) as Student;
                // If the student was indeed assigned to this mentor, unassign them.
                if (student && student.mentorId === userId) {
                    student.mentorId = '';
                }
            }
        });

        // Find students that were ADDED to this mentor's list
        newAssignedIds.forEach(studentId => {
            if (!oldAssignedIds.has(studentId)) {
                const student = users.find(u => u.id === studentId) as Student;
                if (student) {
                    // If this student was previously assigned to a DIFFERENT mentor, remove the old link.
                     if (student.mentorId && student.mentorId !== userId) {
                         const previousMentor = users.find(u => u.id === student.mentorId) as User;
                         if (previousMentor && previousMentor.assignedStudentIds) {
                            previousMentor.assignedStudentIds = previousMentor.assignedStudentIds.filter(id => id !== studentId);
                         }
                    }
                    // Assign the student to this new mentor.
                    student.mentorId = userId;
                }
            }
        });
    }

    saveData();
    return updatedUser;
};

export const dbDeleteUser = (userId: string): boolean => {
    const userIndex = users.findIndex(u => u.id === userId);
    if (userIndex === -1) return false;

    const userToDelete = users[userIndex];

    // Handle cascading effects
    if (userToDelete.role === Role.Student) {
        const student = userToDelete as Student;
        // Remove from mentor's list
        if (student.mentorId) {
            const mentor = users.find(u => u.id === student.mentorId) as User | undefined;
            if (mentor?.assignedStudentIds) {
                mentor.assignedStudentIds = mentor.assignedStudentIds.filter(id => id !== userId);
            }
        }
        // Delete related data
        moodRecords = moodRecords.filter(r => r.studentId !== userId);
        sessions = sessions.filter(s => s.studentId !== userId);
        voiceNotes = voiceNotes.filter(vn => vn.studentId !== userId);
        interventions = interventions.filter(i => i.studentId !== userId);
    } else if (userToDelete.role === Role.Mentor || userToDelete.role === Role.Admin) {
        // Unassign students from this mentor/admin
        if (userToDelete.assignedStudentIds) {
            userToDelete.assignedStudentIds.forEach(studentId => {
                const student = users.find(u => u.id === studentId) as Student | undefined;
                if (student && student.mentorId === userId) {
                    student.mentorId = '';
                }
            });
        }
    }

    // Remove user
    users.splice(userIndex, 1);

    saveData();
    return true;
};

export const dbGetUnassignedStudents = (): Student[] => {
    return users.filter(u => u.role === Role.Student && !(u as Student).mentorId) as Student[];
};

export const dbReassignStudent = (studentId: string, newMentorId: string | null): Student | null => {
    const student = users.find(u => u.id === studentId && u.role === Role.Student) as Student | undefined;
    if (!student) return null;

    const oldMentorId = student.mentorId;

    // Remove from old mentor
    if (oldMentorId) {
        const oldMentor = users.find(u => u.id === oldMentorId);
        if (oldMentor && oldMentor.assignedStudentIds) {
            oldMentor.assignedStudentIds = oldMentor.assignedStudentIds.filter(id => id !== studentId);
        }
    }

    // Add to new mentor
    if (newMentorId) {
        const newMentor = users.find(u => u.id === newMentorId);
        if (newMentor) {
            if (!newMentor.assignedStudentIds) newMentor.assignedStudentIds = [];
            if (!newMentor.assignedStudentIds.includes(studentId)) {
                newMentor.assignedStudentIds.push(studentId);
            }
        }
    }
    
    // Update student's mentorId
    student.mentorId = newMentorId || '';

    saveData();
    return student;
};


export const dbGetStudentById = (id: string): Student | undefined => users.find(u => u.id === id && u.role === Role.Student) as Student | undefined;

export const dbGetStudentsForMentor = (mentorId: string): Student[] => {
    const mentor = users.find(u => u.id === mentorId);
    if (!mentor || !mentor.assignedStudentIds) return [];
    return users.filter(u => mentor.assignedStudentIds!.includes(u.id) && u.role === Role.Student) as Student[];
};

export const dbGetMoodRecordsForStudent = (studentId: string): MoodRecord[] => {
    return moodRecords.filter(r => r.studentId === studentId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const dbAddMoodRecord = (recordData: Omit<MoodRecord, 'id' | 'averageScore'>): MoodRecord => {
    const averageScore = calculateAverageScore(recordData);
    const newRecord: MoodRecord = {
        ...recordData,
        id: `record-${Date.now()}`,
        averageScore,
        isAcknowledged: false,
    };
    moodRecords.unshift(newRecord);
    if (newRecord.sessionId) {
        const session = sessions.find(s => s.id === newRecord.sessionId);
        if(session) {
            session.linkedMoodRecordId = newRecord.id;
        }
    }
    
    updateGamificationStats(newRecord.studentId);
    
    saveData();
    return newRecord;
};

export const dbAddReportToExistingSession = (sessionId: string, recordData: WellbeingFormData): { session: Session, record: MoodRecord } | null => {
    const session = sessions.find(s => s.id === sessionId);
    if (!session) return null;

    const averageScore = calculateAverageScore(recordData);
    const newRecord: MoodRecord = {
        studentId: recordData.studentId,
        emotionalScore: recordData.emotionalScore,
        socialScore: recordData.socialScore,
        academicScore: recordData.academicScore,
        personalScore: recordData.personalScore,
        emotionalEvidence: recordData.emotionalEvidence,
        socialEvidence: recordData.socialEvidence,
        academicEvidence: recordData.academicEvidence,
        personalEvidence: recordData.personalEvidence,
        id: `record-${Date.now()}-${Math.random()}`,
        date: new Date(session.date).toISOString(), // Use the session's date
        averageScore,
        sessionId: session.id,
        isAcknowledged: false,
    };

    moodRecords.unshift(newRecord);
    
    // Update the existing session
    session.status = 'completed';
    session.linkedMoodRecordId = newRecord.id;
    session.mentorImpression = recordData.mentorImpression;
    session.usedToolId = recordData.usedToolId;

    if (recordData.usedToolId) {
        const tool = tools.find(t => t.id.toString() === recordData.usedToolId);
        if (tool && (tool.category === 'משימה לתלמיד' || tool.category === 'תהליך ארוך טווח')) {
            dbAddIntervention({
                studentId: recordData.studentId,
                mentorId: session.mentorId,
                toolId: recordData.usedToolId,
                date: new Date().toISOString(),
                notes: `המשימה החלה בעקבות פגישה בתאריך ${new Date(session.date).toLocaleDateString('he-IL')}. ${recordData.mentorImpression || ''}`,
                status: 'בתהליך'
            });
        }
    }
    
    updateGamificationStats(recordData.studentId);
    
    saveData();

    return { session, record: newRecord };
};

export const dbAddSessionWithReport = (recordData: WellbeingFormData, mentorId: string): { session: Session, record: MoodRecord } => {
    const now = new Date();
    const student = dbGetStudentById(recordData.studentId);
    
    const newSession: Session = {
        id: `session-${Date.now()}-${Math.random()}`,
        studentId: recordData.studentId,
        mentorId: mentorId,
        title: `פגישה עם ${student?.firstName || 'תלמיד'}`,
        date: now.toISOString(),
        time: now.toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' }),
        place: 'פגישה',
        status: 'completed',
        mentorImpression: recordData.mentorImpression,
        usedToolId: recordData.usedToolId,
    };

    const averageScore = calculateAverageScore(recordData);
    const newRecord: MoodRecord = {
        studentId: recordData.studentId,
        emotionalScore: recordData.emotionalScore,
        socialScore: recordData.socialScore,
        academicScore: recordData.academicScore,
        personalScore: recordData.personalScore,
        emotionalEvidence: recordData.emotionalEvidence,
        socialEvidence: recordData.socialEvidence,
        academicEvidence: recordData.academicEvidence,
        personalEvidence: recordData.personalEvidence,
        id: `record-${Date.now()}-${Math.random()}`,
        date: now.toISOString(),
        averageScore,
        sessionId: newSession.id,
        isAcknowledged: false,
    };
    
    newSession.linkedMoodRecordId = newRecord.id;

    sessions.unshift(newSession);
    moodRecords.unshift(newRecord);

    if (recordData.usedToolId) {
        const tool = tools.find(t => t.id.toString() === recordData.usedToolId);
        if (tool && (tool.category === 'משימה לתלמיד' || tool.category === 'תהליך ארוך טווח')) {
            dbAddIntervention({
                studentId: recordData.studentId,
                mentorId,
                toolId: recordData.usedToolId,
                date: now.toISOString(),
                notes: `המשימה החלה בעקבות פגישה בתאריך ${now.toLocaleDateString('he-IL')}. ${recordData.mentorImpression || ''}`,
                status: 'בתהליך'
            });
        }
    }
    
    updateGamificationStats(recordData.studentId);
    
    saveData();

    return { session: newSession, record: newRecord };
};

export const dbGetSessionsForMentor = (mentorId: string): Session[] => {
    return sessions.filter(s => s.mentorId === mentorId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const dbGetSessionsForStudent = (studentId: string): Session[] => {
    return sessions.filter(s => s.studentId === studentId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const dbGetSessionById = (sessionId: string): Session | undefined => {
    return sessions.find(s => s.id === sessionId);
};

export const dbAddSession = (sessionData: SessionData): Session[] => {
    const newSessions: Session[] = [];
    const { studentId, mentorId, title, place, startDate, time, recurring, endDate } = sessionData;
    
    let currentDate = new Date(new Date(startDate).setHours(0,0,0,0));
    const stopDate = endDate ? new Date(new Date(endDate).setHours(0,0,0,0)) : new Date(currentDate);
    if (recurring !== 'none') {
        stopDate.setDate(stopDate.getDate() + 1);
    } else {
        stopDate.setDate(currentDate.getDate() + 1);
    }
    
    let student = dbGetStudentById(studentId);
    let sessionTitle = title || `פגישה עם ${student?.firstName || 'תלמיד'}`;

    while (currentDate < stopDate) {
        const newSession: Session = {
            id: `session-${Date.now()}-${Math.random()}`,
            studentId,
            mentorId,
            title: sessionTitle,
            date: currentDate.toISOString(),
            time,
            place,
            status: 'scheduled',
        };
        newSessions.push(newSession);

        if (recurring === 'none') {
            break;
        } else if (recurring === 'daily') {
            currentDate.setDate(currentDate.getDate() + 1);
        } else if (recurring === 'weekly') {
            currentDate.setDate(currentDate.getDate() + 7);
        } else if (recurring === 'monthly') {
            currentDate.setMonth(currentDate.getMonth() + 1);
        }
    }
    
    sessions.push(...newSessions);
    saveData();
    return newSessions;
};

export const dbGetVoiceNotesForStudent = (studentId: string): VoiceNote[] => {
    return voiceNotes.filter(vn => vn.studentId === studentId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const dbAddVoiceNote = (noteData: Omit<VoiceNote, 'id'>): VoiceNote => {
    const newNote: VoiceNote = {
        ...noteData,
        id: `vn-${Date.now()}`,
    };
    voiceNotes.unshift(newNote);
    saveData();
    return newNote;
};

export const dbAcknowledgeAlert = (alertId: string, alertType: 'mood_record' | 'intervention'): boolean => {
    if (alertType === 'mood_record') {
        const record = moodRecords.find(r => r.id === alertId);
        if (record) {
            record.isAcknowledged = true;
            saveData();
            return true;
        }
    }
    if (alertType === 'intervention') {
        const intervention = interventions.find(i => i.id === alertId);
        if (intervention) {
            intervention.status = 'הושלם';
            saveData();
            return true;
        }
    }
    return false;
};

export const dbGetAlerts = (mentorId: string): Alert[] => {
    const mentorStudents = dbGetStudentsForMentor(mentorId);
    const alerts: Alert[] = [];
    const toolsMap = new Map(tools.map(t => [t.id, t.name]));

    mentorStudents.forEach(student => {
      // Mood Record Alerts
      dbGetMoodRecordsForStudent(student.id)
        .filter(r => !r.isAcknowledged)
        .forEach(record => {
            const hasLowIndividualScore = [record.emotionalScore, record.socialScore, record.academicScore, record.personalScore].some(s => s !== null && s < 4);
            const isLowScore = record.averageScore > 0 && (record.averageScore < 5 || hasLowIndividualScore);
            const isIndependent = !record.sessionId;

            if (isLowScore) {
              alerts.push({ 
                  id: record.id,
                  student,
                  source: { type: 'mood_record', record },
                  reason: 'low_score',
                  severity: 'דחוף',
                  date: record.date
              });
            } else if (isIndependent) {
              alerts.push({ 
                  id: record.id,
                  student,
                  source: { type: 'mood_record', record },
                  reason: 'independent_report',
                  severity: 'חשוב',
                  date: record.date
              });
            }
        });
        
      // Intervention Alerts (Task Follow-ups)
      dbGetInterventionsForStudent(student.id)
        .filter(i => i.status !== 'הושלם')
        .forEach(intervention => {
            alerts.push({
                id: intervention.id,
                student,
                source: {
                    type: 'intervention',
                    intervention: {
                        ...intervention,
                        toolName: toolsMap.get(Number(intervention.toolId)) || 'כלי לא ידוע'
                    }
                },
                reason: 'task_follow_up',
                severity: 'מעקב',
                date: intervention.date,
            });
        });
    });

    alerts.sort((a, b) => {
      const severityOrder: Record<AlertSeverity, number> = { 'דחוף': 1, 'חשוב': 2, 'מעקב': 3 };
      if (severityOrder[a.severity] !== severityOrder[b.severity]) {
          return severityOrder[a.severity] - severityOrder[b.severity];
      }
      return new Date(b.date).getTime() - new Date(a.date).getTime();
    });

    return alerts;
};

export const dbGetFlaggedStudents = (mentorId: string): { student: Student, record: MoodRecord, reason: 'low_score' | 'independent_report', severity: AlertSeverity }[] => {
    const allAlerts = dbGetAlerts(mentorId);
    
    const moodAlerts = allAlerts
        .filter(alert => alert.source.type === 'mood_record' && (alert.reason === 'low_score' || alert.reason === 'independent_report'))
        .map(alert => {
            const source = alert.source as { type: 'mood_record', record: MoodRecord };
            return {
                student: alert.student,
                record: source.record,
                reason: alert.reason as 'low_score' | 'independent_report',
                severity: alert.severity,
            };
        });
        
    return moodAlerts;
};

export const dbAcknowledgeMoodRecord = (recordId: string): boolean => {
    return dbAcknowledgeAlert(recordId, 'mood_record');
};

export const dbGetTools = (): Tool[] => tools;

export const dbAddIntervention = (data: Omit<Intervention, 'id'>): Intervention => {
    const newIntervention: Intervention = {
        ...data,
        id: `int-${Date.now()}`
    };
    interventions.unshift(newIntervention);
    saveData();
    return newIntervention;
};

export const dbGetInterventionsForStudent = (studentId: string): Intervention[] => {
    return interventions.filter(i => i.studentId === studentId).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// --- Feedback Functions ---

export const dbAddFeedback = (feedbackData: Omit<Feedback, 'id' | 'status' | 'date'>): Feedback => {
    const newFeedback: Feedback = {
        ...feedbackData,
        id: `feedback-${Date.now()}`,
        status: 'new',
        date: new Date().toISOString(),
    };
    feedback.unshift(newFeedback); // Add to start of array
    saveData();
    return newFeedback;
};

export const dbGetAllFeedback = (): Feedback[] => {
    return [...feedback].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const dbUpdateFeedbackStatus = (feedbackId: string, status: FeedbackStatus): Feedback | null => {
    const item = feedback.find(f => f.id === feedbackId);
    if (item) {
        item.status = status;
        saveData();
        return item;
    }
    return null;
};

export const dbExportAllData = (userId: string): string => {
    const dataToStore: AppData = { users, moodRecords, sessions, voiceNotes, tools, interventions, feedback };
    const exportObject = {
        exportDate: new Date().toISOString(),
        exportedByUserId: userId,
        data: dataToStore,
    };
    return JSON.stringify(exportObject, null, 2); // Pretty print JSON
};

export const dbLoadBackupForImpersonation = (jsonData: string): { success: boolean; impersonatedUserId?: string; error?: string } => {
    try {
        const parsedBackup = JSON.parse(jsonData);
        if (!parsedBackup.exportedByUserId || !parsedBackup.data) {
            return { success: false, error: 'קובץ הגיבוי אינו תקין או חסר מידע.' };
        }

        // 1. Back up the admin's current state to sessionStorage
        const adminCurrentData = localStorage.getItem(APP_DATA_KEY);
        const adminCurrentUserId = localStorage.getItem('rememberedUserId');
        
        if (adminCurrentData && adminCurrentUserId) {
            sessionStorage.setItem('admin_data_backup', adminCurrentData);
            sessionStorage.setItem('admin_id_backup', adminCurrentUserId);
        } else {
             return { success: false, error: 'לא ניתן לגבות את נתוני האדמין הנוכחיים.' };
        }

        // 2. Load the mentor's data into localStorage
        localStorage.setItem(APP_DATA_KEY, JSON.stringify(parsedBackup.data));
        
        // 3. Set the impersonation user ID
        localStorage.setItem('impersonating_user_id', parsedBackup.exportedByUserId);
        
        // 4. Clear remembered user to ensure impersonation takes precedence
        localStorage.removeItem('rememberedUserId');
        
        return { success: true, impersonatedUserId: parsedBackup.exportedByUserId };

    } catch (e) {
        console.error("Failed to load backup data", e);
        return { success: false, error: 'שגיאה בפענוח קובץ הגיבוי.' };
    }
};

export const dbExitImpersonation = (): string | null => {
    const adminDataBackup = sessionStorage.getItem('admin_data_backup');
    const adminIdBackup = sessionStorage.getItem('admin_id_backup');

    if (adminDataBackup && adminIdBackup) {
        // Restore admin data
        localStorage.setItem(APP_DATA_KEY, adminDataBackup);
        localStorage.setItem('rememberedUserId', adminIdBackup);

        // Clean up
        localStorage.removeItem('impersonating_user_id');
        sessionStorage.removeItem('admin_data_backup');
        sessionStorage.removeItem('admin_id_backup');
        
        return adminIdBackup;
    }
    return null;
};