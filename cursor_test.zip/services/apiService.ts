import { Role, User, Student, MoodRecord, Session, SessionData, VoiceNote, Tool, Intervention, AlertSeverity, Alert, Feedback, FeedbackStatus } from '../types';
import { WellbeingFormData } from '../components/WellbeingForm';
import * as db from './localStorageService';

const SIMULATED_DELAY = 300; // ms

const simulateApiCall = <T>(data: T): Promise<T> => {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve(data);
    }, SIMULATED_DELAY);
  });
};

const apiService = {
  login: (phone: string, password?: string): Promise<User | null> => simulateApiCall(db.dbLogin(phone, password)),

  getUserById: (id: string): Promise<User | undefined> => simulateApiCall(db.dbGetUserById(id)),
  
  getAllUsers: (): Promise<(User | Student)[]> => simulateApiCall(db.dbGetAllUsers()),

  addUser: (userData: Partial<Omit<Student, 'role'>> & { role?: Role }): Promise<User | Student> => simulateApiCall(db.dbAddUser(userData)),
  
  addMultipleUsers: (newStudentsData: any[]): Promise<{ success: number, failures: number }> => simulateApiCall(db.dbAddMultipleUsers(newStudentsData)),
  
  addMultipleMentors: (newMentorsData: any[]): Promise<{ success: number, failures: number }> => simulateApiCall(db.dbAddMultipleMentors(newMentorsData)),

  updateUser: (userId: string, updatedData: Partial<Omit<Student, 'role'>> & { role?: Role }): Promise<User | Student | null> => simulateApiCall(db.dbUpdateUser(userId, updatedData)),
  
  deleteUser: (userId: string): Promise<boolean> => simulateApiCall(db.dbDeleteUser(userId)),

  getUnassignedStudents: (): Promise<Student[]> => simulateApiCall(db.dbGetUnassignedStudents()),

  reassignStudent: (studentId: string, newMentorId: string | null): Promise<Student | null> => simulateApiCall(db.dbReassignStudent(studentId, newMentorId)),

  getStudentById: (id: string): Promise<Student | undefined> => simulateApiCall(db.dbGetStudentById(id)),

  getStudentsForMentor: (mentorId: string): Promise<Student[]> => simulateApiCall(db.dbGetStudentsForMentor(mentorId)),

  getMoodRecordsForStudent: (studentId: string): Promise<MoodRecord[]> => simulateApiCall(db.dbGetMoodRecordsForStudent(studentId)),
  
  addMoodRecord: (recordData: Omit<MoodRecord, 'id' | 'averageScore'>): Promise<MoodRecord> => simulateApiCall(db.dbAddMoodRecord(recordData)),
    
  addSessionWithReport: (recordData: WellbeingFormData, mentorId: string): Promise<{ session: Session, record: MoodRecord }> => simulateApiCall(db.dbAddSessionWithReport(recordData, mentorId)),
  
  addReportToExistingSession: (sessionId: string, reportData: WellbeingFormData): Promise<{ session: Session, record: MoodRecord } | null> => simulateApiCall(db.dbAddReportToExistingSession(sessionId, reportData)),

  getSessionsForMentor: (mentorId: string): Promise<Session[]> => simulateApiCall(db.dbGetSessionsForMentor(mentorId)),

  getSessionsForStudent: (studentId: string): Promise<Session[]> => simulateApiCall(db.dbGetSessionsForStudent(studentId)),
  
  getSessionById: (sessionId: string): Promise<Session | undefined> => simulateApiCall(db.dbGetSessionById(sessionId)),
  
  addSession: (sessionData: SessionData): Promise<Session[]> => simulateApiCall(db.dbAddSession(sessionData)),
  
  getVoiceNotesForStudent: (studentId: string): Promise<VoiceNote[]> => simulateApiCall(db.dbGetVoiceNotesForStudent(studentId)),

  addVoiceNote: (noteData: Omit<VoiceNote, 'id'>): Promise<VoiceNote> => simulateApiCall(db.dbAddVoiceNote(noteData)),

  getTools: (): Promise<Tool[]> => simulateApiCall(db.dbGetTools()),
  
  addIntervention: (data: Omit<Intervention, 'id'>): Promise<Intervention> => simulateApiCall(db.dbAddIntervention(data)),

  getInterventionsForStudent: (studentId: string): Promise<Intervention[]> => simulateApiCall(db.dbGetInterventionsForStudent(studentId)),

  getAlerts: (mentorId: string): Promise<Alert[]> => simulateApiCall(db.dbGetAlerts(mentorId)),

  acknowledgeAlert: (alertId: string, alertType: 'mood_record' | 'intervention'): Promise<boolean> => simulateApiCall(db.dbAcknowledgeAlert(alertId, alertType)),

  // Feedback API
  addFeedback: (data: Omit<Feedback, 'id' | 'status' | 'date'>): Promise<Feedback> => simulateApiCall(db.dbAddFeedback(data)),
  getAllFeedback: (): Promise<Feedback[]> => simulateApiCall(db.dbGetAllFeedback()),
  updateFeedbackStatus: (id: string, status: FeedbackStatus): Promise<Feedback | null> => simulateApiCall(db.dbUpdateFeedbackStatus(id, status)),

  // Data Management API
  exportAllData: (userId: string): Promise<string> => simulateApiCall(db.dbExportAllData(userId)),
  loadBackupForImpersonation: (jsonData: string): Promise<{ success: boolean; impersonatedUserId?: string; error?: string }> => simulateApiCall(db.dbLoadBackupForImpersonation(jsonData)),
  exitImpersonation: (): Promise<string | null> => simulateApiCall(db.dbExitImpersonation()),

  resetData: (): Promise<void> => {
    db.resetData();
    return simulateApiCall(undefined);
  }
};

export default apiService;
